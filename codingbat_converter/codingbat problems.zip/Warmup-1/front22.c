#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, take the first 2 chars and return the string with
the 2 chars added at both the front and back, so "kitten"
yields"kikittenki". If the string length is less than 2, use
whatever chars are there.
*/

char * front22(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = front22(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"kitten\"\n");
    correct += test("kitten", "kikittenki");
    total++;
    printf("Sent: \"Ha\"\n");
    correct += test("Ha", "HaHaHa");
    total++;
    printf("Sent: \"abc\"\n");
    correct += test("abc", "ababcab");
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", "ababab");
    total++;
    printf("Sent: \"a\"\n");
    correct += test("a", "aaa");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"Logic\"\n");
    correct += test("Logic", "LoLogicLo");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

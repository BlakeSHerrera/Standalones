#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 int values, return whichever value is nearest to the
value 10, or return 0 in the event of a tie. Note that
Math.abs(n) returns the absolute value of a number.
*/

int close10(int a, int b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int expected)
{
    int returned = close10(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 8, 13\n");
    correct += test(8, 13, 8);
    total++;
    printf("Sent: 13, 8\n");
    correct += test(13, 8, 8);
    total++;
    printf("Sent: 13, 7\n");
    correct += test(13, 7, 0);
    total++;
    printf("Sent: 7, 13\n");
    correct += test(7, 13, 0);
    total++;
    printf("Sent: 9, 13\n");
    correct += test(9, 13, 9);
    total++;
    printf("Sent: 13, 8\n");
    correct += test(13, 8, 8);
    total++;
    printf("Sent: 10, 12\n");
    correct += test(10, 12, 10);
    total++;
    printf("Sent: 11, 10\n");
    correct += test(11, 10, 10);
    total++;
    printf("Sent: 5, 21\n");
    correct += test(5, 21, 5);
    total++;
    printf("Sent: 0, 20\n");
    correct += test(0, 20, 0);
    total++;
    printf("Sent: 10, 10\n");
    correct += test(10, 10, 0);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

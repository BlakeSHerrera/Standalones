#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a new string where the first and last
chars have been exchanged.
*/

char * frontBack(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = frontBack(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"code\"\n");
    correct += test("code", "eodc");
    total++;
    printf("Sent: \"a\"\n");
    correct += test("a", "a");
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", "ba");
    total++;
    printf("Sent: \"abc\"\n");
    correct += test("abc", "cba");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"Chocolate\"\n");
    correct += test("Chocolate", "ehocolatC");
    total++;
    printf("Sent: \"aavJ\"\n");
    correct += test("aavJ", "Java");
    total++;
    printf("Sent: \"hello\"\n");
    correct += test("hello", "oellh");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

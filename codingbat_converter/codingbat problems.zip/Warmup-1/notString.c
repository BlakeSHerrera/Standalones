#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a new string where "not " has been added
to the front. However, if the string already begins with "not",
return the string unchanged. Note: use .equals() to compare 2
strings.
*/

char * notString(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = notString(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"candy\"\n");
    correct += test("candy", "not candy");
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", "not x");
    total++;
    printf("Sent: \"not bad\"\n");
    correct += test("not bad", "not bad");
    total++;
    printf("Sent: \"bad\"\n");
    correct += test("bad", "not bad");
    total++;
    printf("Sent: \"not\"\n");
    correct += test("not", "not");
    total++;
    printf("Sent: \"is not\"\n");
    correct += test("is not", "not is not");
    total++;
    printf("Sent: \"no\"\n");
    correct += test("no", "not no");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

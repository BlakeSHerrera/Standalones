#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given two non-negative int values, return TRUE if they have the
same last digit, such as with 27 and 57. Note that the % "mod"
operator computes remainders, so 17 % 10 is 7.
*/

int lastDigit(int a, int b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int expected)
{
    int returned = lastDigit(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 7, 17\n");
    correct += test(7, 17, TRUE);
    total++;
    printf("Sent: 6, 17\n");
    correct += test(6, 17, FALSE);
    total++;
    printf("Sent: 3, 113\n");
    correct += test(3, 113, TRUE);
    total++;
    printf("Sent: 114, 113\n");
    correct += test(114, 113, FALSE);
    total++;
    printf("Sent: 114, 4\n");
    correct += test(114, 4, TRUE);
    total++;
    printf("Sent: 10, 0\n");
    correct += test(10, 0, TRUE);
    total++;
    printf("Sent: 11, 0\n");
    correct += test(11, 0, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a string made of the first 2 chars (if
present), however include first char only if it is 'o' and
include the second only if it is 'z', so "ozymandias" yields
"oz".
*/

char * startOz(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = startOz(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"ozymandias\"\n");
    correct += test("ozymandias", "oz");
    total++;
    printf("Sent: \"bzoo\"\n");
    correct += test("bzoo", "z");
    total++;
    printf("Sent: \"oxx\"\n");
    correct += test("oxx", "o");
    total++;
    printf("Sent: \"oz\"\n");
    correct += test("oz", "oz");
    total++;
    printf("Sent: \"ounce\"\n");
    correct += test("ounce", "o");
    total++;
    printf("Sent: \"o\"\n");
    correct += test("o", "o");
    total++;
    printf("Sent: \"abc\"\n");
    correct += test("abc", "");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"zoo\"\n");
    correct += test("zoo", "");
    total++;
    printf("Sent: \"aztec\"\n");
    correct += test("aztec", "z");
    total++;
    printf("Sent: \"zzzz\"\n");
    correct += test("zzzz", "z");
    total++;
    printf("Sent: \"oznic\"\n");
    correct += test("oznic", "oz");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 ints, a and b, return TRUE if one if them is 10 or if
their sum is 10.
*/

int makes10(int a, int b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int expected)
{
    int returned = makes10(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 9, 10\n");
    correct += test(9, 10, TRUE);
    total++;
    printf("Sent: 9, 9\n");
    correct += test(9, 9, FALSE);
    total++;
    printf("Sent: 1, 9\n");
    correct += test(1, 9, TRUE);
    total++;
    printf("Sent: 10, 1\n");
    correct += test(10, 1, TRUE);
    total++;
    printf("Sent: 10, 10\n");
    correct += test(10, 10, TRUE);
    total++;
    printf("Sent: 8, 2\n");
    correct += test(8, 2, TRUE);
    total++;
    printf("Sent: 8, 3\n");
    correct += test(8, 3, FALSE);
    total++;
    printf("Sent: 10, 42\n");
    correct += test(10, 42, TRUE);
    total++;
    printf("Sent: 12, -2\n");
    correct += test(12, -2, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return TRUE if the given non-negative number is a multiple of 3
or a multiple of 5. Use the % "mod" operator -- see Introduction
to Mod
*/

int or35(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int expected)
{
    int returned = or35(n);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 3\n");
    correct += test(3, TRUE);
    total++;
    printf("Sent: 10\n");
    correct += test(10, TRUE);
    total++;
    printf("Sent: 8\n");
    correct += test(8, FALSE);
    total++;
    printf("Sent: 15\n");
    correct += test(15, TRUE);
    total++;
    printf("Sent: 5\n");
    correct += test(5, TRUE);
    total++;
    printf("Sent: 9\n");
    correct += test(9, TRUE);
    total++;
    printf("Sent: 4\n");
    correct += test(4, FALSE);
    total++;
    printf("Sent: 7\n");
    correct += test(7, FALSE);
    total++;
    printf("Sent: 6\n");
    correct += test(6, TRUE);
    total++;
    printf("Sent: 17\n");
    correct += test(17, FALSE);
    total++;
    printf("Sent: 18\n");
    correct += test(18, TRUE);
    total++;
    printf("Sent: 29\n");
    correct += test(29, FALSE);
    total++;
    printf("Sent: 20\n");
    correct += test(20, TRUE);
    total++;
    printf("Sent: 21\n");
    correct += test(21, TRUE);
    total++;
    printf("Sent: 22\n");
    correct += test(22, FALSE);
    total++;
    printf("Sent: 45\n");
    correct += test(45, TRUE);
    total++;
    printf("Sent: 99\n");
    correct += test(99, TRUE);
    total++;
    printf("Sent: 100\n");
    correct += test(100, TRUE);
    total++;
    printf("Sent: 101\n");
    correct += test(101, FALSE);
    total++;
    printf("Sent: 121\n");
    correct += test(121, FALSE);
    total++;
    printf("Sent: 122\n");
    correct += test(122, FALSE);
    total++;
    printf("Sent: 123\n");
    correct += test(123, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

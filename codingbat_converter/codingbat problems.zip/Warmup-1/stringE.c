#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return TRUE if the given string contains between 1 and 3 'e'
chars.
*/

int stringE(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = stringE(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", TRUE);
    total++;
    printf("Sent: \"Heelle\"\n");
    correct += test("Heelle", TRUE);
    total++;
    printf("Sent: \"Heelele\"\n");
    correct += test("Heelele", FALSE);
    total++;
    printf("Sent: \"Hll\"\n");
    correct += test("Hll", FALSE);
    total++;
    printf("Sent: \"e\"\n");
    correct += test("e", TRUE);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

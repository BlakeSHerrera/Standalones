#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We'll say that a number is "teen" if it is in the range 13..19
inclusive. Given 2 int values, return TRUE if one or the other is
teen, but not both.
*/

int loneTeen(int a, int b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int expected)
{
    int returned = loneTeen(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 13, 99\n");
    correct += test(13, 99, TRUE);
    total++;
    printf("Sent: 21, 19\n");
    correct += test(21, 19, TRUE);
    total++;
    printf("Sent: 13, 13\n");
    correct += test(13, 13, FALSE);
    total++;
    printf("Sent: 14, 20\n");
    correct += test(14, 20, TRUE);
    total++;
    printf("Sent: 20, 15\n");
    correct += test(20, 15, TRUE);
    total++;
    printf("Sent: 16, 17\n");
    correct += test(16, 17, FALSE);
    total++;
    printf("Sent: 16, 9\n");
    correct += test(16, 9, TRUE);
    total++;
    printf("Sent: 16, 18\n");
    correct += test(16, 18, FALSE);
    total++;
    printf("Sent: 13, 19\n");
    correct += test(13, 19, FALSE);
    total++;
    printf("Sent: 13, 20\n");
    correct += test(13, 20, TRUE);
    total++;
    printf("Sent: 6, 18\n");
    correct += test(6, 18, TRUE);
    total++;
    printf("Sent: 99, 13\n");
    correct += test(99, 13, TRUE);
    total++;
    printf("Sent: 99, 99\n");
    correct += test(99, 99, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

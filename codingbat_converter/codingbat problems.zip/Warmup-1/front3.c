#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, we'll say that the front is the first 3 chars of
the string. If the string length is less than 3, the front is
whatever is there. Return a new string which is 3 copies of the
front.
*/

char * front3(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = front3(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Java\"\n");
    correct += test("Java", "JavJavJav");
    total++;
    printf("Sent: \"Chocolate\"\n");
    correct += test("Chocolate", "ChoChoCho");
    total++;
    printf("Sent: \"abc\"\n");
    correct += test("abc", "abcabcabc");
    total++;
    printf("Sent: \"abcXYZ\"\n");
    correct += test("abcXYZ", "abcabcabc");
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", "ababab");
    total++;
    printf("Sent: \"a\"\n");
    correct += test("a", "aaa");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

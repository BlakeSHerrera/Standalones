#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 int values, return TRUE if they are both in the range
30..40 inclusive, or they are both in the range 40..50 inclusive.
*/

int in3050(int a, int b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int expected)
{
    int returned = in3050(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 30, 31\n");
    correct += test(30, 31, TRUE);
    total++;
    printf("Sent: 30, 41\n");
    correct += test(30, 41, FALSE);
    total++;
    printf("Sent: 40, 50\n");
    correct += test(40, 50, TRUE);
    total++;
    printf("Sent: 40, 51\n");
    correct += test(40, 51, FALSE);
    total++;
    printf("Sent: 39, 50\n");
    correct += test(39, 50, FALSE);
    total++;
    printf("Sent: 50, 39\n");
    correct += test(50, 39, FALSE);
    total++;
    printf("Sent: 40, 39\n");
    correct += test(40, 39, TRUE);
    total++;
    printf("Sent: 49, 48\n");
    correct += test(49, 48, TRUE);
    total++;
    printf("Sent: 50, 40\n");
    correct += test(50, 40, TRUE);
    total++;
    printf("Sent: 50, 51\n");
    correct += test(50, 51, FALSE);
    total++;
    printf("Sent: 35, 36\n");
    correct += test(35, 36, TRUE);
    total++;
    printf("Sent: 35, 45\n");
    correct += test(35, 45, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

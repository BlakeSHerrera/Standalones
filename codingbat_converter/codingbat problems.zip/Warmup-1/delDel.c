#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, if the string "del" appears starting at index 1,
return a string where that "del" has been deleted. Otherwise,
return the string unchanged.
*/

char * delDel(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = delDel(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"adelbc\"\n");
    correct += test("adelbc", "abc");
    total++;
    printf("Sent: \"adelHello\"\n");
    correct += test("adelHello", "aHello");
    total++;
    printf("Sent: \"adedbc\"\n");
    correct += test("adedbc", "adedbc");
    total++;
    printf("Sent: \"abcdel\"\n");
    correct += test("abcdel", "abcdel");
    total++;
    printf("Sent: \"add\"\n");
    correct += test("add", "add");
    total++;
    printf("Sent: \"ad\"\n");
    correct += test("ad", "ad");
    total++;
    printf("Sent: \"a\"\n");
    correct += test("a", "a");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"del\"\n");
    correct += test("del", "del");
    total++;
    printf("Sent: \"adel\"\n");
    correct += test("adel", "a");
    total++;
    printf("Sent: \"aadelbb\"\n");
    correct += test("aadelbb", "aadelbb");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an int n, return TRUE if it is within 10 of 100 or 200.
Note: Math.abs(num) computes the absolute value of a number.
*/

int nearHundred(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int expected)
{
    int returned = nearHundred(n);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 93\n");
    correct += test(93, TRUE);
    total++;
    printf("Sent: 90\n");
    correct += test(90, TRUE);
    total++;
    printf("Sent: 89\n");
    correct += test(89, FALSE);
    total++;
    printf("Sent: 110\n");
    correct += test(110, TRUE);
    total++;
    printf("Sent: 111\n");
    correct += test(111, FALSE);
    total++;
    printf("Sent: 121\n");
    correct += test(121, FALSE);
    total++;
    printf("Sent: -101\n");
    correct += test(-101, FALSE);
    total++;
    printf("Sent: -209\n");
    correct += test(-209, FALSE);
    total++;
    printf("Sent: 190\n");
    correct += test(190, TRUE);
    total++;
    printf("Sent: 209\n");
    correct += test(209, TRUE);
    total++;
    printf("Sent: 0\n");
    correct += test(0, FALSE);
    total++;
    printf("Sent: 5\n");
    correct += test(5, FALSE);
    total++;
    printf("Sent: -50\n");
    correct += test(-50, FALSE);
    total++;
    printf("Sent: 191\n");
    correct += test(191, TRUE);
    total++;
    printf("Sent: 189\n");
    correct += test(189, FALSE);
    total++;
    printf("Sent: 200\n");
    correct += test(200, TRUE);
    total++;
    printf("Sent: 210\n");
    correct += test(210, TRUE);
    total++;
    printf("Sent: 211\n");
    correct += test(211, FALSE);
    total++;
    printf("Sent: 290\n");
    correct += test(290, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

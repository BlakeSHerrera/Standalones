#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given two temperatures, return TRUE if one is less than 0 and the
other is greater than 100.
*/

int icyHot(int temp1, int temp2)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int temp1, int temp2, int expected)
{
    int returned = icyHot(temp1, temp2);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 120, -1\n");
    correct += test(120, -1, TRUE);
    total++;
    printf("Sent: -1, 120\n");
    correct += test(-1, 120, TRUE);
    total++;
    printf("Sent: 2, 120\n");
    correct += test(2, 120, FALSE);
    total++;
    printf("Sent: -1, 100\n");
    correct += test(-1, 100, FALSE);
    total++;
    printf("Sent: -2, -2\n");
    correct += test(-2, -2, FALSE);
    total++;
    printf("Sent: 120, 120\n");
    correct += test(120, 120, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

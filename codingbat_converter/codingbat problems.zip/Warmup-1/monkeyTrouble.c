#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We have two monkeys, a and b, and the parameters aSmile and
bSmile indicate if each is smiling. We are in trouble if they are
both smiling or if neither of them is smiling. Return TRUE if we
are in trouble.
*/

int monkeyTrouble(int aSmile, int bSmile)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int aSmile, int bSmile, int expected)
{
    int returned = monkeyTrouble(aSmile, bSmile);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: TRUE, TRUE\n");
    correct += test(TRUE, TRUE, TRUE);
    total++;
    printf("Sent: FALSE, FALSE\n");
    correct += test(FALSE, FALSE, TRUE);
    total++;
    printf("Sent: TRUE, FALSE\n");
    correct += test(TRUE, FALSE, FALSE);
    total++;
    printf("Sent: FALSE, TRUE\n");
    correct += test(FALSE, TRUE, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

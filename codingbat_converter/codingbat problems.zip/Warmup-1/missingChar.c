#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a non-empty string and an int n, return a new string where
the char at index n has been removed. The value of n will be a
valid index of a char in the original string (i.e. n will be in
the range 0..str.length()-1 inclusive).
*/

char * missingChar(char * str, int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int n, char * expected)
{
    char * returned = missingChar(str, n);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"kitten\", 1\n");
    correct += test("kitten", 1, "ktten");
    total++;
    printf("Sent: \"kitten\", 0\n");
    correct += test("kitten", 0, "itten");
    total++;
    printf("Sent: \"kitten\", 4\n");
    correct += test("kitten", 4, "kittn");
    total++;
    printf("Sent: \"Hi\", 0\n");
    correct += test("Hi", 0, "i");
    total++;
    printf("Sent: \"Hi\", 1\n");
    correct += test("Hi", 1, "H");
    total++;
    printf("Sent: \"code\", 0\n");
    correct += test("code", 0, "ode");
    total++;
    printf("Sent: \"code\", 1\n");
    correct += test("code", 1, "cde");
    total++;
    printf("Sent: \"code\", 2\n");
    correct += test("code", 2, "coe");
    total++;
    printf("Sent: \"code\", 3\n");
    correct += test("code", 3, "cod");
    total++;
    printf("Sent: \"chocolate\", 8\n");
    correct += test("chocolate", 8, "chocolat");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return TRUE if the given string begins with "mix", except the 'm'
can be anything, so "pix", "9ix" .. all count.
*/

int mixStart(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = mixStart(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"mix snacks\"\n");
    correct += test("mix snacks", TRUE);
    total++;
    printf("Sent: \"pix snacks\"\n");
    correct += test("pix snacks", TRUE);
    total++;
    printf("Sent: \"piz snacks\"\n");
    correct += test("piz snacks", FALSE);
    total++;
    printf("Sent: \"nix\"\n");
    correct += test("nix", TRUE);
    total++;
    printf("Sent: \"ni\"\n");
    correct += test("ni", FALSE);
    total++;
    printf("Sent: \"n\"\n");
    correct += test("n", FALSE);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

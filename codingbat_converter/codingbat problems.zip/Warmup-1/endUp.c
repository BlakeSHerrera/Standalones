#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a new string where the last 3 chars are
now in upper case. If the string has less than 3 chars, uppercase
whatever is there. Note that str.toUpperCase() returns the
uppercase version of a string.
*/

char * endUp(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = endUp(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "HeLLO");
    total++;
    printf("Sent: \"hi there\"\n");
    correct += test("hi there", "hi thERE");
    total++;
    printf("Sent: \"hi\"\n");
    correct += test("hi", "HI");
    total++;
    printf("Sent: \"woo hoo\"\n");
    correct += test("woo hoo", "woo HOO");
    total++;
    printf("Sent: \"xyz12\"\n");
    correct += test("xyz12", "xyZ12");
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", "X");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

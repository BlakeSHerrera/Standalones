#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 int values, return TRUE if one is negative and one is
positive. Except if the parameter "negative" is TRUE, then return
TRUE only if both are negative.
*/

int posNeg(int a, int b, int negative)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int negative, int expected)
{
    int returned = posNeg(a, b, negative);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 1, -1, FALSE\n");
    correct += test(1, -1, FALSE, TRUE);
    total++;
    printf("Sent: -1, 1, FALSE\n");
    correct += test(-1, 1, FALSE, TRUE);
    total++;
    printf("Sent: -4, -5, TRUE\n");
    correct += test(-4, -5, TRUE, TRUE);
    total++;
    printf("Sent: -4, -5, FALSE\n");
    correct += test(-4, -5, FALSE, FALSE);
    total++;
    printf("Sent: -4, 5, FALSE\n");
    correct += test(-4, 5, FALSE, TRUE);
    total++;
    printf("Sent: -4, 5, TRUE\n");
    correct += test(-4, 5, TRUE, FALSE);
    total++;
    printf("Sent: 1, 1, FALSE\n");
    correct += test(1, 1, FALSE, FALSE);
    total++;
    printf("Sent: -1, -1, FALSE\n");
    correct += test(-1, -1, FALSE, FALSE);
    total++;
    printf("Sent: 1, -1, TRUE\n");
    correct += test(1, -1, TRUE, FALSE);
    total++;
    printf("Sent: -1, 1, TRUE\n");
    correct += test(-1, 1, TRUE, FALSE);
    total++;
    printf("Sent: 1, 1, TRUE\n");
    correct += test(1, 1, TRUE, FALSE);
    total++;
    printf("Sent: -1, -1, TRUE\n");
    correct += test(-1, -1, TRUE, TRUE);
    total++;
    printf("Sent: 5, -5, FALSE\n");
    correct += test(5, -5, FALSE, TRUE);
    total++;
    printf("Sent: -6, 6, FALSE\n");
    correct += test(-6, 6, FALSE, TRUE);
    total++;
    printf("Sent: -5, -6, FALSE\n");
    correct += test(-5, -6, FALSE, FALSE);
    total++;
    printf("Sent: -2, -1, FALSE\n");
    correct += test(-2, -1, FALSE, FALSE);
    total++;
    printf("Sent: 1, 2, FALSE\n");
    correct += test(1, 2, FALSE, FALSE);
    total++;
    printf("Sent: -5, 6, TRUE\n");
    correct += test(-5, 6, TRUE, FALSE);
    total++;
    printf("Sent: -5, -5, TRUE\n");
    correct += test(-5, -5, TRUE, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

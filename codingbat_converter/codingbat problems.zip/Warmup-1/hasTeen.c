#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We'll say that a number is "teen" if it is in the range 13..19
inclusive. Given 3 int values, return TRUE if 1 or more of them
are teen.
*/

int hasTeen(int a, int b, int c)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int c, int expected)
{
    int returned = hasTeen(a, b, c);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 13, 20, 10\n");
    correct += test(13, 20, 10, TRUE);
    total++;
    printf("Sent: 20, 19, 10\n");
    correct += test(20, 19, 10, TRUE);
    total++;
    printf("Sent: 20, 10, 13\n");
    correct += test(20, 10, 13, TRUE);
    total++;
    printf("Sent: 1, 20, 12\n");
    correct += test(1, 20, 12, FALSE);
    total++;
    printf("Sent: 19, 20, 12\n");
    correct += test(19, 20, 12, TRUE);
    total++;
    printf("Sent: 12, 20, 19\n");
    correct += test(12, 20, 19, TRUE);
    total++;
    printf("Sent: 12, 9, 20\n");
    correct += test(12, 9, 20, FALSE);
    total++;
    printf("Sent: 12, 18, 20\n");
    correct += test(12, 18, 20, TRUE);
    total++;
    printf("Sent: 14, 2, 20\n");
    correct += test(14, 2, 20, TRUE);
    total++;
    printf("Sent: 4, 2, 20\n");
    correct += test(4, 2, 20, FALSE);
    total++;
    printf("Sent: 11, 22, 22\n");
    correct += test(11, 22, 22, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

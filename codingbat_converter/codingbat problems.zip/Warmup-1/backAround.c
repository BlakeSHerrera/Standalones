#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, take the last char and return a new string with
the last char added at the front and back, so "cat" yields
"tcatt". The original string will be length 1 or more.
*/

char * backAround(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = backAround(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"cat\"\n");
    correct += test("cat", "tcatt");
    total++;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "oHelloo");
    total++;
    printf("Sent: \"a\"\n");
    correct += test("a", "aaa");
    total++;
    printf("Sent: \"abc\"\n");
    correct += test("abc", "cabcc");
    total++;
    printf("Sent: \"read\"\n");
    correct += test("read", "dreadd");
    total++;
    printf("Sent: \"boo\"\n");
    correct += test("boo", "obooo");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

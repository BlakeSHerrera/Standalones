#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We have a loud talking parrot. The "hour" parameter is the
current hour time in the range 0..23. We are in trouble if the
parrot is talking and the hour is before 7 or after 20. Return
TRUE if we are in trouble.
*/

int parrotTrouble(int talking, int hour)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int talking, int hour, int expected)
{
    int returned = parrotTrouble(talking, hour);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: TRUE, 6\n");
    correct += test(TRUE, 6, TRUE);
    total++;
    printf("Sent: TRUE, 7\n");
    correct += test(TRUE, 7, FALSE);
    total++;
    printf("Sent: FALSE, 6\n");
    correct += test(FALSE, 6, FALSE);
    total++;
    printf("Sent: TRUE, 21\n");
    correct += test(TRUE, 21, TRUE);
    total++;
    printf("Sent: FALSE, 21\n");
    correct += test(FALSE, 21, FALSE);
    total++;
    printf("Sent: FALSE, 20\n");
    correct += test(FALSE, 20, FALSE);
    total++;
    printf("Sent: TRUE, 23\n");
    correct += test(TRUE, 23, TRUE);
    total++;
    printf("Sent: FALSE, 23\n");
    correct += test(FALSE, 23, FALSE);
    total++;
    printf("Sent: TRUE, 20\n");
    correct += test(TRUE, 20, FALSE);
    total++;
    printf("Sent: FALSE, 12\n");
    correct += test(FALSE, 12, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

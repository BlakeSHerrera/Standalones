#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given three int values, a b c, return the largest.
*/

int intMax(int a, int b, int c)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int c, int expected)
{
    int returned = intMax(a, b, c);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 1, 2, 3\n");
    correct += test(1, 2, 3, 3);
    total++;
    printf("Sent: 1, 3, 2\n");
    correct += test(1, 3, 2, 3);
    total++;
    printf("Sent: 3, 2, 1\n");
    correct += test(3, 2, 1, 3);
    total++;
    printf("Sent: 9, 3, 3\n");
    correct += test(9, 3, 3, 9);
    total++;
    printf("Sent: 3, 9, 3\n");
    correct += test(3, 9, 3, 9);
    total++;
    printf("Sent: 3, 3, 9\n");
    correct += test(3, 3, 9, 9);
    total++;
    printf("Sent: 8, 2, 3\n");
    correct += test(8, 2, 3, 8);
    total++;
    printf("Sent: -3, -1, -2\n");
    correct += test(-3, -1, -2, -1);
    total++;
    printf("Sent: 6, 2, 5\n");
    correct += test(6, 2, 5, 6);
    total++;
    printf("Sent: 5, 6, 2\n");
    correct += test(5, 6, 2, 6);
    total++;
    printf("Sent: 5, 2, 6\n");
    correct += test(5, 2, 6, 6);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

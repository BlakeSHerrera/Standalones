#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an int n, return the absolute difference between n and 21,
except return double the absolute difference if n is over 21.
*/

int diff21(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int expected)
{
    int returned = diff21(n);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 19\n");
    correct += test(19, 2);
    total++;
    printf("Sent: 10\n");
    correct += test(10, 11);
    total++;
    printf("Sent: 21\n");
    correct += test(21, 0);
    total++;
    printf("Sent: 22\n");
    correct += test(22, 2);
    total++;
    printf("Sent: 25\n");
    correct += test(25, 8);
    total++;
    printf("Sent: 30\n");
    correct += test(30, 18);
    total++;
    printf("Sent: 0\n");
    correct += test(0, 21);
    total++;
    printf("Sent: 1\n");
    correct += test(1, 20);
    total++;
    printf("Sent: 2\n");
    correct += test(2, 19);
    total++;
    printf("Sent: -1\n");
    correct += test(-1, 22);
    total++;
    printf("Sent: -2\n");
    correct += test(-2, 23);
    total++;
    printf("Sent: 50\n");
    correct += test(50, 58);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

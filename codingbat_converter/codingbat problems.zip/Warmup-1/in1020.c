#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 int values, return TRUE if either of them is in the range
10..20 inclusive.
*/

int in1020(int a, int b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int expected)
{
    int returned = in1020(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 12, 99\n");
    correct += test(12, 99, TRUE);
    total++;
    printf("Sent: 21, 12\n");
    correct += test(21, 12, TRUE);
    total++;
    printf("Sent: 8, 99\n");
    correct += test(8, 99, FALSE);
    total++;
    printf("Sent: 99, 10\n");
    correct += test(99, 10, TRUE);
    total++;
    printf("Sent: 20, 20\n");
    correct += test(20, 20, TRUE);
    total++;
    printf("Sent: 21, 21\n");
    correct += test(21, 21, FALSE);
    total++;
    printf("Sent: 9, 9\n");
    correct += test(9, 9, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

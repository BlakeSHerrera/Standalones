#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a non-empty string and an int N, return the string made
starting with char 0, and then every Nth char of the string. So
if N is 3, use char 0, 3, 6, ... and so on. N is 1 or more.
*/

char * everyNth(char * str, int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int n, char * expected)
{
    char * returned = everyNth(str, n);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Miracle\", 2\n");
    correct += test("Miracle", 2, "Mrce");
    total++;
    printf("Sent: \"abcdefg\", 2\n");
    correct += test("abcdefg", 2, "aceg");
    total++;
    printf("Sent: \"abcdefg\", 3\n");
    correct += test("abcdefg", 3, "adg");
    total++;
    printf("Sent: \"Chocolate\", 3\n");
    correct += test("Chocolate", 3, "Cca");
    total++;
    printf("Sent: \"Chocolates\", 3\n");
    correct += test("Chocolates", 3, "Ccas");
    total++;
    printf("Sent: \"Chocolates\", 4\n");
    correct += test("Chocolates", 4, "Coe");
    total++;
    printf("Sent: \"Chocolates\", 100\n");
    correct += test("Chocolates", 100, "C");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

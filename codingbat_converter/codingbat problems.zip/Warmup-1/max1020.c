#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 positive int values, return the larger value that is in
the range 10..20 inclusive, or return 0 if neither is in that
range.
*/

int max1020(int a, int b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int expected)
{
    int returned = max1020(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 11, 19\n");
    correct += test(11, 19, 19);
    total++;
    printf("Sent: 19, 11\n");
    correct += test(19, 11, 19);
    total++;
    printf("Sent: 11, 9\n");
    correct += test(11, 9, 11);
    total++;
    printf("Sent: 9, 21\n");
    correct += test(9, 21, 0);
    total++;
    printf("Sent: 10, 21\n");
    correct += test(10, 21, 10);
    total++;
    printf("Sent: 21, 10\n");
    correct += test(21, 10, 10);
    total++;
    printf("Sent: 9, 11\n");
    correct += test(9, 11, 11);
    total++;
    printf("Sent: 23, 10\n");
    correct += test(23, 10, 10);
    total++;
    printf("Sent: 20, 10\n");
    correct += test(20, 10, 20);
    total++;
    printf("Sent: 7, 20\n");
    correct += test(7, 20, 20);
    total++;
    printf("Sent: 17, 16\n");
    correct += test(17, 16, 17);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

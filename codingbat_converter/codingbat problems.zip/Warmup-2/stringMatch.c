#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 strings, a and b, return the number of the positions
where they contain the same length 2 substring. So "xxcaazz" and
"xxbaaz" yields 3, since the "xx", "aa", and "az" substrings
appear in the same place in both strings.
*/

int stringMatch(char * a, char * b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * a, char * b, int expected)
{
    int returned = stringMatch(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"xxcaazz\", \"xxbaaz\"\n");
    correct += test("xxcaazz", "xxbaaz", 3);
    total++;
    printf("Sent: \"abc\", \"abc\"\n");
    correct += test("abc", "abc", 2);
    total++;
    printf("Sent: \"abc\", \"axc\"\n");
    correct += test("abc", "axc", 0);
    total++;
    printf("Sent: \"hello\", \"he\"\n");
    correct += test("hello", "he", 1);
    total++;
    printf("Sent: \"he\", \"hello\"\n");
    correct += test("he", "hello", 1);
    total++;
    printf("Sent: \"h\", \"hello\"\n");
    correct += test("h", "hello", 0);
    total++;
    printf("Sent: \"\", \"hello\"\n");
    correct += test("", "hello", 0);
    total++;
    printf("Sent: \"aabbccdd\", \"abbbxxd\"\n");
    correct += test("aabbccdd", "abbbxxd", 1);
    total++;
    printf("Sent: \"aaxxaaxx\", \"iaxxai\"\n");
    correct += test("aaxxaaxx", "iaxxai", 3);
    total++;
    printf("Sent: \"iaxxai\", \"aaxxaaxx\"\n");
    correct += test("iaxxai", "aaxxaaxx", 3);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

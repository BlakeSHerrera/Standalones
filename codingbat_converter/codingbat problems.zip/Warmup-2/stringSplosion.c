#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a non-empty string like "Code" return a string like
"CCoCodCode".
*/

char * stringSplosion(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = stringSplosion(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Code\"\n");
    correct += test("Code", "CCoCodCode");
    total++;
    printf("Sent: \"abc\"\n");
    correct += test("abc", "aababc");
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", "aab");
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", "x");
    total++;
    printf("Sent: \"fade\"\n");
    correct += test("fade", "ffafadfade");
    total++;
    printf("Sent: \"There\"\n");
    correct += test("There", "TThTheTherThere");
    total++;
    printf("Sent: \"Kitten\"\n");
    correct += test("Kitten", "KKiKitKittKitteKitten");
    total++;
    printf("Sent: \"Bye\"\n");
    correct += test("Bye", "BByBye");
    total++;
    printf("Sent: \"Good\"\n");
    correct += test("Good", "GGoGooGood");
    total++;
    printf("Sent: \"Bad\"\n");
    correct += test("Bad", "BBaBad");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

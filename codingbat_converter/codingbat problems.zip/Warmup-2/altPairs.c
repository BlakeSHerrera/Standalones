#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a string made of the chars at indexes 0,1,
4,5, 8,9 ... so "kittens" yields "kien".
*/

char * altPairs(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = altPairs(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"kitten\"\n");
    correct += test("kitten", "kien");
    total++;
    printf("Sent: \"Chocolate\"\n");
    correct += test("Chocolate", "Chole");
    total++;
    printf("Sent: \"CodingHorror\"\n");
    correct += test("CodingHorror", "Congrr");
    total++;
    printf("Sent: \"yak\"\n");
    correct += test("yak", "ya");
    total++;
    printf("Sent: \"ya\"\n");
    correct += test("ya", "ya");
    total++;
    printf("Sent: \"y\"\n");
    correct += test("y", "y");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"ThisThatTheOther\"\n");
    correct += test("ThisThatTheOther", "ThThThth");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

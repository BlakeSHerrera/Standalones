#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, return TRUE if one of the first 4
elements in the array is a 9. The array length may be less than
4.
*/

int arrayFront9(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = arrayFront9(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 9, 3, 4]\n");
    correct += test((int[]){1, 2, 9, 3, 4}, 5, TRUE);
    total++;
    printf("Sent: [1, 2, 3, 4, 9]\n");
    correct += test((int[]){1, 2, 3, 4, 9}, 5, FALSE);
    total++;
    printf("Sent: [1, 2, 3, 4, 5]\n");
    correct += test((int[]){1, 2, 3, 4, 5}, 5, FALSE);
    total++;
    printf("Sent: [9, 2, 3]\n");
    correct += test((int[]){9, 2, 3}, 3, TRUE);
    total++;
    printf("Sent: [1, 9, 9]\n");
    correct += test((int[]){1, 9, 9}, 3, TRUE);
    total++;
    printf("Sent: [1, 2, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, FALSE);
    total++;
    printf("Sent: [1, 9]\n");
    correct += test((int[]){1, 9}, 2, TRUE);
    total++;
    printf("Sent: [5, 5]\n");
    correct += test((int[]){5, 5}, 2, FALSE);
    total++;
    printf("Sent: [2]\n");
    correct += test((int[]){2}, 1, FALSE);
    total++;
    printf("Sent: [9]\n");
    correct += test((int[]){9}, 1, TRUE);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, FALSE);
    total++;
    printf("Sent: [3, 9, 2, 3, 3]\n");
    correct += test((int[]){3, 9, 2, 3, 3}, 5, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

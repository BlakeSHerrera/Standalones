#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Count the number of "xx" in the given string. We'll say that
overlapping is allowed, so "xxx" contains 2 "xx".
*/

int countXX(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = countXX(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"abcxx\"\n");
    correct += test("abcxx", 1);
    total++;
    printf("Sent: \"xxx\"\n");
    correct += test("xxx", 2);
    total++;
    printf("Sent: \"xxxx\"\n");
    correct += test("xxxx", 3);
    total++;
    printf("Sent: \"abc\"\n");
    correct += test("abc", 0);
    total++;
    printf("Sent: \"Hello there\"\n");
    correct += test("Hello there", 0);
    total++;
    printf("Sent: \"Hexxo thxxe\"\n");
    correct += test("Hexxo thxxe", 2);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", 0);
    total++;
    printf("Sent: \"Kittens\"\n");
    correct += test("Kittens", 0);
    total++;
    printf("Sent: \"Kittensxxx\"\n");
    correct += test("Kittensxxx", 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a version where all the "x" have been
removed. Except an "x" at the very start or end should not be
removed.
*/

char * stringX(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = stringX(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"xxHxix\"\n");
    correct += test("xxHxix", "xHix");
    total++;
    printf("Sent: \"abxxxcd\"\n");
    correct += test("abxxxcd", "abcd");
    total++;
    printf("Sent: \"xabxxxcdx\"\n");
    correct += test("xabxxxcdx", "xabcdx");
    total++;
    printf("Sent: \"xKittenx\"\n");
    correct += test("xKittenx", "xKittenx");
    total++;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "Hello");
    total++;
    printf("Sent: \"xx\"\n");
    correct += test("xx", "xx");
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", "x");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

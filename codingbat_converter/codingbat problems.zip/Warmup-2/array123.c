#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, return TRUE if the sequence of numbers 1,
2, 3 appears in the array somewhere.
*/

int array123(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = array123(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 1, 2, 3, 1]\n");
    correct += test((int[]){1, 1, 2, 3, 1}, 5, TRUE);
    total++;
    printf("Sent: [1, 1, 2, 4, 1]\n");
    correct += test((int[]){1, 1, 2, 4, 1}, 5, FALSE);
    total++;
    printf("Sent: [1, 1, 2, 1, 2, 3]\n");
    correct += test((int[]){1, 1, 2, 1, 2, 3}, 6, TRUE);
    total++;
    printf("Sent: [1, 1, 2, 1, 2, 1]\n");
    correct += test((int[]){1, 1, 2, 1, 2, 1}, 6, FALSE);
    total++;
    printf("Sent: [1, 2, 3, 1, 2, 3]\n");
    correct += test((int[]){1, 2, 3, 1, 2, 3}, 6, TRUE);
    total++;
    printf("Sent: [1, 2, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, TRUE);
    total++;
    printf("Sent: [1, 1, 1]\n");
    correct += test((int[]){1, 1, 1}, 3, FALSE);
    total++;
    printf("Sent: [1, 2]\n");
    correct += test((int[]){1, 2}, 2, FALSE);
    total++;
    printf("Sent: [1]\n");
    correct += test((int[]){1}, 1, FALSE);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

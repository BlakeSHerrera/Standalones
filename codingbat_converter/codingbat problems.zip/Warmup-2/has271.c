#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, return TRUE if it contains a 2, 7, 1
pattern: a value, followed by the value plus 5, followed by the
value minus 1. Additionally the 271 counts even if the "1"
differs by 2 or less from the correct value.
*/

int has271(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = has271(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 7, 1]\n");
    correct += test((int[]){1, 2, 7, 1}, 4, TRUE);
    total++;
    printf("Sent: [1, 2, 8, 1]\n");
    correct += test((int[]){1, 2, 8, 1}, 4, FALSE);
    total++;
    printf("Sent: [2, 7, 1]\n");
    correct += test((int[]){2, 7, 1}, 3, TRUE);
    total++;
    printf("Sent: [3, 8, 2]\n");
    correct += test((int[]){3, 8, 2}, 3, TRUE);
    total++;
    printf("Sent: [2, 7, 3]\n");
    correct += test((int[]){2, 7, 3}, 3, TRUE);
    total++;
    printf("Sent: [2, 7, 4]\n");
    correct += test((int[]){2, 7, 4}, 3, FALSE);
    total++;
    printf("Sent: [2, 7, -1]\n");
    correct += test((int[]){2, 7, -1}, 3, TRUE);
    total++;
    printf("Sent: [2, 7, -2]\n");
    correct += test((int[]){2, 7, -2}, 3, FALSE);
    total++;
    printf("Sent: [4, 5, 3, 8, 0]\n");
    correct += test((int[]){4, 5, 3, 8, 0}, 5, TRUE);
    total++;
    printf("Sent: [2, 7, 5, 10, 4]\n");
    correct += test((int[]){2, 7, 5, 10, 4}, 5, TRUE);
    total++;
    printf("Sent: [2, 7, -2, 4, 9, 3]\n");
    correct += test((int[]){2, 7, -2, 4, 9, 3}, 6, TRUE);
    total++;
    printf("Sent: [2, 7, 5, 10, 1]\n");
    correct += test((int[]){2, 7, 5, 10, 1}, 5, FALSE);
    total++;
    printf("Sent: [2, 7, -2, 4, 10, 2]\n");
    correct += test((int[]){2, 7, -2, 4, 10, 2}, 6, FALSE);
    total++;
    printf("Sent: [1, 1, 4, 9, 0]\n");
    correct += test((int[]){1, 1, 4, 9, 0}, 5, FALSE);
    total++;
    printf("Sent: [1, 1, 4, 9, 4, 9, 2]\n");
    correct += test((int[]){1, 1, 4, 9, 4, 9, 2}, 7, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

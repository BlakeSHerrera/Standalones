#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string and a non-negative int n, we'll say that the front
of the string is the first 3 chars, or whatever is there if the
string is less than length 3. Return n copies of the front;
*/

char * frontTimes(char * str, int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int n, char * expected)
{
    char * returned = frontTimes(str, n);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Chocolate\", 2\n");
    correct += test("Chocolate", 2, "ChoCho");
    total++;
    printf("Sent: \"Chocolate\", 3\n");
    correct += test("Chocolate", 3, "ChoChoCho");
    total++;
    printf("Sent: \"Abc\", 3\n");
    correct += test("Abc", 3, "AbcAbcAbc");
    total++;
    printf("Sent: \"Ab\", 4\n");
    correct += test("Ab", 4, "AbAbAbAb");
    total++;
    printf("Sent: \"A\", 4\n");
    correct += test("A", 4, "AAAA");
    total++;
    printf("Sent: \"\", 4\n");
    correct += test("", 4, "");
    total++;
    printf("Sent: \"Abc\", 0\n");
    correct += test("Abc", 0, "");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return TRUE if the first instance of "x" in the
string is immediately followed by another "x".
*/

int doubleX(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = doubleX(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"axxbb\"\n");
    correct += test("axxbb", TRUE);
    total++;
    printf("Sent: \"axaxax\"\n");
    correct += test("axaxax", FALSE);
    total++;
    printf("Sent: \"xxxxx\"\n");
    correct += test("xxxxx", TRUE);
    total++;
    printf("Sent: \"xaxxx\"\n");
    correct += test("xaxxx", FALSE);
    total++;
    printf("Sent: \"aaaax\"\n");
    correct += test("aaaax", FALSE);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", FALSE);
    total++;
    printf("Sent: \"abc\"\n");
    correct += test("abc", FALSE);
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", FALSE);
    total++;
    printf("Sent: \"xx\"\n");
    correct += test("xx", TRUE);
    total++;
    printf("Sent: \"xax\"\n");
    correct += test("xax", FALSE);
    total++;
    printf("Sent: \"xaxx\"\n");
    correct += test("xaxx", FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

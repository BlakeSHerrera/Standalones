#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, return the number of times that two 6's
are next to each other in the array. Also count instances where
the second "6" is actually a 7.
*/

int array667(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = array667(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [6, 6, 2]\n");
    correct += test((int[]){6, 6, 2}, 3, 1);
    total++;
    printf("Sent: [6, 6, 2, 6]\n");
    correct += test((int[]){6, 6, 2, 6}, 4, 1);
    total++;
    printf("Sent: [6, 7, 2, 6]\n");
    correct += test((int[]){6, 7, 2, 6}, 4, 1);
    total++;
    printf("Sent: [6, 6, 2, 6, 7]\n");
    correct += test((int[]){6, 6, 2, 6, 7}, 5, 2);
    total++;
    printf("Sent: [1, 6, 3]\n");
    correct += test((int[]){1, 6, 3}, 3, 0);
    total++;
    printf("Sent: [6, 1]\n");
    correct += test((int[]){6, 1}, 2, 0);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, 0);
    total++;
    printf("Sent: [3, 6, 7, 6]\n");
    correct += test((int[]){3, 6, 7, 6}, 4, 1);
    total++;
    printf("Sent: [3, 6, 6, 7]\n");
    correct += test((int[]){3, 6, 6, 7}, 4, 2);
    total++;
    printf("Sent: [6, 3, 6, 6]\n");
    correct += test((int[]){6, 3, 6, 6}, 4, 1);
    total++;
    printf("Sent: [6, 7, 6, 6]\n");
    correct += test((int[]){6, 7, 6, 6}, 4, 2);
    total++;
    printf("Sent: [1, 2, 3, 5, 6]\n");
    correct += test((int[]){1, 2, 3, 5, 6}, 5, 0);
    total++;
    printf("Sent: [1, 2, 3, 6, 6]\n");
    correct += test((int[]){1, 2, 3, 6, 6}, 5, 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Suppose the string "yak" is unlucky. Given a string, return a
version where all the "yak" are removed, but the "a" can be any
char. The "yak" strings will not overlap.
*/

char * stringYak(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = stringYak(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"yakpak\"\n");
    correct += test("yakpak", "pak");
    total++;
    printf("Sent: \"pakyak\"\n");
    correct += test("pakyak", "pak");
    total++;
    printf("Sent: \"yak123ya\"\n");
    correct += test("yak123ya", "123ya");
    total++;
    printf("Sent: \"yak\"\n");
    correct += test("yak", "");
    total++;
    printf("Sent: \"yakxxxyak\"\n");
    correct += test("yakxxxyak", "xxx");
    total++;
    printf("Sent: \"HiyakHi\"\n");
    correct += test("HiyakHi", "HiHi");
    total++;
    printf("Sent: \"xxxyakyyyakzzz\"\n");
    correct += test("xxxyakyyyakzzz", "xxxyyzzz");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

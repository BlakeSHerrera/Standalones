#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return the count of the number of times that a
substring length 2 appears in the string and also as the last 2
chars of the string, so "hixxxhi" yields 1 (we won't count the
end substring).
*/

int last2(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = last2(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"hixxhi\"\n");
    correct += test("hixxhi", 1);
    total++;
    printf("Sent: \"xaxxaxaxx\"\n");
    correct += test("xaxxaxaxx", 1);
    total++;
    printf("Sent: \"axxxaaxx\"\n");
    correct += test("axxxaaxx", 2);
    total++;
    printf("Sent: \"xxaxxaxxaxx\"\n");
    correct += test("xxaxxaxxaxx", 3);
    total++;
    printf("Sent: \"xaxaxaxx\"\n");
    correct += test("xaxaxaxx", 0);
    total++;
    printf("Sent: \"xxxx\"\n");
    correct += test("xxxx", 2);
    total++;
    printf("Sent: \"13121312\"\n");
    correct += test("13121312", 1);
    total++;
    printf("Sent: \"11212\"\n");
    correct += test("11212", 1);
    total++;
    printf("Sent: \"13121311\"\n");
    correct += test("13121311", 0);
    total++;
    printf("Sent: \"1717171\"\n");
    correct += test("1717171", 2);
    total++;
    printf("Sent: \"hi\"\n");
    correct += test("hi", 0);
    total++;
    printf("Sent: \"h\"\n");
    correct += test("h", 0);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", 0);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

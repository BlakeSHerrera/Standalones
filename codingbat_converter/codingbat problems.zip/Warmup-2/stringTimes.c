#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string and a non-negative int n, return a larger string
that is n copies of the original string.
*/

char * stringTimes(char * str, int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int n, char * expected)
{
    char * returned = stringTimes(str, n);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hi\", 2\n");
    correct += test("Hi", 2, "HiHi");
    total++;
    printf("Sent: \"Hi\", 3\n");
    correct += test("Hi", 3, "HiHiHi");
    total++;
    printf("Sent: \"Hi\", 1\n");
    correct += test("Hi", 1, "Hi");
    total++;
    printf("Sent: \"Hi\", 0\n");
    correct += test("Hi", 0, "");
    total++;
    printf("Sent: \"Hi\", 5\n");
    correct += test("Hi", 5, "HiHiHiHiHi");
    total++;
    printf("Sent: \"Oh Boy!\", 2\n");
    correct += test("Oh Boy!", 2, "Oh Boy!Oh Boy!");
    total++;
    printf("Sent: \"x\", 4\n");
    correct += test("x", 4, "xxxx");
    total++;
    printf("Sent: \"\", 4\n");
    correct += test("", 4, "");
    total++;
    printf("Sent: \"code\", 2\n");
    correct += test("code", 2, "codecode");
    total++;
    printf("Sent: \"code\", 3\n");
    correct += test("code", 3, "codecodecode");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a new string made of 3 copies of the last
2 chars of the original string. The string length will be at
least 2.
*/

char * extraEnd(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = extraEnd(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "lololo");
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", "ababab");
    total++;
    printf("Sent: \"Hi\"\n");
    correct += test("Hi", "HiHiHi");
    total++;
    printf("Sent: \"Candy\"\n");
    correct += test("Candy", "dydydy");
    total++;
    printf("Sent: \"Code\"\n");
    correct += test("Code", "dedede");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

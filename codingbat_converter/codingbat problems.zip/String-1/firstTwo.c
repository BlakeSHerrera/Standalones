#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return the string made of its first two chars, so
the char * "Hello" yields "He". If the string is shorter than
length 2, return whatever there is, so "X" yields "X", and the
empty string "" yields the empty string "". Note that
str.length() returns the length of a string.
*/

char * firstTwo(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = firstTwo(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "He");
    total++;
    printf("Sent: \"abcdefg\"\n");
    correct += test("abcdefg", "ab");
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", "ab");
    total++;
    printf("Sent: \"a\"\n");
    correct += test("a", "a");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"Kitten\"\n");
    correct += test("Kitten", "Ki");
    total++;
    printf("Sent: \"hi\"\n");
    correct += test("hi", "hi");
    total++;
    printf("Sent: \"hiya\"\n");
    correct += test("hiya", "hi");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, if one or both of the first 2 chars is 'x',
return the string without those 'x' chars, and otherwise return
the string unchanged. This is a little harder than it looks.
*/

char * withoutX2(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = withoutX2(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"xHi\"\n");
    correct += test("xHi", "Hi");
    total++;
    printf("Sent: \"Hxi\"\n");
    correct += test("Hxi", "Hi");
    total++;
    printf("Sent: \"Hi\"\n");
    correct += test("Hi", "Hi");
    total++;
    printf("Sent: \"xxHi\"\n");
    correct += test("xxHi", "Hi");
    total++;
    printf("Sent: \"Hix\"\n");
    correct += test("Hix", "Hix");
    total++;
    printf("Sent: \"xaxb\"\n");
    correct += test("xaxb", "axb");
    total++;
    printf("Sent: \"xx\"\n");
    correct += test("xx", "");
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", "");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "Hello");
    total++;
    printf("Sent: \"Hexllo\"\n");
    correct += test("Hexllo", "Hexllo");
    total++;
    printf("Sent: \"xHxllo\"\n");
    correct += test("xHxllo", "Hxllo");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

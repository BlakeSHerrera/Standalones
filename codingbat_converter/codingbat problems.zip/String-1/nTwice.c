#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string and an int n, return a string made of the first
and last n chars from the string. The string length will be at
least n.
*/

char * nTwice(char * str, int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int n, char * expected)
{
    char * returned = nTwice(str, n);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\", 2\n");
    correct += test("Hello", 2, "Helo");
    total++;
    printf("Sent: \"Chocolate\", 3\n");
    correct += test("Chocolate", 3, "Choate");
    total++;
    printf("Sent: \"Chocolate\", 1\n");
    correct += test("Chocolate", 1, "Ce");
    total++;
    printf("Sent: \"Chocolate\", 0\n");
    correct += test("Chocolate", 0, "");
    total++;
    printf("Sent: \"Hello\", 4\n");
    correct += test("Hello", 4, "Hellello");
    total++;
    printf("Sent: \"Code\", 4\n");
    correct += test("Code", 4, "CodeCode");
    total++;
    printf("Sent: \"Code\", 2\n");
    correct += test("Code", 2, "Code");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given two strings, append them together (known as
"concatenation") and return the result. However, if the strings
are different lengths, omit chars from the longer string so it is
the same length as the shorter string. So "Hello" and "Hi" yield
"loHi". The strings may be any length.
*/

char * minCat(char * a, char * b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * a, char * b, char * expected)
{
    char * returned = minCat(a, b);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\", \"Hi\"\n");
    correct += test("Hello", "Hi", "loHi");
    total++;
    printf("Sent: \"Hello\", \"java\"\n");
    correct += test("Hello", "java", "ellojava");
    total++;
    printf("Sent: \"java\", \"Hello\"\n");
    correct += test("java", "Hello", "javaello");
    total++;
    printf("Sent: \"abc\", \"x\"\n");
    correct += test("abc", "x", "cx");
    total++;
    printf("Sent: \"x\", \"abc\"\n");
    correct += test("x", "abc", "xc");
    total++;
    printf("Sent: \"abc\", \"\"\n");
    correct += test("abc", "", "");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

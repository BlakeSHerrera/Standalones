#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given two strings, a and b, return the result of putting them
together in the order abba, e.g. "Hi" and "Bye" returns
"HiByeByeHi".
*/

char * makeAbba(char * a, char * b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * a, char * b, char * expected)
{
    char * returned = makeAbba(a, b);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hi\", \"Bye\"\n");
    correct += test("Hi", "Bye", "HiByeByeHi");
    total++;
    printf("Sent: \"Yo\", \"Alice\"\n");
    correct += test("Yo", "Alice", "YoAliceAliceYo");
    total++;
    printf("Sent: \"What\", \"Up\"\n");
    correct += test("What", "Up", "WhatUpUpWhat");
    total++;
    printf("Sent: \"aaa\", \"bbb\"\n");
    correct += test("aaa", "bbb", "aaabbbbbbaaa");
    total++;
    printf("Sent: \"x\", \"y\"\n");
    correct += test("x", "y", "xyyx");
    total++;
    printf("Sent: \"x\", \"\"\n");
    correct += test("x", "", "xx");
    total++;
    printf("Sent: \"\", \"y\"\n");
    correct += test("", "y", "yy");
    total++;
    printf("Sent: \"Bo\", \"Ya\"\n");
    correct += test("Bo", "Ya", "BoYaYaBo");
    total++;
    printf("Sent: \"Ya\", \"Ya\"\n");
    correct += test("Ya", "Ya", "YaYaYaYa");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

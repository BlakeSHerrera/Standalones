#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 strings, return their concatenation, except omit the
first char of each. The strings will be at least length 1.
*/

char * nonStart(char * a, char * b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * a, char * b, char * expected)
{
    char * returned = nonStart(a, b);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\", \"There\"\n");
    correct += test("Hello", "There", "ellohere");
    total++;
    printf("Sent: \"java\", \"code\"\n");
    correct += test("java", "code", "avaode");
    total++;
    printf("Sent: \"shotl\", \"java\"\n");
    correct += test("shotl", "java", "hotlava");
    total++;
    printf("Sent: \"ab\", \"xy\"\n");
    correct += test("ab", "xy", "by");
    total++;
    printf("Sent: \"ab\", \"x\"\n");
    correct += test("ab", "x", "b");
    total++;
    printf("Sent: \"x\", \"ac\"\n");
    correct += test("x", "ac", "c");
    total++;
    printf("Sent: \"a\", \"x\"\n");
    correct += test("a", "x", "");
    total++;
    printf("Sent: \"kit\", \"kat\"\n");
    correct += test("kit", "kat", "itat");
    total++;
    printf("Sent: \"mart\", \"dart\"\n");
    correct += test("mart", "dart", "artart");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a version without the first 2 chars.
Except keep the first char if it is 'a' and keep the second char
if it is 'b'. The string may be any length. Harder than it looks.
*/

char * deFront(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = deFront(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "llo");
    total++;
    printf("Sent: \"java\"\n");
    correct += test("java", "va");
    total++;
    printf("Sent: \"away\"\n");
    correct += test("away", "aay");
    total++;
    printf("Sent: \"axy\"\n");
    correct += test("axy", "ay");
    total++;
    printf("Sent: \"abc\"\n");
    correct += test("abc", "abc");
    total++;
    printf("Sent: \"xby\"\n");
    correct += test("xby", "by");
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", "ab");
    total++;
    printf("Sent: \"ax\"\n");
    correct += test("ax", "a");
    total++;
    printf("Sent: \"axb\"\n");
    correct += test("axb", "ab");
    total++;
    printf("Sent: \"aaa\"\n");
    correct += test("aaa", "aa");
    total++;
    printf("Sent: \"xbc\"\n");
    correct += test("xbc", "bc");
    total++;
    printf("Sent: \"bbb\"\n");
    correct += test("bbb", "bb");
    total++;
    printf("Sent: \"bazz\"\n");
    correct += test("bazz", "zz");
    total++;
    printf("Sent: \"ba\"\n");
    correct += test("ba", "");
    total++;
    printf("Sent: \"abxyz\"\n");
    correct += test("abxyz", "abxyz");
    total++;
    printf("Sent: \"hi\"\n");
    correct += test("hi", "");
    total++;
    printf("Sent: \"his\"\n");
    correct += test("his", "s");
    total++;
    printf("Sent: \"xz\"\n");
    correct += test("xz", "");
    total++;
    printf("Sent: \"zzz\"\n");
    correct += test("zzz", "z");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string name, e.g. "Bob", return a greeting of the form
"Hello Bob!".
*/

char * helloName(char * name)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * name, char * expected)
{
    char * returned = helloName(name);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Bob\"\n");
    correct += test("Bob", "Hello Bob!");
    total++;
    printf("Sent: \"Alice\"\n");
    correct += test("Alice", "Hello Alice!");
    total++;
    printf("Sent: \"X\"\n");
    correct += test("X", "Hello X!");
    total++;
    printf("Sent: \"Dolly\"\n");
    correct += test("Dolly", "Hello Dolly!");
    total++;
    printf("Sent: \"Alpha\"\n");
    correct += test("Alpha", "Hello Alpha!");
    total++;
    printf("Sent: \"Omega\"\n");
    correct += test("Omega", "Hello Omega!");
    total++;
    printf("Sent: \"Goodbye\"\n");
    correct += test("Goodbye", "Hello Goodbye!");
    total++;
    printf("Sent: \"ho ho ho\"\n");
    correct += test("ho ho ho", "Hello ho ho ho!");
    total++;
    printf("Sent: \"xyz!\"\n");
    correct += test("xyz!", "Hello xyz!!");
    total++;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "Hello Hello!");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

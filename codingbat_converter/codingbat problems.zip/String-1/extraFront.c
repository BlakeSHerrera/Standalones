#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a new string made of 3 copies of the first
2 chars of the original string. The string may be any length. If
there are fewer than 2 chars, use whatever is there.
*/

char * extraFront(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = extraFront(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "HeHeHe");
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", "ababab");
    total++;
    printf("Sent: \"H\"\n");
    correct += test("H", "HHH");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"Candy\"\n");
    correct += test("Candy", "CaCaCa");
    total++;
    printf("Sent: \"Code\"\n");
    correct += test("Code", "CoCoCo");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

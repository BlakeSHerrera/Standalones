#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 strings, a and b, return a new string made of the first
char of a and the last char of b, so "yo" and "java" yields "ya".
If either string is length 0, use '@' for its missing char.
*/

char * lastChars(char * a, char * b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * a, char * b, char * expected)
{
    char * returned = lastChars(a, b);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"last\", \"chars\"\n");
    correct += test("last", "chars", "ls");
    total++;
    printf("Sent: \"yo\", \"java\"\n");
    correct += test("yo", "java", "ya");
    total++;
    printf("Sent: \"hi\", \"\"\n");
    correct += test("hi", "", "h@");
    total++;
    printf("Sent: \"\", \"hello\"\n");
    correct += test("", "hello", "@o");
    total++;
    printf("Sent: \"\", \"\"\n");
    correct += test("", "", "@@");
    total++;
    printf("Sent: \"kitten\", \"hi\"\n");
    correct += test("kitten", "hi", "ki");
    total++;
    printf("Sent: \"k\", \"zip\"\n");
    correct += test("k", "zip", "kp");
    total++;
    printf("Sent: \"kitten\", \"\"\n");
    correct += test("kitten", "", "k@");
    total++;
    printf("Sent: \"kitten\", \"zip\"\n");
    correct += test("kitten", "zip", "kp");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

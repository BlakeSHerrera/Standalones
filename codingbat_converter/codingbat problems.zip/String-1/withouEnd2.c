#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a version without both the first and last
char of the string. The string may be any length, including 0.
*/

char * withouEnd2(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = withouEnd2(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "ell");
    total++;
    printf("Sent: \"abc\"\n");
    correct += test("abc", "b");
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", "");
    total++;
    printf("Sent: \"a\"\n");
    correct += test("a", "");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"coldy\"\n");
    correct += test("coldy", "old");
    total++;
    printf("Sent: \"java code\"\n");
    correct += test("java code", "ava cod");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

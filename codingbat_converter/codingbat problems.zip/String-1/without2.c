#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, if a length 2 substring appears at both its
beginning and end, return a string without the substring at the
beginning, so "HelloHe" yields "lloHe". The substring may overlap
with itself, so "Hi" yields "". Otherwise, return the original
string unchanged.
*/

char * without2(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = without2(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"HelloHe\"\n");
    correct += test("HelloHe", "lloHe");
    total++;
    printf("Sent: \"HelloHi\"\n");
    correct += test("HelloHi", "HelloHi");
    total++;
    printf("Sent: \"Hi\"\n");
    correct += test("Hi", "");
    total++;
    printf("Sent: \"Chocolate\"\n");
    correct += test("Chocolate", "Chocolate");
    total++;
    printf("Sent: \"xxx\"\n");
    correct += test("xxx", "x");
    total++;
    printf("Sent: \"xx\"\n");
    correct += test("xx", "");
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", "x");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"Fruits\"\n");
    correct += test("Fruits", "Fruits");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

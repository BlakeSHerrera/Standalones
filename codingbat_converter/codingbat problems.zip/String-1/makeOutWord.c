#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an "out" string length 4, such as "<<>>", and a word,
return a new string where the word is in the middle of the out
string, e.g. "<<word>>". Note: use str.substring(i, j) to extract
the char * starting at index i and going up to but not including
index j.
*/

char * makeOutWord(char * out, char * word)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * out, char * word, char * expected)
{
    char * returned = makeOutWord(out, word);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"<<>>\", \"Yay\"\n");
    correct += test("<<>>", "Yay", "<<Yay>>");
    total++;
    printf("Sent: \"<<>>\", \"WooHoo\"\n");
    correct += test("<<>>", "WooHoo", "<<WooHoo>>");
    total++;
    printf("Sent: \"[[]]\", \"word\"\n");
    correct += test("(int[]){(int[]){}, 1}, 1", "word", "ialloc((int[]){ialloc((int[]){word}), 1}), 1");
    total++;
    printf("Sent: \"HHoo\", \"Hello\"\n");
    correct += test("HHoo", "Hello", "HHHellooo");
    total++;
    printf("Sent: \"abyz\", \"YAY\"\n");
    correct += test("abyz", "YAY", "abYAYyz");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

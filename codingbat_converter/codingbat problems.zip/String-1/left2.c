#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a "rotated left 2" version where the first
2 chars are moved to the end. The string length will be at least
2.
*/

char * left2(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = left2(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "lloHe");
    total++;
    printf("Sent: \"java\"\n");
    correct += test("java", "vaja");
    total++;
    printf("Sent: \"Hi\"\n");
    correct += test("Hi", "Hi");
    total++;
    printf("Sent: \"code\"\n");
    correct += test("code", "deco");
    total++;
    printf("Sent: \"cat\"\n");
    correct += test("cat", "tca");
    total++;
    printf("Sent: \"12345\"\n");
    correct += test("12345", "34512");
    total++;
    printf("Sent: \"Chocolate\"\n");
    correct += test("Chocolate", "ocolateCh");
    total++;
    printf("Sent: \"bricks\"\n");
    correct += test("bricks", "icksbr");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

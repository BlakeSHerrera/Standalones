#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a "rotated right 2" version where the last
2 chars are moved to the start. The string length will be at
least 2.
*/

char * right2(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = right2(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "loHel");
    total++;
    printf("Sent: \"java\"\n");
    correct += test("java", "vaja");
    total++;
    printf("Sent: \"Hi\"\n");
    correct += test("Hi", "Hi");
    total++;
    printf("Sent: \"code\"\n");
    correct += test("code", "deco");
    total++;
    printf("Sent: \"cat\"\n");
    correct += test("cat", "atc");
    total++;
    printf("Sent: \"12345\"\n");
    correct += test("12345", "45123");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

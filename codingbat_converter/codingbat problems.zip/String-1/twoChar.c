#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string and an index, return a string length 2 starting at
the given index. If the index is too big or too small to define a
string length 2, use the first 2 chars. The string length will be
at least 2.
*/

char * twoChar(char * str, int index)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int index, char * expected)
{
    char * returned = twoChar(str, index);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"java\", 0\n");
    correct += test("java", 0, "ja");
    total++;
    printf("Sent: \"java\", 2\n");
    correct += test("java", 2, "va");
    total++;
    printf("Sent: \"java\", 3\n");
    correct += test("java", 3, "ja");
    total++;
    printf("Sent: \"java\", 4\n");
    correct += test("java", 4, "ja");
    total++;
    printf("Sent: \"java\", -1\n");
    correct += test("java", -1, "ja");
    total++;
    printf("Sent: \"Hello\", 0\n");
    correct += test("Hello", 0, "He");
    total++;
    printf("Sent: \"Hello\", 1\n");
    correct += test("Hello", 1, "el");
    total++;
    printf("Sent: \"Hello\", 99\n");
    correct += test("Hello", 99, "He");
    total++;
    printf("Sent: \"Hello\", 3\n");
    correct += test("Hello", 3, "lo");
    total++;
    printf("Sent: \"Hello\", 4\n");
    correct += test("Hello", 4, "He");
    total++;
    printf("Sent: \"Hello\", 5\n");
    correct += test("Hello", 5, "He");
    total++;
    printf("Sent: \"Hello\", -7\n");
    correct += test("Hello", -7, "He");
    total++;
    printf("Sent: \"Hello\", 6\n");
    correct += test("Hello", 6, "He");
    total++;
    printf("Sent: \"Hello\", -1\n");
    correct += test("Hello", -1, "He");
    total++;
    printf("Sent: \"yay\", 0\n");
    correct += test("yay", 0, "ya");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

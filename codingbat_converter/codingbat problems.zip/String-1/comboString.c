#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 strings, a and b, return a string of the form
short+long+short, with the shorter string on the outside and the
longer string on the inside. The strings will not be the same
length, but they may be empty (length 0).
*/

char * comboString(char * a, char * b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * a, char * b, char * expected)
{
    char * returned = comboString(a, b);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\", \"hi\"\n");
    correct += test("Hello", "hi", "hiHellohi");
    total++;
    printf("Sent: \"hi\", \"Hello\"\n");
    correct += test("hi", "Hello", "hiHellohi");
    total++;
    printf("Sent: \"aaa\", \"b\"\n");
    correct += test("aaa", "b", "baaab");
    total++;
    printf("Sent: \"b\", \"aaa\"\n");
    correct += test("b", "aaa", "baaab");
    total++;
    printf("Sent: \"aaa\", \"\"\n");
    correct += test("aaa", "", "aaa");
    total++;
    printf("Sent: \"\", \"bb\"\n");
    correct += test("", "bb", "bb");
    total++;
    printf("Sent: \"aaa\", \"1234\"\n");
    correct += test("aaa", "1234", "aaa1234aaa");
    total++;
    printf("Sent: \"aaa\", \"bb\"\n");
    correct += test("aaa", "bb", "bbaaabb");
    total++;
    printf("Sent: \"a\", \"bb\"\n");
    correct += test("a", "bb", "abba");
    total++;
    printf("Sent: \"bb\", \"a\"\n");
    correct += test("bb", "a", "abba");
    total++;
    printf("Sent: \"xyz\", \"ab\"\n");
    correct += test("xyz", "ab", "abxyzab");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, if the string begins with "red" or "blue" return
that color string, otherwise return the empty string.
*/

char * seeColor(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = seeColor(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"redxx\"\n");
    correct += test("redxx", "red");
    total++;
    printf("Sent: \"xxred\"\n");
    correct += test("xxred", "");
    total++;
    printf("Sent: \"blueTimes\"\n");
    correct += test("blueTimes", "blue");
    total++;
    printf("Sent: \"NoColor\"\n");
    correct += test("NoColor", "");
    total++;
    printf("Sent: \"red\"\n");
    correct += test("red", "red");
    total++;
    printf("Sent: \"re\"\n");
    correct += test("re", "");
    total++;
    printf("Sent: \"blu\"\n");
    correct += test("blu", "");
    total++;
    printf("Sent: \"blue\"\n");
    correct += test("blue", "blue");
    total++;
    printf("Sent: \"a\"\n");
    correct += test("a", "");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"xyzred\"\n");
    correct += test("xyzred", "");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

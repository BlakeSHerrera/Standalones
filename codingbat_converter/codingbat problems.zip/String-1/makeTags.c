#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
The web is built with HTML strings like "<i>Yay</i>" which draws
Yay as italic text. In this example, the "i" tag makes <i> and
</i> which surround the word "Yay". Given tag and word strings,
create the HTML string with tags around the word, e.g.
"<i>Yay</i>".
*/

char * makeTags(char * tag, char * word)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * tag, char * word, char * expected)
{
    char * returned = makeTags(tag, word);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"i\", \"Yay\"\n");
    correct += test("i", "Yay", "<i>Yay</i>");
    total++;
    printf("Sent: \"i\", \"Hello\"\n");
    correct += test("i", "Hello", "<i>Hello</i>");
    total++;
    printf("Sent: \"cite\", \"Yay\"\n");
    correct += test("cite", "Yay", "<cite>Yay</cite>");
    total++;
    printf("Sent: \"address\", \"here\"\n");
    correct += test("address", "here", "<address>here</address>");
    total++;
    printf("Sent: \"body\", \"Heart\"\n");
    correct += test("body", "Heart", "<body>Heart</body>");
    total++;
    printf("Sent: \"i\", \"i\"\n");
    correct += test("i", "i", "<i>i</i>");
    total++;
    printf("Sent: \"i\", \"\"\n");
    correct += test("i", "", "<i></i>");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

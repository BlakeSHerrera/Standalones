#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return TRUE if it ends in "ly".
*/

int endsLy(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = endsLy(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"oddly\"\n");
    correct += test("oddly", TRUE);
    total++;
    printf("Sent: \"y\"\n");
    correct += test("y", FALSE);
    total++;
    printf("Sent: \"oddy\"\n");
    correct += test("oddy", FALSE);
    total++;
    printf("Sent: \"oddl\"\n");
    correct += test("oddl", FALSE);
    total++;
    printf("Sent: \"olydd\"\n");
    correct += test("olydd", FALSE);
    total++;
    printf("Sent: \"ly\"\n");
    correct += test("ly", TRUE);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", FALSE);
    total++;
    printf("Sent: \"FALSEy\"\n");
    correct += test("FALSEy", FALSE);
    total++;
    printf("Sent: \"evenly\"\n");
    correct += test("evenly", TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

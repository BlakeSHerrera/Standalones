#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a version without the first and last char,
so "Hello" yields "ell". The string length will be at least 2.
*/

char * withoutEnd(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = withoutEnd(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "ell");
    total++;
    printf("Sent: \"java\"\n");
    correct += test("java", "av");
    total++;
    printf("Sent: \"coding\"\n");
    correct += test("coding", "odin");
    total++;
    printf("Sent: \"code\"\n");
    correct += test("code", "od");
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", "");
    total++;
    printf("Sent: \"Chocolate!\"\n");
    correct += test("Chocolate!", "hocolate");
    total++;
    printf("Sent: \"kitten\"\n");
    correct += test("kitten", "itte");
    total++;
    printf("Sent: \"woohoo\"\n");
    correct += test("woohoo", "ooho");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

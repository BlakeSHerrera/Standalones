#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string of even length, return a string made of the middle
two chars, so the string "string" yields "ri". The string length
will be at least 2.
*/

char * middleTwo(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = middleTwo(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"string\"\n");
    correct += test("string", "ri");
    total++;
    printf("Sent: \"code\"\n");
    correct += test("code", "od");
    total++;
    printf("Sent: \"Practice\"\n");
    correct += test("Practice", "ct");
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", "ab");
    total++;
    printf("Sent: \"0123456789\"\n");
    correct += test("0123456789", "45");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

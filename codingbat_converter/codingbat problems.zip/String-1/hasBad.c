#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return TRUE if "bad" appears starting at index 0
or 1 in the string, such as with "badxxx" or "xbadxx" but not
"xxbadxx". The string may be any length, including 0. Note: use
.equals() to compare 2 strings.
*/

int hasBad(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = hasBad(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"badxx\"\n");
    correct += test("badxx", TRUE);
    total++;
    printf("Sent: \"xbadxx\"\n");
    correct += test("xbadxx", TRUE);
    total++;
    printf("Sent: \"xxbadxx\"\n");
    correct += test("xxbadxx", FALSE);
    total++;
    printf("Sent: \"code\"\n");
    correct += test("code", FALSE);
    total++;
    printf("Sent: \"bad\"\n");
    correct += test("bad", TRUE);
    total++;
    printf("Sent: \"ba\"\n");
    correct += test("ba", FALSE);
    total++;
    printf("Sent: \"xba\"\n");
    correct += test("xba", FALSE);
    total++;
    printf("Sent: \"xbad\"\n");
    correct += test("xbad", TRUE);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", FALSE);
    total++;
    printf("Sent: \"badyy\"\n");
    correct += test("badyy", TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

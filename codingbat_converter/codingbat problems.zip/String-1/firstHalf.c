#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string of even length, return the first half. So the
string "WooHoo" yields "Woo".
*/

char * firstHalf(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = firstHalf(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"WooHoo\"\n");
    correct += test("WooHoo", "Woo");
    total++;
    printf("Sent: \"HelloThere\"\n");
    correct += test("HelloThere", "Hello");
    total++;
    printf("Sent: \"abcdef\"\n");
    correct += test("abcdef", "abc");
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", "a");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"0123456789\"\n");
    correct += test("0123456789", "01234");
    total++;
    printf("Sent: \"kitten\"\n");
    correct += test("kitten", "kit");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

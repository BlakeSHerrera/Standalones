#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, if the first or last chars are 'x', return the
string without those 'x' chars, and otherwise return the string
unchanged.
*/

char * withoutX(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = withoutX(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"xHix\"\n");
    correct += test("xHix", "Hi");
    total++;
    printf("Sent: \"xHi\"\n");
    correct += test("xHi", "Hi");
    total++;
    printf("Sent: \"Hxix\"\n");
    correct += test("Hxix", "Hxi");
    total++;
    printf("Sent: \"Hi\"\n");
    correct += test("Hi", "Hi");
    total++;
    printf("Sent: \"xxHi\"\n");
    correct += test("xxHi", "xHi");
    total++;
    printf("Sent: \"Hix\"\n");
    correct += test("Hix", "Hi");
    total++;
    printf("Sent: \"xaxbx\"\n");
    correct += test("xaxbx", "axb");
    total++;
    printf("Sent: \"xx\"\n");
    correct += test("xx", "");
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", "");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "Hello");
    total++;
    printf("Sent: \"Hexllo\"\n");
    correct += test("Hexllo", "Hexllo");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string and a second "word" string, we'll say that the
word matches the string if it appears at the front of the string,
except its first char does not need to match exactly. On a match,
return the front of the string, or otherwise return the empty
string. So, so with the string "hippo" the word "hi" returns "hi"
and "xip" returns "hip". The word will be at least length 1.
*/

char * startWord(char * str, char * word)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * word, char * expected)
{
    char * returned = startWord(str, word);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"hippo\", \"hi\"\n");
    correct += test("hippo", "hi", "hi");
    total++;
    printf("Sent: \"hippo\", \"xip\"\n");
    correct += test("hippo", "xip", "hip");
    total++;
    printf("Sent: \"hippo\", \"i\"\n");
    correct += test("hippo", "i", "h");
    total++;
    printf("Sent: \"hippo\", \"ix\"\n");
    correct += test("hippo", "ix", "");
    total++;
    printf("Sent: \"h\", \"ix\"\n");
    correct += test("h", "ix", "");
    total++;
    printf("Sent: \"\", \"i\"\n");
    correct += test("", "i", "");
    total++;
    printf("Sent: \"hip\", \"zi\"\n");
    correct += test("hip", "zi", "hi");
    total++;
    printf("Sent: \"hip\", \"zip\"\n");
    correct += test("hip", "zip", "hip");
    total++;
    printf("Sent: \"hip\", \"zig\"\n");
    correct += test("hip", "zig", "");
    total++;
    printf("Sent: \"h\", \"z\"\n");
    correct += test("h", "z", "h");
    total++;
    printf("Sent: \"hippo\", \"xippo\"\n");
    correct += test("hippo", "xippo", "hippo");
    total++;
    printf("Sent: \"hippo\", \"xyz\"\n");
    correct += test("hippo", "xyz", "");
    total++;
    printf("Sent: \"hippo\", \"hip\"\n");
    correct += test("hippo", "hip", "hip");
    total++;
    printf("Sent: \"kitten\", \"cit\"\n");
    correct += test("kitten", "cit", "kit");
    total++;
    printf("Sent: \"kit\", \"cit\"\n");
    correct += test("kit", "cit", "kit");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a string length 1 from its front, unless
front is FALSE, in which case return a string length 1 from its
back. The string will be non-empty.
*/

char * theEnd(char * str, int front)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int front, char * expected)
{
    char * returned = theEnd(str, front);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\", TRUE\n");
    correct += test("Hello", TRUE, "H");
    total++;
    printf("Sent: \"Hello\", FALSE\n");
    correct += test("Hello", FALSE, "o");
    total++;
    printf("Sent: \"oh\", TRUE\n");
    correct += test("oh", TRUE, "o");
    total++;
    printf("Sent: \"oh\", FALSE\n");
    correct += test("oh", FALSE, "h");
    total++;
    printf("Sent: \"x\", TRUE\n");
    correct += test("x", TRUE, "x");
    total++;
    printf("Sent: \"x\", FALSE\n");
    correct += test("x", FALSE, "x");
    total++;
    printf("Sent: \"java\", TRUE\n");
    correct += test("java", TRUE, "j");
    total++;
    printf("Sent: \"chocolate\", FALSE\n");
    correct += test("chocolate", FALSE, "e");
    total++;
    printf("Sent: \"1234\", TRUE\n");
    correct += test("1234", TRUE, "1");
    total++;
    printf("Sent: \"code\", FALSE\n");
    correct += test("code", FALSE, "e");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given two strings, append them together (known as
"concatenation") and return the result. However, if the
concatenation creates a double-char, then omit one of the chars,
so "abc" and "cat" yields "abcat".
*/

char * conCat(char * a, char * b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * a, char * b, char * expected)
{
    char * returned = conCat(a, b);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"abc\", \"cat\"\n");
    correct += test("abc", "cat", "abcat");
    total++;
    printf("Sent: \"dog\", \"cat\"\n");
    correct += test("dog", "cat", "dogcat");
    total++;
    printf("Sent: \"abc\", \"\"\n");
    correct += test("abc", "", "abc");
    total++;
    printf("Sent: \"\", \"cat\"\n");
    correct += test("", "cat", "cat");
    total++;
    printf("Sent: \"pig\", \"g\"\n");
    correct += test("pig", "g", "pig");
    total++;
    printf("Sent: \"pig\", \"doggy\"\n");
    correct += test("pig", "doggy", "pigdoggy");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

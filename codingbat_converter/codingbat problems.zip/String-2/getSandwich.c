#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
A sandwich is two pieces of bread with something in between.
Return the string that is between the first and last appearance
of "bread" in the given string, or return the empty string "" if
there are not two pieces of bread.
*/

char * getSandwich(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = getSandwich(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"breadjambread\"\n");
    correct += test("breadjambread", "jam");
    total++;
    printf("Sent: \"xxbreadjambreadyy\"\n");
    correct += test("xxbreadjambreadyy", "jam");
    total++;
    printf("Sent: \"xxbreadyy\"\n");
    correct += test("xxbreadyy", "");
    total++;
    printf("Sent: \"xxbreadbreadjambreadyy\"\n");
    correct += test("xxbreadbreadjambreadyy", "breadjam");
    total++;
    printf("Sent: \"breadAbread\"\n");
    correct += test("breadAbread", "A");
    total++;
    printf("Sent: \"breadbread\"\n");
    correct += test("breadbread", "");
    total++;
    printf("Sent: \"abcbreaz\"\n");
    correct += test("abcbreaz", "");
    total++;
    printf("Sent: \"xyz\"\n");
    correct += test("xyz", "");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"breadbreaxbread\"\n");
    correct += test("breadbreaxbread", "breax");
    total++;
    printf("Sent: \"breaxbreadybread\"\n");
    correct += test("breaxbreadybread", "y");
    total++;
    printf("Sent: \"breadbreadbreadbread\"\n");
    correct += test("breadbreadbreadbread", "breadbread");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Look for patterns like "zip" and "zap" in the string -- length-3,
starting with 'z' and ending with 'p'. Return a string where for
all such words, the middle letter is gone, so "zipXzap" yields
"zpXzp".
*/

char * zipZap(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = zipZap(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"zipXzap\"\n");
    correct += test("zipXzap", "zpXzp");
    total++;
    printf("Sent: \"zopzop\"\n");
    correct += test("zopzop", "zpzp");
    total++;
    printf("Sent: \"zzzopzop\"\n");
    correct += test("zzzopzop", "zzzpzp");
    total++;
    printf("Sent: \"zibzap\"\n");
    correct += test("zibzap", "zibzp");
    total++;
    printf("Sent: \"zip\"\n");
    correct += test("zip", "zp");
    total++;
    printf("Sent: \"zi\"\n");
    correct += test("zi", "zi");
    total++;
    printf("Sent: \"z\"\n");
    correct += test("z", "z");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"zzp\"\n");
    correct += test("zzp", "zp");
    total++;
    printf("Sent: \"abcppp\"\n");
    correct += test("abcppp", "abcppp");
    total++;
    printf("Sent: \"azbcppp\"\n");
    correct += test("azbcppp", "azbcppp");
    total++;
    printf("Sent: \"azbcpzpp\"\n");
    correct += test("azbcpzpp", "azbcpzp");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string and a non-empty word string, return a string made
of each char just before and just after every appearance of the
word in the string. Ignore cases where there is no char before or
after the word, and a char may be included twice if it is between
two words.
*/

char * wordEnds(char * str, char * word)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * word, char * expected)
{
    char * returned = wordEnds(str, word);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"abcXY123XYijk\", \"XY\"\n");
    correct += test("abcXY123XYijk", "XY", "c13i");
    total++;
    printf("Sent: \"XY123XY\", \"XY\"\n");
    correct += test("XY123XY", "XY", "13");
    total++;
    printf("Sent: \"XY1XY\", \"XY\"\n");
    correct += test("XY1XY", "XY", "11");
    total++;
    printf("Sent: \"XYXY\", \"XY\"\n");
    correct += test("XYXY", "XY", "XY");
    total++;
    printf("Sent: \"XY\", \"XY\"\n");
    correct += test("XY", "XY", "");
    total++;
    printf("Sent: \"Hi\", \"XY\"\n");
    correct += test("Hi", "XY", "");
    total++;
    printf("Sent: \"\", \"XY\"\n");
    correct += test("", "XY", "");
    total++;
    printf("Sent: \"abc1xyz1i1j\", \"1\"\n");
    correct += test("abc1xyz1i1j", "1", "cxziij");
    total++;
    printf("Sent: \"abc1xyz1\", \"1\"\n");
    correct += test("abc1xyz1", "1", "cxz");
    total++;
    printf("Sent: \"abc1xyz11\", \"1\"\n");
    correct += test("abc1xyz11", "1", "cxz11");
    total++;
    printf("Sent: \"abc1xyz1abc\", \"abc\"\n");
    correct += test("abc1xyz1abc", "abc", "11");
    total++;
    printf("Sent: \"abc1xyz1abc\", \"b\"\n");
    correct += test("abc1xyz1abc", "b", "acac");
    total++;
    printf("Sent: \"abc1abc1abc\", \"abc\"\n");
    correct += test("abc1abc1abc", "abc", "1111");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

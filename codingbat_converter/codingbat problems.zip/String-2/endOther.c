#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given two strings, return TRUE if either of the strings appears
at the very end of the other string, ignoring upper/lower case
differences (in other words, the computation should not be "case
sensitive"). Note:  str.toLowerCase() returns the lowercase
version of a string.
*/

int endOther(char * a, char * b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * a, char * b, int expected)
{
    int returned = endOther(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hiabc\", \"abc\"\n");
    correct += test("Hiabc", "abc", TRUE);
    total++;
    printf("Sent: \"AbC\", \"HiaBc\"\n");
    correct += test("AbC", "HiaBc", TRUE);
    total++;
    printf("Sent: \"abc\", \"abXabc\"\n");
    correct += test("abc", "abXabc", TRUE);
    total++;
    printf("Sent: \"Hiabc\", \"abcd\"\n");
    correct += test("Hiabc", "abcd", FALSE);
    total++;
    printf("Sent: \"Hiabc\", \"bc\"\n");
    correct += test("Hiabc", "bc", TRUE);
    total++;
    printf("Sent: \"Hiabcx\", \"bc\"\n");
    correct += test("Hiabcx", "bc", FALSE);
    total++;
    printf("Sent: \"abc\", \"abc\"\n");
    correct += test("abc", "abc", TRUE);
    total++;
    printf("Sent: \"xyz\", \"12xyz\"\n");
    correct += test("xyz", "12xyz", TRUE);
    total++;
    printf("Sent: \"yz\", \"12xz\"\n");
    correct += test("yz", "12xz", FALSE);
    total++;
    printf("Sent: \"Z\", \"12xz\"\n");
    correct += test("Z", "12xz", TRUE);
    total++;
    printf("Sent: \"12\", \"12\"\n");
    correct += test("12", "12", TRUE);
    total++;
    printf("Sent: \"abcXYZ\", \"abcDEF\"\n");
    correct += test("abcXYZ", "abcDEF", FALSE);
    total++;
    printf("Sent: \"ab\", \"ab12\"\n");
    correct += test("ab", "ab12", FALSE);
    total++;
    printf("Sent: \"ab\", \"12ab\"\n");
    correct += test("ab", "12ab", TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, compute a new string by moving the first char to
come after the next two chars, so "abc" yields "bca". Repeat this
process for each subsequent group of 3 chars, so "abcdef" yields
"bcaefd". Ignore any group of fewer than 3 chars at the end.
*/

char * oneTwo(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = oneTwo(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"abc\"\n");
    correct += test("abc", "bca");
    total++;
    printf("Sent: \"tca\"\n");
    correct += test("tca", "cat");
    total++;
    printf("Sent: \"tcagdo\"\n");
    correct += test("tcagdo", "catdog");
    total++;
    printf("Sent: \"chocolate\"\n");
    correct += test("chocolate", "hocolctea");
    total++;
    printf("Sent: \"1234567890\"\n");
    correct += test("1234567890", "231564897");
    total++;
    printf("Sent: \"xabxabxabxabxabxabxab\"\n");
    correct += test("xabxabxabxabxabxabxab", "abxabxabxabxabxabxabx");
    total++;
    printf("Sent: \"abcdefx\"\n");
    correct += test("abcdefx", "bcaefd");
    total++;
    printf("Sent: \"abcdefxy\"\n");
    correct += test("abcdefxy", "bcaefd");
    total++;
    printf("Sent: \"abcdefxyz\"\n");
    correct += test("abcdefxyz", "bcaefdyzx");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", "");
    total++;
    printf("Sent: \"xy\"\n");
    correct += test("xy", "");
    total++;
    printf("Sent: \"xyz\"\n");
    correct += test("xyz", "yzx");
    total++;
    printf("Sent: \"abcdefghijklkmnopqrstuvwxyz1234567890\"\n");
    correct += test("abcdefghijklkmnopqrstuvwxyz1234567890", "bcaefdhigkljmnkpqostrvwuyzx231564897");
    total++;
    printf("Sent: \"abcdefghijklkmnopqrstuvwxyz123456789\"\n");
    correct += test("abcdefghijklkmnopqrstuvwxyz123456789", "bcaefdhigkljmnkpqostrvwuyzx231564897");
    total++;
    printf("Sent: \"abcdefghijklkmnopqrstuvwxyz12345678\"\n");
    correct += test("abcdefghijklkmnopqrstuvwxyz12345678", "bcaefdhigkljmnkpqostrvwuyzx231564");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We'll say that a char * is xy-balanced if for all the 'x' chars
in the string, there exists a 'y' char somewhere later in the
string. So "xxy" is balanced, but "xyx" is not. One 'y' can
balance multiple 'x's. Return TRUE if the given string is
xy-balanced.
*/

int xyBalance(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = xyBalance(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"aaxbby\"\n");
    correct += test("aaxbby", TRUE);
    total++;
    printf("Sent: \"aaxbb\"\n");
    correct += test("aaxbb", FALSE);
    total++;
    printf("Sent: \"yaaxbb\"\n");
    correct += test("yaaxbb", FALSE);
    total++;
    printf("Sent: \"yaaxbby\"\n");
    correct += test("yaaxbby", TRUE);
    total++;
    printf("Sent: \"xaxxbby\"\n");
    correct += test("xaxxbby", TRUE);
    total++;
    printf("Sent: \"xaxxbbyx\"\n");
    correct += test("xaxxbbyx", FALSE);
    total++;
    printf("Sent: \"xxbxy\"\n");
    correct += test("xxbxy", TRUE);
    total++;
    printf("Sent: \"xxbx\"\n");
    correct += test("xxbx", FALSE);
    total++;
    printf("Sent: \"bbb\"\n");
    correct += test("bbb", TRUE);
    total++;
    printf("Sent: \"bxbb\"\n");
    correct += test("bxbb", FALSE);
    total++;
    printf("Sent: \"bxyb\"\n");
    correct += test("bxyb", TRUE);
    total++;
    printf("Sent: \"xy\"\n");
    correct += test("xy", TRUE);
    total++;
    printf("Sent: \"y\"\n");
    correct += test("y", TRUE);
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", FALSE);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", TRUE);
    total++;
    printf("Sent: \"yxyxyxyx\"\n");
    correct += test("yxyxyxyx", FALSE);
    total++;
    printf("Sent: \"yxyxyxyxy\"\n");
    correct += test("yxyxyxyxy", TRUE);
    total++;
    printf("Sent: \"12xabxxydxyxyzz\"\n");
    correct += test("12xabxxydxyxyzz", TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

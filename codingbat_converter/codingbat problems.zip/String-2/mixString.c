#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given two strings, a and b, create a bigger string made of the
first char of a, the first char of b, the second char of a, the
second char of b, and so on. Any leftover chars go at the end of
the result.
*/

char * mixString(char * a, char * b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * a, char * b, char * expected)
{
    char * returned = mixString(a, b);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"abc\", \"xyz\"\n");
    correct += test("abc", "xyz", "axbycz");
    total++;
    printf("Sent: \"Hi\", \"There\"\n");
    correct += test("Hi", "There", "HTihere");
    total++;
    printf("Sent: \"xxxx\", \"There\"\n");
    correct += test("xxxx", "There", "xTxhxexre");
    total++;
    printf("Sent: \"xxx\", \"X\"\n");
    correct += test("xxx", "X", "xXxx");
    total++;
    printf("Sent: \"2/\", \"27 around\"\n");
    correct += test("2/", "27 around", "22/7 around");
    total++;
    printf("Sent: \"\", \"Hello\"\n");
    correct += test("", "Hello", "Hello");
    total++;
    printf("Sent: \"Abc\", \"\"\n");
    correct += test("Abc", "", "Abc");
    total++;
    printf("Sent: \"\", \"\"\n");
    correct += test("", "", "");
    total++;
    printf("Sent: \"a\", \"b\"\n");
    correct += test("a", "b", "ab");
    total++;
    printf("Sent: \"ax\", \"b\"\n");
    correct += test("ax", "b", "abx");
    total++;
    printf("Sent: \"a\", \"bx\"\n");
    correct += test("a", "bx", "abx");
    total++;
    printf("Sent: \"So\", \"Long\"\n");
    correct += test("So", "Long", "SLoong");
    total++;
    printf("Sent: \"Long\", \"So\"\n");
    correct += test("Long", "So", "LSoong");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string and a non-empty word string, return a version of
the original char * where all chars have been replaced by pluses
("+"), except for appearances of the word string which are
preserved unchanged.
*/

char * plusOut(char * str, char * word)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * word, char * expected)
{
    char * returned = plusOut(str, word);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"12xy34\", \"xy\"\n");
    correct += test("12xy34", "xy", "++xy++");
    total++;
    printf("Sent: \"12xy34\", \"1\"\n");
    correct += test("12xy34", "1", "1+++++");
    total++;
    printf("Sent: \"12xy34xyabcxy\", \"xy\"\n");
    correct += test("12xy34xyabcxy", "xy", "++xy++xy+++xy");
    total++;
    printf("Sent: \"abXYabcXYZ\", \"ab\"\n");
    correct += test("abXYabcXYZ", "ab", "ab++ab++++");
    total++;
    printf("Sent: \"abXYabcXYZ\", \"abc\"\n");
    correct += test("abXYabcXYZ", "abc", "++++abc+++");
    total++;
    printf("Sent: \"abXYabcXYZ\", \"XY\"\n");
    correct += test("abXYabcXYZ", "XY", "++XY+++XY+");
    total++;
    printf("Sent: \"abXYxyzXYZ\", \"XYZ\"\n");
    correct += test("abXYxyzXYZ", "XYZ", "+++++++XYZ");
    total++;
    printf("Sent: \"--++ab\", \"++\"\n");
    correct += test("--++ab", "++", "++++++");
    total++;
    printf("Sent: \"aaxxxxbb\", \"xx\"\n");
    correct += test("aaxxxxbb", "xx", "++xxxx++");
    total++;
    printf("Sent: \"123123\", \"3\"\n");
    correct += test("123123", "3", "++3++3");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return the number of times that the string "hi" appears anywhere
in the given string.
*/

int countHi(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = countHi(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"abc hi ho\"\n");
    correct += test("abc hi ho", 1);
    total++;
    printf("Sent: \"ABChi hi\"\n");
    correct += test("ABChi hi", 2);
    total++;
    printf("Sent: \"hihi\"\n");
    correct += test("hihi", 2);
    total++;
    printf("Sent: \"hiHIhi\"\n");
    correct += test("hiHIhi", 2);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", 0);
    total++;
    printf("Sent: \"h\"\n");
    correct += test("h", 0);
    total++;
    printf("Sent: \"hi\"\n");
    correct += test("hi", 1);
    total++;
    printf("Sent: \"Hi is no HI on ahI\"\n");
    correct += test("Hi is no HI on ahI", 0);
    total++;
    printf("Sent: \"hiho not HOHIhi\"\n");
    correct += test("hiho not HOHIhi", 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

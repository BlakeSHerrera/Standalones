#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, consider the prefix string made of the first N
chars of the string. Does that prefix string appear somewhere
else in the string? Assume that the string is not empty and that
N is in the range 1..str.length().
*/

int prefixAgain(char * str, int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int n, int expected)
{
    int returned = prefixAgain(str, n);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"abXYabc\", 1\n");
    correct += test("abXYabc", 1, TRUE);
    total++;
    printf("Sent: \"abXYabc\", 2\n");
    correct += test("abXYabc", 2, TRUE);
    total++;
    printf("Sent: \"abXYabc\", 3\n");
    correct += test("abXYabc", 3, FALSE);
    total++;
    printf("Sent: \"xyzxyxyxy\", 2\n");
    correct += test("xyzxyxyxy", 2, TRUE);
    total++;
    printf("Sent: \"xyzxyxyxy\", 3\n");
    correct += test("xyzxyxyxy", 3, FALSE);
    total++;
    printf("Sent: \"Hi12345Hi6789Hi10\", 1\n");
    correct += test("Hi12345Hi6789Hi10", 1, TRUE);
    total++;
    printf("Sent: \"Hi12345Hi6789Hi10\", 2\n");
    correct += test("Hi12345Hi6789Hi10", 2, TRUE);
    total++;
    printf("Sent: \"Hi12345Hi6789Hi10\", 3\n");
    correct += test("Hi12345Hi6789Hi10", 3, TRUE);
    total++;
    printf("Sent: \"Hi12345Hi6789Hi10\", 4\n");
    correct += test("Hi12345Hi6789Hi10", 4, FALSE);
    total++;
    printf("Sent: \"a\", 1\n");
    correct += test("a", 1, FALSE);
    total++;
    printf("Sent: \"aa\", 1\n");
    correct += test("aa", 1, TRUE);
    total++;
    printf("Sent: \"ab\", 1\n");
    correct += test("ab", 1, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

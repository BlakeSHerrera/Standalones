#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return TRUE if the given string contains an appearance of "xyz"
where the xyz is not directly preceeded by a period (.). So
"xxyz" counts but "x.xyz" does not.
*/

int xyzThere(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = xyzThere(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"abcxyz\"\n");
    correct += test("abcxyz", TRUE);
    total++;
    printf("Sent: \"abc.xyz\"\n");
    correct += test("abc.xyz", FALSE);
    total++;
    printf("Sent: \"xyz.abc\"\n");
    correct += test("xyz.abc", TRUE);
    total++;
    printf("Sent: \"abcxy\"\n");
    correct += test("abcxy", FALSE);
    total++;
    printf("Sent: \"xyz\"\n");
    correct += test("xyz", TRUE);
    total++;
    printf("Sent: \"xy\"\n");
    correct += test("xy", FALSE);
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", FALSE);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", FALSE);
    total++;
    printf("Sent: \"abc.xyzxyz\"\n");
    correct += test("abc.xyzxyz", TRUE);
    total++;
    printf("Sent: \"abc.xxyz\"\n");
    correct += test("abc.xxyz", TRUE);
    total++;
    printf("Sent: \".xyz\"\n");
    correct += test(".xyz", FALSE);
    total++;
    printf("Sent: \"12.xyz\"\n");
    correct += test("12.xyz", FALSE);
    total++;
    printf("Sent: \"12xyz\"\n");
    correct += test("12xyz", TRUE);
    total++;
    printf("Sent: \"1.xyz.xyz2.xyz\"\n");
    correct += test("1.xyz.xyz2.xyz", FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return TRUE if the string "cat" and "dog" appear the same number
of times in the given string.
*/

int catDog(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = catDog(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"catdog\"\n");
    correct += test("catdog", TRUE);
    total++;
    printf("Sent: \"catcat\"\n");
    correct += test("catcat", FALSE);
    total++;
    printf("Sent: \"1cat1cadodog\"\n");
    correct += test("1cat1cadodog", TRUE);
    total++;
    printf("Sent: \"catxxdogxxxdog\"\n");
    correct += test("catxxdogxxxdog", FALSE);
    total++;
    printf("Sent: \"catxdogxdogxcat\"\n");
    correct += test("catxdogxdogxcat", TRUE);
    total++;
    printf("Sent: \"catxdogxdogxca\"\n");
    correct += test("catxdogxdogxca", FALSE);
    total++;
    printf("Sent: \"dogdogcat\"\n");
    correct += test("dogdogcat", FALSE);
    total++;
    printf("Sent: \"dogogcat\"\n");
    correct += test("dogogcat", TRUE);
    total++;
    printf("Sent: \"dog\"\n");
    correct += test("dog", FALSE);
    total++;
    printf("Sent: \"cat\"\n");
    correct += test("cat", FALSE);
    total++;
    printf("Sent: \"ca\"\n");
    correct += test("ca", TRUE);
    total++;
    printf("Sent: \"c\"\n");
    correct += test("c", TRUE);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

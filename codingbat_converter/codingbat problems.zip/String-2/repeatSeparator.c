#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given two strings, word and a separator sep, return a big string
made of count occurrences of the word, separated by the separator
string.
*/

char * repeatSeparator(char * word, char * sep, int count)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * word, char * sep, int count, char * expected)
{
    char * returned = repeatSeparator(word, sep, count);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Word\", \"X\", 3\n");
    correct += test("Word", "X", 3, "WordXWordXWord");
    total++;
    printf("Sent: \"This\", \"And\", 2\n");
    correct += test("This", "And", 2, "ThisAndThis");
    total++;
    printf("Sent: \"This\", \"And\", 1\n");
    correct += test("This", "And", 1, "This");
    total++;
    printf("Sent: \"Hi\", \"-n-\", 2\n");
    correct += test("Hi", "-n-", 2, "Hi-n-Hi");
    total++;
    printf("Sent: \"AAA\", \"\", 1\n");
    correct += test("AAA", "", 1, "AAA");
    total++;
    printf("Sent: \"AAA\", \"\", 0\n");
    correct += test("AAA", "", 0, "");
    total++;
    printf("Sent: \"A\", \"B\", 5\n");
    correct += test("A", "B", 5, "ABABABABA");
    total++;
    printf("Sent: \"abc\", \"XX\", 3\n");
    correct += test("abc", "XX", 3, "abcXXabcXXabc");
    total++;
    printf("Sent: \"abc\", \"XX\", 2\n");
    correct += test("abc", "XX", 2, "abcXXabc");
    total++;
    printf("Sent: \"abc\", \"XX\", 1\n");
    correct += test("abc", "XX", 1, "abc");
    total++;
    printf("Sent: \"XYZ\", \"a\", 2\n");
    correct += test("XYZ", "a", 2, "XYZaXYZ");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

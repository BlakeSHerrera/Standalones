#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Returns TRUE if for every '*' (star) in the string, if there are
chars both immediately before and after the star, they are the
same.
*/

int sameStarChar(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = sameStarChar(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"xy*yzz\"\n");
    correct += test("xy*yzz", TRUE);
    total++;
    printf("Sent: \"xy*zzz\"\n");
    correct += test("xy*zzz", FALSE);
    total++;
    printf("Sent: \"*xa*az\"\n");
    correct += test("*xa*az", TRUE);
    total++;
    printf("Sent: \"*xa*bz\"\n");
    correct += test("*xa*bz", FALSE);
    total++;
    printf("Sent: \"*xa*a*\"\n");
    correct += test("*xa*a*", TRUE);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", TRUE);
    total++;
    printf("Sent: \"*xa*a*a\"\n");
    correct += test("*xa*a*a", TRUE);
    total++;
    printf("Sent: \"*xa*a*b\"\n");
    correct += test("*xa*a*b", FALSE);
    total++;
    printf("Sent: \"*12*2*2\"\n");
    correct += test("*12*2*2", TRUE);
    total++;
    printf("Sent: \"12*2*3*\"\n");
    correct += test("12*2*3*", FALSE);
    total++;
    printf("Sent: \"abcDEF\"\n");
    correct += test("abcDEF", TRUE);
    total++;
    printf("Sent: \"XY*YYYY*Z*\"\n");
    correct += test("XY*YYYY*Z*", FALSE);
    total++;
    printf("Sent: \"XY*YYYY*Y*\"\n");
    correct += test("XY*YYYY*Y*", TRUE);
    total++;
    printf("Sent: \"12*2*3*\"\n");
    correct += test("12*2*3*", FALSE);
    total++;
    printf("Sent: \"*\"\n");
    correct += test("*", TRUE);
    total++;
    printf("Sent: \"**\"\n");
    correct += test("**", TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

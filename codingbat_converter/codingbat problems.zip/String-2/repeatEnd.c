#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string and an int n, return a string made of n
repetitions of the last n characters of the string. You may
assume that n is between 0 and the length of the string,
inclusive.
*/

char * repeatEnd(char * str, int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int n, char * expected)
{
    char * returned = repeatEnd(str, n);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello\", 3\n");
    correct += test("Hello", 3, "llollollo");
    total++;
    printf("Sent: \"Hello\", 2\n");
    correct += test("Hello", 2, "lolo");
    total++;
    printf("Sent: \"Hello\", 1\n");
    correct += test("Hello", 1, "o");
    total++;
    printf("Sent: \"Hello\", 0\n");
    correct += test("Hello", 0, "");
    total++;
    printf("Sent: \"abc\", 3\n");
    correct += test("abc", 3, "abcabcabc");
    total++;
    printf("Sent: \"1234\", 2\n");
    correct += test("1234", 2, "3434");
    total++;
    printf("Sent: \"1234\", 3\n");
    correct += test("1234", 3, "234234234");
    total++;
    printf("Sent: \"\", 0\n");
    correct += test("", 0, "");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

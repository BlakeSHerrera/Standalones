#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return a version of the given string, where for every star (*) in
the string the star and the chars immediately to its left and
right are gone. So "ab*cd" yields "ad" and "ab**cd" also yields
"ad".
*/

char * starOut(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = starOut(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"ab*cd\"\n");
    correct += test("ab*cd", "ad");
    total++;
    printf("Sent: \"ab**cd\"\n");
    correct += test("ab**cd", "ad");
    total++;
    printf("Sent: \"sm*eilly\"\n");
    correct += test("sm*eilly", "silly");
    total++;
    printf("Sent: \"sm*eil*ly\"\n");
    correct += test("sm*eil*ly", "siy");
    total++;
    printf("Sent: \"sm**eil*ly\"\n");
    correct += test("sm**eil*ly", "siy");
    total++;
    printf("Sent: \"sm***eil*ly\"\n");
    correct += test("sm***eil*ly", "siy");
    total++;
    printf("Sent: \"stringy*\"\n");
    correct += test("stringy*", "string");
    total++;
    printf("Sent: \"*stringy\"\n");
    correct += test("*stringy", "tringy");
    total++;
    printf("Sent: \"*str*in*gy\"\n");
    correct += test("*str*in*gy", "ty");
    total++;
    printf("Sent: \"abc\"\n");
    correct += test("abc", "abc");
    total++;
    printf("Sent: \"a*bc\"\n");
    correct += test("a*bc", "c");
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", "ab");
    total++;
    printf("Sent: \"a*b\"\n");
    correct += test("a*b", "");
    total++;
    printf("Sent: \"a\"\n");
    correct += test("a", "a");
    total++;
    printf("Sent: \"a*\"\n");
    correct += test("a*", "");
    total++;
    printf("Sent: \"*a\"\n");
    correct += test("*a", "");
    total++;
    printf("Sent: \"*\"\n");
    correct += test("*", "");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

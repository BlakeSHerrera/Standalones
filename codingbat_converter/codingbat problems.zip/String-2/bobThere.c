#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return TRUE if the given string contains a "bob" string, but
where the middle 'o' char can be any char.
*/

int bobThere(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = bobThere(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"abcbob\"\n");
    correct += test("abcbob", TRUE);
    total++;
    printf("Sent: \"b9b\"\n");
    correct += test("b9b", TRUE);
    total++;
    printf("Sent: \"bac\"\n");
    correct += test("bac", FALSE);
    total++;
    printf("Sent: \"bbb\"\n");
    correct += test("bbb", TRUE);
    total++;
    printf("Sent: \"abcdefb\"\n");
    correct += test("abcdefb", FALSE);
    total++;
    printf("Sent: \"123abcbcdbabxyz\"\n");
    correct += test("123abcbcdbabxyz", TRUE);
    total++;
    printf("Sent: \"b12\"\n");
    correct += test("b12", FALSE);
    total++;
    printf("Sent: \"b1b\"\n");
    correct += test("b1b", TRUE);
    total++;
    printf("Sent: \"b12b1b\"\n");
    correct += test("b12b1b", TRUE);
    total++;
    printf("Sent: \"bbc\"\n");
    correct += test("bbc", FALSE);
    total++;
    printf("Sent: \"bbb\"\n");
    correct += test("bbb", TRUE);
    total++;
    printf("Sent: \"bb\"\n");
    correct += test("bb", FALSE);
    total++;
    printf("Sent: \"b\"\n");
    correct += test("b", FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

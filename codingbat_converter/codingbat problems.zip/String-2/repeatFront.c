#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string and an int n, return a string made of the first n
characters of the string, followed by the first n-1 characters of
the string, and so on. You may assume that n is between 0 and the
length of the string, inclusive (i.e. n >= 0 and n <=
str.length()).
*/

char * repeatFront(char * str, int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int n, char * expected)
{
    char * returned = repeatFront(str, n);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Chocolate\", 4\n");
    correct += test("Chocolate", 4, "ChocChoChC");
    total++;
    printf("Sent: \"Chocolate\", 3\n");
    correct += test("Chocolate", 3, "ChoChC");
    total++;
    printf("Sent: \"Ice Cream\", 2\n");
    correct += test("Ice Cream", 2, "IcI");
    total++;
    printf("Sent: \"Ice Cream\", 1\n");
    correct += test("Ice Cream", 1, "I");
    total++;
    printf("Sent: \"Ice Cream\", 0\n");
    correct += test("Ice Cream", 0, "");
    total++;
    printf("Sent: \"xyz\", 3\n");
    correct += test("xyz", 3, "xyzxyx");
    total++;
    printf("Sent: \"\", 0\n");
    correct += test("", 0, "");
    total++;
    printf("Sent: \"Java\", 4\n");
    correct += test("Java", 4, "JavaJavJaJ");
    total++;
    printf("Sent: \"Java\", 1\n");
    correct += test("Java", 1, "J");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, does "xyz" appear in the middle of the string? To
define middle, we'll say that the number of chars to the left and
right of the "xyz" must differ by at most one. This problem is
harder than it looks.
*/

int xyzMiddle(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = xyzMiddle(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"AAxyzBB\"\n");
    correct += test("AAxyzBB", TRUE);
    total++;
    printf("Sent: \"AxyzBB\"\n");
    correct += test("AxyzBB", TRUE);
    total++;
    printf("Sent: \"AxyzBBB\"\n");
    correct += test("AxyzBBB", FALSE);
    total++;
    printf("Sent: \"AxyzBBBB\"\n");
    correct += test("AxyzBBBB", FALSE);
    total++;
    printf("Sent: \"AAAxyzB\"\n");
    correct += test("AAAxyzB", FALSE);
    total++;
    printf("Sent: \"AAAxyzBB\"\n");
    correct += test("AAAxyzBB", TRUE);
    total++;
    printf("Sent: \"AAAAxyzBB\"\n");
    correct += test("AAAAxyzBB", FALSE);
    total++;
    printf("Sent: \"AAAAAxyzBBB\"\n");
    correct += test("AAAAAxyzBBB", FALSE);
    total++;
    printf("Sent: \"1x345xyz12x4\"\n");
    correct += test("1x345xyz12x4", TRUE);
    total++;
    printf("Sent: \"xyzAxyzBBB\"\n");
    correct += test("xyzAxyzBBB", TRUE);
    total++;
    printf("Sent: \"xyzAxyzBxyz\"\n");
    correct += test("xyzAxyzBxyz", TRUE);
    total++;
    printf("Sent: \"xyzxyzAxyzBxyzxyz\"\n");
    correct += test("xyzxyzAxyzBxyzxyz", TRUE);
    total++;
    printf("Sent: \"xyzxyzxyzBxyzxyz\"\n");
    correct += test("xyzxyzxyzBxyzxyz", TRUE);
    total++;
    printf("Sent: \"xyzxyzAxyzxyzxyz\"\n");
    correct += test("xyzxyzAxyzxyzxyz", TRUE);
    total++;
    printf("Sent: \"xyzxyzAxyzxyzxy\"\n");
    correct += test("xyzxyzAxyzxyzxy", FALSE);
    total++;
    printf("Sent: \"AxyzxyzBB\"\n");
    correct += test("AxyzxyzBB", FALSE);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", FALSE);
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", FALSE);
    total++;
    printf("Sent: \"xy\"\n");
    correct += test("xy", FALSE);
    total++;
    printf("Sent: \"xyz\"\n");
    correct += test("xyz", TRUE);
    total++;
    printf("Sent: \"xyzz\"\n");
    correct += test("xyzz", TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a string where for every char in the
original, there are two chars.
*/

char * doubleChar(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = doubleChar(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"The\"\n");
    correct += test("The", "TThhee");
    total++;
    printf("Sent: \"AAbb\"\n");
    correct += test("AAbb", "AAAAbbbb");
    total++;
    printf("Sent: \"Hi-There\"\n");
    correct += test("Hi-There", "HHii--TThheerree");
    total++;
    printf("Sent: \"Word!\"\n");
    correct += test("Word!", "WWoorrdd!!");
    total++;
    printf("Sent: \"!!\"\n");
    correct += test("!!", "!!!!");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"a\"\n");
    correct += test("a", "aa");
    total++;
    printf("Sent: \".\"\n");
    correct += test(".", "..");
    total++;
    printf("Sent: \"aa\"\n");
    correct += test("aa", "aaaa");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, is it possible to choose a group of some
of the ints, such that the group sums to the given target with
this additional constraint: If a value in the array is chosen to
be in the group, the value immediately following it in the array
must not be chosen. (No loops needed.)
*/

int groupNoAdj(int start, int nums[], int numsSize, int target)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int start, int nums[], int numsSize, int target, int expected)
{
    int returned = groupNoAdj(start, nums, numsSize, target);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 0, [2, 5, 10, 4], 12\n");
    correct += test(0, (int[]){2, 5, 10, 4}, 4, 12, TRUE);
    total++;
    printf("Sent: 0, [2, 5, 10, 4], 14\n");
    correct += test(0, (int[]){2, 5, 10, 4}, 4, 14, FALSE);
    total++;
    printf("Sent: 0, [2, 5, 10, 4], 7\n");
    correct += test(0, (int[]){2, 5, 10, 4}, 4, 7, FALSE);
    total++;
    printf("Sent: 0, [2, 5, 10, 4, 2], 7\n");
    correct += test(0, (int[]){2, 5, 10, 4, 2}, 5, 7, TRUE);
    total++;
    printf("Sent: 0, [2, 5, 10, 4], 9\n");
    correct += test(0, (int[]){2, 5, 10, 4}, 4, 9, TRUE);
    total++;
    printf("Sent: 0, [10, 2, 2, 3, 3], 15\n");
    correct += test(0, (int[]){10, 2, 2, 3, 3}, 5, 15, TRUE);
    total++;
    printf("Sent: 0, [10, 2, 2, 3, 3], 7\n");
    correct += test(0, (int[]){10, 2, 2, 3, 3}, 5, 7, FALSE);
    total++;
    printf("Sent: 0, [], 0\n");
    correct += test(0, (int[]){}, 1, 0, TRUE);
    total++;
    printf("Sent: 0, [1], 1\n");
    correct += test(0, (int[]){1}, 1, 1, TRUE);
    total++;
    printf("Sent: 0, [9], 1\n");
    correct += test(0, (int[]){9}, 1, 1, FALSE);
    total++;
    printf("Sent: 0, [9], 0\n");
    correct += test(0, (int[]){9}, 1, 0, TRUE);
    total++;
    printf("Sent: 0, [5, 10, 4, 1], 11\n");
    correct += test(0, (int[]){5, 10, 4, 1}, 4, 11, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, is it possible to choose a group of some
of the ints, such that the group sums to the given target? This
is a classic backtracking recursion problem. Once you understand
the recursive backtracking strategy in this problem, you can use
the same pattern for many problems to search a space of choices.
Rather than looking at the whole array, our convention is to
consider the part of the array starting at index start and
continuing to the end of the array. The caller can specify the
whole array simply by passing start as 0. No loops are needed --
the recursive calls progress down the array. 
*/

int groupSum(int start, int nums[], int numsSize, int target)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int start, int nums[], int numsSize, int target, int expected)
{
    int returned = groupSum(start, nums, numsSize, target);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 0, [2, 4, 8], 10\n");
    correct += test(0, (int[]){2, 4, 8}, 3, 10, TRUE);
    total++;
    printf("Sent: 0, [2, 4, 8], 14\n");
    correct += test(0, (int[]){2, 4, 8}, 3, 14, TRUE);
    total++;
    printf("Sent: 0, [2, 4, 8], 9\n");
    correct += test(0, (int[]){2, 4, 8}, 3, 9, FALSE);
    total++;
    printf("Sent: 0, [2, 4, 8], 8\n");
    correct += test(0, (int[]){2, 4, 8}, 3, 8, TRUE);
    total++;
    printf("Sent: 1, [2, 4, 8], 8\n");
    correct += test(1, (int[]){2, 4, 8}, 3, 8, TRUE);
    total++;
    printf("Sent: 1, [2, 4, 8], 2\n");
    correct += test(1, (int[]){2, 4, 8}, 3, 2, FALSE);
    total++;
    printf("Sent: 0, [1], 1\n");
    correct += test(0, (int[]){1}, 1, 1, TRUE);
    total++;
    printf("Sent: 0, [9], 1\n");
    correct += test(0, (int[]){9}, 1, 1, FALSE);
    total++;
    printf("Sent: 1, [9], 0\n");
    correct += test(1, (int[]){9}, 1, 0, TRUE);
    total++;
    printf("Sent: 0, [], 0\n");
    correct += test(0, (int[]){}, 1, 0, TRUE);
    total++;
    printf("Sent: 0, [10, 2, 2, 5], 17\n");
    correct += test(0, (int[]){10, 2, 2, 5}, 4, 17, TRUE);
    total++;
    printf("Sent: 0, [10, 2, 2, 5], 15\n");
    correct += test(0, (int[]){10, 2, 2, 5}, 4, 15, TRUE);
    total++;
    printf("Sent: 0, [10, 2, 2, 5], 9\n");
    correct += test(0, (int[]){10, 2, 2, 5}, 4, 9, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

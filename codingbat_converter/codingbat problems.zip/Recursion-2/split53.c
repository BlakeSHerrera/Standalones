#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, is it possible to divide the ints into
two groups, so that the sum of the two groups is the same, with
these constraints: all the values that are multiple of 5 must be
in one group, and all the values that are a multiple of 3 (and
not a multiple of 5) must be in the other. (No loops needed.)
*/

int split53(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = split53(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 1]\n");
    correct += test((int[]){1, 1}, 2, TRUE);
    total++;
    printf("Sent: [1, 1, 1]\n");
    correct += test((int[]){1, 1, 1}, 3, FALSE);
    total++;
    printf("Sent: [2, 4, 2]\n");
    correct += test((int[]){2, 4, 2}, 3, TRUE);
    total++;
    printf("Sent: [2, 2, 2, 1]\n");
    correct += test((int[]){2, 2, 2, 1}, 4, FALSE);
    total++;
    printf("Sent: [3, 3, 5, 1]\n");
    correct += test((int[]){3, 3, 5, 1}, 4, TRUE);
    total++;
    printf("Sent: [3, 5, 8]\n");
    correct += test((int[]){3, 5, 8}, 3, FALSE);
    total++;
    printf("Sent: [2, 4, 6]\n");
    correct += test((int[]){2, 4, 6}, 3, TRUE);
    total++;
    printf("Sent: [3, 5, 6, 10, 3, 3]\n");
    correct += test((int[]){3, 5, 6, 10, 3, 3}, 6, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

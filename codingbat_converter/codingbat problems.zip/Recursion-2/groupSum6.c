#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, is it possible to choose a group of some
of the ints, beginning at the start index, such that the group
sums to the given target? However, with the additional constraint
that all 6's must be chosen. (No loops needed.)
*/

int groupSum6(int start, int nums[], int numsSize, int target)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int start, int nums[], int numsSize, int target, int expected)
{
    int returned = groupSum6(start, nums, numsSize, target);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 0, [5, 6, 2], 8\n");
    correct += test(0, (int[]){5, 6, 2}, 3, 8, TRUE);
    total++;
    printf("Sent: 0, [5, 6, 2], 9\n");
    correct += test(0, (int[]){5, 6, 2}, 3, 9, FALSE);
    total++;
    printf("Sent: 0, [5, 6, 2], 7\n");
    correct += test(0, (int[]){5, 6, 2}, 3, 7, FALSE);
    total++;
    printf("Sent: 0, [1], 1\n");
    correct += test(0, (int[]){1}, 1, 1, TRUE);
    total++;
    printf("Sent: 0, [9], 1\n");
    correct += test(0, (int[]){9}, 1, 1, FALSE);
    total++;
    printf("Sent: 0, [], 0\n");
    correct += test(0, (int[]){}, 1, 0, TRUE);
    total++;
    printf("Sent: 0, [3, 2, 4, 6], 8\n");
    correct += test(0, (int[]){3, 2, 4, 6}, 4, 8, TRUE);
    total++;
    printf("Sent: 0, [6, 2, 4, 3], 8\n");
    correct += test(0, (int[]){6, 2, 4, 3}, 4, 8, TRUE);
    total++;
    printf("Sent: 0, [5, 2, 4, 6], 9\n");
    correct += test(0, (int[]){5, 2, 4, 6}, 4, 9, FALSE);
    total++;
    printf("Sent: 0, [6, 2, 4, 5], 9\n");
    correct += test(0, (int[]){6, 2, 4, 5}, 4, 9, FALSE);
    total++;
    printf("Sent: 0, [3, 2, 4, 6], 3\n");
    correct += test(0, (int[]){3, 2, 4, 6}, 4, 3, FALSE);
    total++;
    printf("Sent: 0, [1, 6, 2, 6, 4], 12\n");
    correct += test(0, (int[]){1, 6, 2, 6, 4}, 5, 12, TRUE);
    total++;
    printf("Sent: 0, [1, 6, 2, 6, 4], 13\n");
    correct += test(0, (int[]){1, 6, 2, 6, 4}, 5, 13, TRUE);
    total++;
    printf("Sent: 0, [1, 6, 2, 6, 4], 4\n");
    correct += test(0, (int[]){1, 6, 2, 6, 4}, 5, 4, FALSE);
    total++;
    printf("Sent: 0, [1, 6, 2, 6, 4], 9\n");
    correct += test(0, (int[]){1, 6, 2, 6, 4}, 5, 9, FALSE);
    total++;
    printf("Sent: 0, [1, 6, 2, 6, 5], 14\n");
    correct += test(0, (int[]){1, 6, 2, 6, 5}, 5, 14, TRUE);
    total++;
    printf("Sent: 0, [1, 6, 2, 6, 5], 15\n");
    correct += test(0, (int[]){1, 6, 2, 6, 5}, 5, 15, TRUE);
    total++;
    printf("Sent: 0, [1, 6, 2, 6, 5], 16\n");
    correct += test(0, (int[]){1, 6, 2, 6, 5}, 5, 16, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

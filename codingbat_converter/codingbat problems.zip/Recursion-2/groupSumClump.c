#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, is it possible to choose a group of some
of the ints, such that the group sums to the given target, with
this additional constraint: if there are numbers in the array
that are adjacent and the identical value, they must either all
be chosen, or none of them chosen. For example, with the array
{1, 2, 2, 2, 5, 2}, either all three 2's in the middle must be
chosen or not, all as a group. (one loop can be used to find the
extent of the identical values).
*/

int groupSumClump(int start, int nums[], int numsSize, int target)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int start, int nums[], int numsSize, int target, int expected)
{
    int returned = groupSumClump(start, nums, numsSize, target);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 0, [2, 4, 8], 10\n");
    correct += test(0, (int[]){2, 4, 8}, 3, 10, TRUE);
    total++;
    printf("Sent: 0, [1, 2, 4, 8, 1], 14\n");
    correct += test(0, (int[]){1, 2, 4, 8, 1}, 5, 14, TRUE);
    total++;
    printf("Sent: 0, [2, 4, 4, 8], 14\n");
    correct += test(0, (int[]){2, 4, 4, 8}, 4, 14, FALSE);
    total++;
    printf("Sent: 0, [8, 2, 2, 1], 9\n");
    correct += test(0, (int[]){8, 2, 2, 1}, 4, 9, TRUE);
    total++;
    printf("Sent: 0, [8, 2, 2, 1], 11\n");
    correct += test(0, (int[]){8, 2, 2, 1}, 4, 11, FALSE);
    total++;
    printf("Sent: 0, [1], 1\n");
    correct += test(0, (int[]){1}, 1, 1, TRUE);
    total++;
    printf("Sent: 0, [9], 1\n");
    correct += test(0, (int[]){9}, 1, 1, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

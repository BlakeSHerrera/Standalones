#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, is it possible to choose a group of some
of the ints, such that the group sums to the given target with
these additional constraints: all multiples of 5 in the array
must be included in the group. If the value immediately following
a multiple of 5 is 1, it must not be chosen. (No loops needed.)
*/

int groupSum5(int start, int nums[], int numsSize, int target)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int start, int nums[], int numsSize, int target, int expected)
{
    int returned = groupSum5(start, nums, numsSize, target);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 0, [2, 5, 10, 4], 19\n");
    correct += test(0, (int[]){2, 5, 10, 4}, 4, 19, TRUE);
    total++;
    printf("Sent: 0, [2, 5, 10, 4], 17\n");
    correct += test(0, (int[]){2, 5, 10, 4}, 4, 17, TRUE);
    total++;
    printf("Sent: 0, [2, 5, 10, 4], 12\n");
    correct += test(0, (int[]){2, 5, 10, 4}, 4, 12, FALSE);
    total++;
    printf("Sent: 0, [2, 5, 4, 10], 12\n");
    correct += test(0, (int[]){2, 5, 4, 10}, 4, 12, FALSE);
    total++;
    printf("Sent: 0, [3, 5, 1], 4\n");
    correct += test(0, (int[]){3, 5, 1}, 3, 4, FALSE);
    total++;
    printf("Sent: 0, [3, 5, 1], 5\n");
    correct += test(0, (int[]){3, 5, 1}, 3, 5, TRUE);
    total++;
    printf("Sent: 0, [1, 3, 5], 5\n");
    correct += test(0, (int[]){1, 3, 5}, 3, 5, TRUE);
    total++;
    printf("Sent: 0, [3, 5, 1], 9\n");
    correct += test(0, (int[]){3, 5, 1}, 3, 9, FALSE);
    total++;
    printf("Sent: 0, [2, 5, 10, 4], 7\n");
    correct += test(0, (int[]){2, 5, 10, 4}, 4, 7, FALSE);
    total++;
    printf("Sent: 0, [2, 5, 10, 4], 15\n");
    correct += test(0, (int[]){2, 5, 10, 4}, 4, 15, TRUE);
    total++;
    printf("Sent: 0, [2, 5, 10, 4], 11\n");
    correct += test(0, (int[]){2, 5, 10, 4}, 4, 11, FALSE);
    total++;
    printf("Sent: 0, [1], 1\n");
    correct += test(0, (int[]){1}, 1, 1, TRUE);
    total++;
    printf("Sent: 0, [9], 1\n");
    correct += test(0, (int[]){9}, 1, 1, FALSE);
    total++;
    printf("Sent: 0, [9], 0\n");
    correct += test(0, (int[]){9}, 1, 0, TRUE);
    total++;
    printf("Sent: 0, [], 0\n");
    correct += test(0, (int[]){}, 1, 0, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

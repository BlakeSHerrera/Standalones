#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We have bunnies standing in a line, numbered 1, 2, ... The odd
bunnies (1, 3, ..) have the normal 2 ears. The even bunnies (2,
4, ..) we'll say have 3 ears, because they each have a raised
foot. Recursively return the number of "ears" in the bunny line
1, 2, ... n (without loops or multiplication).
*/

int bunnyEars2(int bunnies)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int bunnies, int expected)
{
    int returned = bunnyEars2(bunnies);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 0\n");
    correct += test(0, 0);
    total++;
    printf("Sent: 1\n");
    correct += test(1, 2);
    total++;
    printf("Sent: 2\n");
    correct += test(2, 5);
    total++;
    printf("Sent: 3\n");
    correct += test(3, 7);
    total++;
    printf("Sent: 4\n");
    correct += test(4, 10);
    total++;
    printf("Sent: 5\n");
    correct += test(5, 12);
    total++;
    printf("Sent: 6\n");
    correct += test(6, 15);
    total++;
    printf("Sent: 10\n");
    correct += test(10, 25);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

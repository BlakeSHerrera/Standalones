#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We have a number of bunnies and each bunny has two big floppy
ears. We want to compute the total number of ears across all the
bunnies recursively (without loops or multiplication).
*/

int bunnyEars(int bunnies)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int bunnies, int expected)
{
    int returned = bunnyEars(bunnies);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 0\n");
    correct += test(0, 0);
    total++;
    printf("Sent: 1\n");
    correct += test(1, 2);
    total++;
    printf("Sent: 2\n");
    correct += test(2, 4);
    total++;
    printf("Sent: 3\n");
    correct += test(3, 6);
    total++;
    printf("Sent: 4\n");
    correct += test(4, 8);
    total++;
    printf("Sent: 5\n");
    correct += test(5, 10);
    total++;
    printf("Sent: 12\n");
    correct += test(12, 24);
    total++;
    printf("Sent: 50\n");
    correct += test(50, 100);
    total++;
    printf("Sent: 234\n");
    correct += test(234, 468);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

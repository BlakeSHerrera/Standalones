#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a non-negative int n, compute recursively (no loops) the
count of the occurrences of 8 as a digit, except that an 8 with
another 8 immediately to its left counts double, so 8818 yields
4. Note that mod (%) by 10 yields the rightmost digit (126 % 10
is 6), while divide (/) by 10 removes the rightmost digit (126 /
10 is 12).
*/

int count8(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int expected)
{
    int returned = count8(n);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 8\n");
    correct += test(8, 1);
    total++;
    printf("Sent: 818\n");
    correct += test(818, 2);
    total++;
    printf("Sent: 8818\n");
    correct += test(8818, 4);
    total++;
    printf("Sent: 8088\n");
    correct += test(8088, 4);
    total++;
    printf("Sent: 123\n");
    correct += test(123, 0);
    total++;
    printf("Sent: 81238\n");
    correct += test(81238, 2);
    total++;
    printf("Sent: 88788\n");
    correct += test(88788, 6);
    total++;
    printf("Sent: 8234\n");
    correct += test(8234, 1);
    total++;
    printf("Sent: 2348\n");
    correct += test(2348, 1);
    total++;
    printf("Sent: 23884\n");
    correct += test(23884, 3);
    total++;
    printf("Sent: 0\n");
    correct += test(0, 0);
    total++;
    printf("Sent: 1818188\n");
    correct += test(1818188, 5);
    total++;
    printf("Sent: 8818181\n");
    correct += test(8818181, 5);
    total++;
    printf("Sent: 1080\n");
    correct += test(1080, 1);
    total++;
    printf("Sent: 188\n");
    correct += test(188, 3);
    total++;
    printf("Sent: 88888\n");
    correct += test(88888, 9);
    total++;
    printf("Sent: 9898\n");
    correct += test(9898, 2);
    total++;
    printf("Sent: 78\n");
    correct += test(78, 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

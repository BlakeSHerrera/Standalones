#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, compute recursively (no loops) the number of "11"
substrings in the string. The "11" substrings should not overlap.
*/

int count11(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = count11(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"11abc11\"\n");
    correct += test("11abc11", 2);
    total++;
    printf("Sent: \"abc11x11x11\"\n");
    correct += test("abc11x11x11", 3);
    total++;
    printf("Sent: \"111\"\n");
    correct += test("111", 1);
    total++;
    printf("Sent: \"1111\"\n");
    correct += test("1111", 2);
    total++;
    printf("Sent: \"1\"\n");
    correct += test("1", 0);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", 0);
    total++;
    printf("Sent: \"hi\"\n");
    correct += test("hi", 0);
    total++;
    printf("Sent: \"11x111x1111\"\n");
    correct += test("11x111x1111", 4);
    total++;
    printf("Sent: \"1x111\"\n");
    correct += test("1x111", 1);
    total++;
    printf("Sent: \"1Hello1\"\n");
    correct += test("1Hello1", 0);
    total++;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", 0);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return recursively a "cleaned" string where
adjacent chars that are the same have been reduced to a single
char. So "yyzzza" yields "yza".
*/

char * stringClean(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = stringClean(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"yyzzza\"\n");
    correct += test("yyzzza", "yza");
    total++;
    printf("Sent: \"abbbcdd\"\n");
    correct += test("abbbcdd", "abcd");
    total++;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "Helo");
    total++;
    printf("Sent: \"XXabcYY\"\n");
    correct += test("XXabcYY", "XabcY");
    total++;
    printf("Sent: \"112ab445\"\n");
    correct += test("112ab445", "12ab45");
    total++;
    printf("Sent: \"Hello Bookkeeper\"\n");
    correct += test("Hello Bookkeeper", "Helo Bokeper");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We have triangle made of blocks. The topmost row has 1 block, the
next row down has 2 blocks, the next row has 3 blocks, and so on.
Compute recursively (no loops or multiplication) the total number
of blocks in such a triangle with the given number of rows.
*/

int triangle(int rows)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int rows, int expected)
{
    int returned = triangle(rows);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 0\n");
    correct += test(0, 0);
    total++;
    printf("Sent: 1\n");
    correct += test(1, 1);
    total++;
    printf("Sent: 2\n");
    correct += test(2, 3);
    total++;
    printf("Sent: 3\n");
    correct += test(3, 6);
    total++;
    printf("Sent: 4\n");
    correct += test(4, 10);
    total++;
    printf("Sent: 5\n");
    correct += test(5, 15);
    total++;
    printf("Sent: 6\n");
    correct += test(6, 21);
    total++;
    printf("Sent: 7\n");
    correct += test(7, 28);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

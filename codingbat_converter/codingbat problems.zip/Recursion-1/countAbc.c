#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Count recursively the total number of "abc" and "aba" substrings
that appear in the given string.
*/

int countAbc(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = countAbc(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"abc\"\n");
    correct += test("abc", 1);
    total++;
    printf("Sent: \"abcxxabc\"\n");
    correct += test("abcxxabc", 2);
    total++;
    printf("Sent: \"abaxxaba\"\n");
    correct += test("abaxxaba", 2);
    total++;
    printf("Sent: \"ababc\"\n");
    correct += test("ababc", 2);
    total++;
    printf("Sent: \"abxbc\"\n");
    correct += test("abxbc", 0);
    total++;
    printf("Sent: \"aaabc\"\n");
    correct += test("aaabc", 1);
    total++;
    printf("Sent: \"hello\"\n");
    correct += test("hello", 0);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", 0);
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", 0);
    total++;
    printf("Sent: \"aba\"\n");
    correct += test("aba", 1);
    total++;
    printf("Sent: \"aca\"\n");
    correct += test("aca", 0);
    total++;
    printf("Sent: \"aaa\"\n");
    correct += test("aaa", 0);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, compute recursively a new string where all the
adjacent chars are now separated by a "*".
*/

char * allStar(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = allStar(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"hello\"\n");
    correct += test("hello", "h*e*l*l*o");
    total++;
    printf("Sent: \"abc\"\n");
    correct += test("abc", "a*b*c");
    total++;
    printf("Sent: \"ab\"\n");
    correct += test("ab", "a*b");
    total++;
    printf("Sent: \"a\"\n");
    correct += test("a", "a");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"3.14\"\n");
    correct += test("3.14", "3*.*1*4");
    total++;
    printf("Sent: \"Chocolate\"\n");
    correct += test("Chocolate", "C*h*o*c*o*l*a*t*e");
    total++;
    printf("Sent: \"1234\"\n");
    correct += test("1234", "1*2*3*4");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, compute recursively a new string where identical
chars that are adjacent in the original string are separated from
each other by a "*".
*/

char * pairStar(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = pairStar(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"hello\"\n");
    correct += test("hello", "hel*lo");
    total++;
    printf("Sent: \"xxyy\"\n");
    correct += test("xxyy", "x*xy*y");
    total++;
    printf("Sent: \"aaaa\"\n");
    correct += test("aaaa", "a*a*a*a");
    total++;
    printf("Sent: \"aaab\"\n");
    correct += test("aaab", "a*a*ab");
    total++;
    printf("Sent: \"aa\"\n");
    correct += test("aa", "a*a");
    total++;
    printf("Sent: \"a\"\n");
    correct += test("a", "a");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"noadjacent\"\n");
    correct += test("noadjacent", "noadjacent");
    total++;
    printf("Sent: \"abba\"\n");
    correct += test("abba", "ab*ba");
    total++;
    printf("Sent: \"abbba\"\n");
    correct += test("abbba", "ab*b*ba");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

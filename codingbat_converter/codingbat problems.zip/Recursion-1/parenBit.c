#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string that contains a single pair of parenthesis,
compute recursively a new string made of only of the parenthesis
and their contents, so "xyz(abc)123" yields "(abc)".
*/

char * parenBit(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = parenBit(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: abc\n");
    correct += test(abc, "(abc)");
    total++;
    printf("Sent: hello\n");
    correct += test(hello, "(hello)");
    total++;
    printf("Sent: xy\n");
    correct += test(xy, "(xy)");
    total++;
    printf("Sent: possible\n");
    correct += test(possible, "(possible)");
    total++;
    printf("Sent: abc\n");
    correct += test(abc, "(abc)");
    total++;
    printf("Sent: abc\n");
    correct += test(abc, "(abc)");
    total++;
    printf("Sent: abc\n");
    correct += test(abc, "(abc)");
    total++;
    printf("Sent: x\n");
    correct += test(x, "(x)");
    total++;
    printf("Sent: \n");
    correct += test("()");
    total++;
    printf("Sent: ipsa\n");
    correct += test(ipsa, "(ipsa)");
    total++;
    printf("Sent: not really\n");
    correct += test(not really, "(not really)");
    total++;
    printf("Sent: ab\n");
    correct += test(ab, "(ab)");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

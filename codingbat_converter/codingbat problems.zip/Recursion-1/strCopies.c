#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string and a non-empty substring sub, compute recursively
if at least n copies of sub appear in the string somewhere,
possibly with overlapping. N will be non-negative.
*/

int strCopies(char * str, char * sub, int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * sub, int n, int expected)
{
    int returned = strCopies(str, sub, n);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"catcowcat\", \"cat\", 2\n");
    correct += test("catcowcat", "cat", 2, TRUE);
    total++;
    printf("Sent: \"catcowcat\", \"cow\", 2\n");
    correct += test("catcowcat", "cow", 2, FALSE);
    total++;
    printf("Sent: \"catcowcat\", \"cow\", 1\n");
    correct += test("catcowcat", "cow", 1, TRUE);
    total++;
    printf("Sent: \"iiijjj\", \"i\", 3\n");
    correct += test("iiijjj", "i", 3, TRUE);
    total++;
    printf("Sent: \"iiijjj\", \"i\", 4\n");
    correct += test("iiijjj", "i", 4, FALSE);
    total++;
    printf("Sent: \"iiijjj\", \"ii\", 2\n");
    correct += test("iiijjj", "ii", 2, TRUE);
    total++;
    printf("Sent: \"iiijjj\", \"ii\", 3\n");
    correct += test("iiijjj", "ii", 3, FALSE);
    total++;
    printf("Sent: \"iiijjj\", \"x\", 3\n");
    correct += test("iiijjj", "x", 3, FALSE);
    total++;
    printf("Sent: \"iiijjj\", \"x\", 0\n");
    correct += test("iiijjj", "x", 0, TRUE);
    total++;
    printf("Sent: \"iiiiij\", \"iii\", 3\n");
    correct += test("iiiiij", "iii", 3, TRUE);
    total++;
    printf("Sent: \"iiiiij\", \"iii\", 4\n");
    correct += test("iiiiij", "iii", 4, FALSE);
    total++;
    printf("Sent: \"ijiiiiij\", \"iiii\", 2\n");
    correct += test("ijiiiiij", "iiii", 2, TRUE);
    total++;
    printf("Sent: \"ijiiiiij\", \"iiii\", 3\n");
    correct += test("ijiiiiij", "iiii", 3, FALSE);
    total++;
    printf("Sent: \"dogcatdogcat\", \"dog\", 2\n");
    correct += test("dogcatdogcat", "dog", 2, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

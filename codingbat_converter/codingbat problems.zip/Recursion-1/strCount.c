#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string and a non-empty substring sub, compute recursively
the number of times that sub appears in the string, without the
sub strings overlapping.
*/

int strCount(char * str, char * sub)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * sub, int expected)
{
    int returned = strCount(str, sub);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"catcowcat\", \"cat\"\n");
    correct += test("catcowcat", "cat", 2);
    total++;
    printf("Sent: \"catcowcat\", \"cow\"\n");
    correct += test("catcowcat", "cow", 1);
    total++;
    printf("Sent: \"catcowcat\", \"dog\"\n");
    correct += test("catcowcat", "dog", 0);
    total++;
    printf("Sent: \"cacatcowcat\", \"cat\"\n");
    correct += test("cacatcowcat", "cat", 2);
    total++;
    printf("Sent: \"xyx\", \"x\"\n");
    correct += test("xyx", "x", 2);
    total++;
    printf("Sent: \"iiiijj\", \"i\"\n");
    correct += test("iiiijj", "i", 4);
    total++;
    printf("Sent: \"iiiijj\", \"ii\"\n");
    correct += test("iiiijj", "ii", 2);
    total++;
    printf("Sent: \"iiiijj\", \"iii\"\n");
    correct += test("iiiijj", "iii", 1);
    total++;
    printf("Sent: \"iiiijj\", \"j\"\n");
    correct += test("iiiijj", "j", 2);
    total++;
    printf("Sent: \"iiiijj\", \"jj\"\n");
    correct += test("iiiijj", "jj", 1);
    total++;
    printf("Sent: \"aaabababab\", \"ab\"\n");
    correct += test("aaabababab", "ab", 4);
    total++;
    printf("Sent: \"aaabababab\", \"aa\"\n");
    correct += test("aaabababab", "aa", 1);
    total++;
    printf("Sent: \"aaabababab\", \"a\"\n");
    correct += test("aaabababab", "a", 6);
    total++;
    printf("Sent: \"aaabababab\", \"b\"\n");
    correct += test("aaabababab", "b", 4);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

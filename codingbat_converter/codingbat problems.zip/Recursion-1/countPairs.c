#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We'll say that a "pair" in a string is two instances of a char
separated by a char. So "AxA" the A's make a pair. Pair's can
overlap, so "AxAxA" contains 3 pairs -- 2 for A and 1 for x.
Recursively compute the number of pairs in the given string.
*/

int countPairs(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = countPairs(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"axa\"\n");
    correct += test("axa", 1);
    total++;
    printf("Sent: \"axax\"\n");
    correct += test("axax", 2);
    total++;
    printf("Sent: \"axbx\"\n");
    correct += test("axbx", 1);
    total++;
    printf("Sent: \"hi\"\n");
    correct += test("hi", 0);
    total++;
    printf("Sent: \"hihih\"\n");
    correct += test("hihih", 3);
    total++;
    printf("Sent: \"ihihhh\"\n");
    correct += test("ihihhh", 3);
    total++;
    printf("Sent: \"ihjxhh\"\n");
    correct += test("ihjxhh", 0);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", 0);
    total++;
    printf("Sent: \"a\"\n");
    correct += test("a", 0);
    total++;
    printf("Sent: \"aa\"\n");
    correct += test("aa", 0);
    total++;
    printf("Sent: \"aaa\"\n");
    correct += test("aaa", 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given base and n that are both 1 or more, compute recursively (no
loops) the value of base to the n power, so powerN(3, 2) is 9 (3
squared).
*/

int powerN(int base, int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int base, int n, int expected)
{
    int returned = powerN(base, n);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 3, 1\n");
    correct += test(3, 1, 3);
    total++;
    printf("Sent: 3, 2\n");
    correct += test(3, 2, 9);
    total++;
    printf("Sent: 3, 3\n");
    correct += test(3, 3, 27);
    total++;
    printf("Sent: 2, 1\n");
    correct += test(2, 1, 2);
    total++;
    printf("Sent: 2, 2\n");
    correct += test(2, 2, 4);
    total++;
    printf("Sent: 2, 3\n");
    correct += test(2, 3, 8);
    total++;
    printf("Sent: 2, 4\n");
    correct += test(2, 4, 16);
    total++;
    printf("Sent: 2, 5\n");
    correct += test(2, 5, 32);
    total++;
    printf("Sent: 10, 1\n");
    correct += test(10, 1, 10);
    total++;
    printf("Sent: 10, 2\n");
    correct += test(10, 2, 100);
    total++;
    printf("Sent: 10, 3\n");
    correct += test(10, 3, 1000);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
The fibonacci sequence is a famous bit of mathematics, and it
happens to have a recursive definition. The first two values in
the sequence are 0 and 1 (essentially 2 base cases). Each
subsequent value is the sum of the previous two values, so the
whole sequence is: 0, 1, 1, 2, 3, 5, 8, 13, 21 and so on. Define
a recursive fibonacci(n) method that returns the nth fibonacci
number, with n=0 representing the start of the sequence.
*/

int fibonacci(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int expected)
{
    int returned = fibonacci(n);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 0\n");
    correct += test(0, 0);
    total++;
    printf("Sent: 1\n");
    correct += test(1, 1);
    total++;
    printf("Sent: 2\n");
    correct += test(2, 1);
    total++;
    printf("Sent: 3\n");
    correct += test(3, 2);
    total++;
    printf("Sent: 4\n");
    correct += test(4, 3);
    total++;
    printf("Sent: 5\n");
    correct += test(5, 5);
    total++;
    printf("Sent: 6\n");
    correct += test(6, 8);
    total++;
    printf("Sent: 7\n");
    correct += test(7, 13);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, compute recursively if the array contains
somewhere a value followed in the array by that value times 10.
We'll use the convention of considering only the part of the
array that begins at the given index. In this way, a recursive
call can pass index+1 to move down the array. The initial call
will pass in index as 0.
*/

int array220(int nums[], int numsSize, int index)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int index, int expected)
{
    int returned = array220(nums, numsSize, index);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 20], 0\n");
    correct += test((int[]){1, 2, 20}, 3, 0, TRUE);
    total++;
    printf("Sent: [3, 30], 0\n");
    correct += test((int[]){3, 30}, 2, 0, TRUE);
    total++;
    printf("Sent: [3], 0\n");
    correct += test((int[]){3}, 1, 0, FALSE);
    total++;
    printf("Sent: [], 0\n");
    correct += test((int[]){}, 1, 0, FALSE);
    total++;
    printf("Sent: [3, 3, 30, 4], 0\n");
    correct += test((int[]){3, 3, 30, 4}, 4, 0, TRUE);
    total++;
    printf("Sent: [2, 19, 4], 0\n");
    correct += test((int[]){2, 19, 4}, 3, 0, FALSE);
    total++;
    printf("Sent: [20, 2, 21], 0\n");
    correct += test((int[]){20, 2, 21}, 3, 0, FALSE);
    total++;
    printf("Sent: [20, 2, 21, 210], 0\n");
    correct += test((int[]){20, 2, 21, 210}, 4, 0, TRUE);
    total++;
    printf("Sent: [2, 200, 2000], 0\n");
    correct += test((int[]){2, 200, 2000}, 3, 0, TRUE);
    total++;
    printf("Sent: [0, 0], 0\n");
    correct += test((int[]){0, 0}, 2, 0, TRUE);
    total++;
    printf("Sent: [1, 2, 3, 4, 5, 6], 0\n");
    correct += test((int[]){1, 2, 3, 4, 5, 6}, 6, 0, FALSE);
    total++;
    printf("Sent: [1, 2, 3, 4, 5, 50, 6], 0\n");
    correct += test((int[]){1, 2, 3, 4, 5, 50, 6}, 7, 0, TRUE);
    total++;
    printf("Sent: [1, 2, 3, 4, 5, 51, 6], 0\n");
    correct += test((int[]){1, 2, 3, 4, 5, 51, 6}, 7, 0, FALSE);
    total++;
    printf("Sent: [1, 2, 3, 4, 4, 50, 500, 6], 0\n");
    correct += test((int[]){1, 2, 3, 4, 4, 50, 500, 6}, 8, 0, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

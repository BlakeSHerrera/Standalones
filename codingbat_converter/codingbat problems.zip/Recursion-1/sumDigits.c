#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a non-negative int n, return the sum of its digits
recursively (no loops). Note that mod (%) by 10 yields the
rightmost digit (126 % 10 is 6), while divide (/) by 10 removes
the rightmost digit (126 / 10 is 12).
*/

int sumDigits(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int expected)
{
    int returned = sumDigits(n);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 126\n");
    correct += test(126, 9);
    total++;
    printf("Sent: 49\n");
    correct += test(49, 13);
    total++;
    printf("Sent: 12\n");
    correct += test(12, 3);
    total++;
    printf("Sent: 10\n");
    correct += test(10, 1);
    total++;
    printf("Sent: 1\n");
    correct += test(1, 1);
    total++;
    printf("Sent: 0\n");
    correct += test(0, 0);
    total++;
    printf("Sent: 730\n");
    correct += test(730, 10);
    total++;
    printf("Sent: 1111\n");
    correct += test(1111, 4);
    total++;
    printf("Sent: 11111\n");
    correct += test(11111, 5);
    total++;
    printf("Sent: 10110\n");
    correct += test(10110, 3);
    total++;
    printf("Sent: 235\n");
    correct += test(235, 10);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, compute recursively (no loops) the number of
lowercase 'x' chars in the string.
*/

int countX(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = countX(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"xxhixx\"\n");
    correct += test("xxhixx", 4);
    total++;
    printf("Sent: \"xhixhix\"\n");
    correct += test("xhixhix", 3);
    total++;
    printf("Sent: \"hi\"\n");
    correct += test("hi", 0);
    total++;
    printf("Sent: \"h\"\n");
    correct += test("h", 0);
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", 1);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", 0);
    total++;
    printf("Sent: \"hihi\"\n");
    correct += test("hihi", 0);
    total++;
    printf("Sent: \"hiAAhi12hi\"\n");
    correct += test("hiAAhi12hi", 0);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

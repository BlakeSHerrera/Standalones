#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, compute recursively the number of times lowercase
"hi" appears in the string, however do not count "hi" that have
an 'x' immedately before them.
*/

int countHi2(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = countHi2(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"ahixhi\"\n");
    correct += test("ahixhi", 1);
    total++;
    printf("Sent: \"ahibhi\"\n");
    correct += test("ahibhi", 2);
    total++;
    printf("Sent: \"xhixhi\"\n");
    correct += test("xhixhi", 0);
    total++;
    printf("Sent: \"hixhi\"\n");
    correct += test("hixhi", 1);
    total++;
    printf("Sent: \"hixhhi\"\n");
    correct += test("hixhhi", 2);
    total++;
    printf("Sent: \"hihihi\"\n");
    correct += test("hihihi", 3);
    total++;
    printf("Sent: \"hihihix\"\n");
    correct += test("hihihix", 3);
    total++;
    printf("Sent: \"xhihihix\"\n");
    correct += test("xhihihix", 2);
    total++;
    printf("Sent: \"xxhi\"\n");
    correct += test("xxhi", 0);
    total++;
    printf("Sent: \"hixxhi\"\n");
    correct += test("hixxhi", 1);
    total++;
    printf("Sent: \"hi\"\n");
    correct += test("hi", 1);
    total++;
    printf("Sent: \"xxxx\"\n");
    correct += test("xxxx", 0);
    total++;
    printf("Sent: \"h\"\n");
    correct += test("h", 0);
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", 0);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", 0);
    total++;
    printf("Sent: \"Hellohi\"\n");
    correct += test("Hellohi", 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

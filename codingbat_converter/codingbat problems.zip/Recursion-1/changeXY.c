#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, compute recursively (no loops) a new string where
all the lowercase 'x' chars have been changed to 'y' chars.
*/

char * changeXY(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = changeXY(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"codex\"\n");
    correct += test("codex", "codey");
    total++;
    printf("Sent: \"xxhixx\"\n");
    correct += test("xxhixx", "yyhiyy");
    total++;
    printf("Sent: \"xhixhix\"\n");
    correct += test("xhixhix", "yhiyhiy");
    total++;
    printf("Sent: \"hiy\"\n");
    correct += test("hiy", "hiy");
    total++;
    printf("Sent: \"h\"\n");
    correct += test("h", "h");
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", "y");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"xxx\"\n");
    correct += test("xxx", "yyy");
    total++;
    printf("Sent: \"yyhxyi\"\n");
    correct += test("yyhxyi", "yyhyyi");
    total++;
    printf("Sent: \"hihi\"\n");
    correct += test("hihi", "hihi");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

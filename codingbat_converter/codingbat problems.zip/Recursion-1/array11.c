#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, compute recursively the number of times
that the value 11 appears in the array. We'll use the convention
of considering only the part of the array that begins at the
given index. In this way, a recursive call can pass index+1 to
move down the array. The initial call will pass in index as 0.
*/

int array11(int nums[], int numsSize, int index)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int index, int expected)
{
    int returned = array11(nums, numsSize, index);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 11], 0\n");
    correct += test((int[]){1, 2, 11}, 3, 0, 1);
    total++;
    printf("Sent: [11, 11], 0\n");
    correct += test((int[]){11, 11}, 2, 0, 2);
    total++;
    printf("Sent: [1, 2, 3, 4], 0\n");
    correct += test((int[]){1, 2, 3, 4}, 4, 0, 0);
    total++;
    printf("Sent: [1, 11, 3, 11, 11], 0\n");
    correct += test((int[]){1, 11, 3, 11, 11}, 5, 0, 3);
    total++;
    printf("Sent: [11], 0\n");
    correct += test((int[]){11}, 1, 0, 1);
    total++;
    printf("Sent: [1], 0\n");
    correct += test((int[]){1}, 1, 0, 0);
    total++;
    printf("Sent: [], 0\n");
    correct += test((int[]){}, 1, 0, 0);
    total++;
    printf("Sent: [11, 2, 3, 4, 11, 5], 0\n");
    correct += test((int[]){11, 2, 3, 4, 11, 5}, 6, 0, 2);
    total++;
    printf("Sent: [11, 5, 11], 0\n");
    correct += test((int[]){11, 5, 11}, 3, 0, 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string and a non-empty substring sub, compute recursively
the largest substring which starts and ends with sub and return
its length.
*/

int strDist(char * str, char * sub)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * sub, int expected)
{
    int returned = strDist(str, sub);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"catcowcat\", \"cat\"\n");
    correct += test("catcowcat", "cat", 9);
    total++;
    printf("Sent: \"catcowcat\", \"cow\"\n");
    correct += test("catcowcat", "cow", 3);
    total++;
    printf("Sent: \"cccatcowcatxx\", \"cat\"\n");
    correct += test("cccatcowcatxx", "cat", 9);
    total++;
    printf("Sent: \"abccatcowcatcatxyz\", \"cat\"\n");
    correct += test("abccatcowcatcatxyz", "cat", 12);
    total++;
    printf("Sent: \"xyx\", \"x\"\n");
    correct += test("xyx", "x", 3);
    total++;
    printf("Sent: \"xyx\", \"y\"\n");
    correct += test("xyx", "y", 1);
    total++;
    printf("Sent: \"xyx\", \"z\"\n");
    correct += test("xyx", "z", 0);
    total++;
    printf("Sent: \"z\", \"z\"\n");
    correct += test("z", "z", 1);
    total++;
    printf("Sent: \"x\", \"z\"\n");
    correct += test("x", "z", 0);
    total++;
    printf("Sent: \"\", \"z\"\n");
    correct += test("", "z", 0);
    total++;
    printf("Sent: \"hiHellohihihi\", \"hi\"\n");
    correct += test("hiHellohihihi", "hi", 13);
    total++;
    printf("Sent: \"hiHellohihihi\", \"hih\"\n");
    correct += test("hiHellohihihi", "hih", 5);
    total++;
    printf("Sent: \"hiHellohihihi\", \"o\"\n");
    correct += test("hiHellohihihi", "o", 1);
    total++;
    printf("Sent: \"hiHellohihihi\", \"ll\"\n");
    correct += test("hiHellohihihi", "ll", 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, compute recursively (no loops) the number of
times lowercase "hi" appears in the string.
*/

int countHi(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = countHi(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"xxhixx\"\n");
    correct += test("xxhixx", 1);
    total++;
    printf("Sent: \"xhixhix\"\n");
    correct += test("xhixhix", 2);
    total++;
    printf("Sent: \"hi\"\n");
    correct += test("hi", 1);
    total++;
    printf("Sent: \"hihih\"\n");
    correct += test("hihih", 2);
    total++;
    printf("Sent: \"h\"\n");
    correct += test("h", 0);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", 0);
    total++;
    printf("Sent: \"ihihihihih\"\n");
    correct += test("ihihihihih", 4);
    total++;
    printf("Sent: \"ihihihihihi\"\n");
    correct += test("ihihihihihi", 5);
    total++;
    printf("Sent: \"hiAAhi12hi\"\n");
    correct += test("hiAAhi12hi", 3);
    total++;
    printf("Sent: \"xhixhxihihhhih\"\n");
    correct += test("xhixhxihihhhih", 3);
    total++;
    printf("Sent: \"ship\"\n");
    correct += test("ship", 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

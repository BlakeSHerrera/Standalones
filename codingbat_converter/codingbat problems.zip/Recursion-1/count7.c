#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a non-negative int n, return the count of the occurrences
of 7 as a digit, so for example 717 yields 2. (no loops). Note
that mod (%) by 10 yields the rightmost digit (126 % 10 is 6),
while divide (/) by 10 removes the rightmost digit (126 / 10 is
12).
*/

int count7(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int expected)
{
    int returned = count7(n);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 717\n");
    correct += test(717, 2);
    total++;
    printf("Sent: 7\n");
    correct += test(7, 1);
    total++;
    printf("Sent: 123\n");
    correct += test(123, 0);
    total++;
    printf("Sent: 77\n");
    correct += test(77, 2);
    total++;
    printf("Sent: 7123\n");
    correct += test(7123, 1);
    total++;
    printf("Sent: 771237\n");
    correct += test(771237, 3);
    total++;
    printf("Sent: 771737\n");
    correct += test(771737, 4);
    total++;
    printf("Sent: 47571\n");
    correct += test(47571, 2);
    total++;
    printf("Sent: 777777\n");
    correct += test(777777, 6);
    total++;
    printf("Sent: 70701277\n");
    correct += test(70701277, 4);
    total++;
    printf("Sent: 777576197\n");
    correct += test(777576197, 5);
    total++;
    printf("Sent: 99999\n");
    correct += test(99999, 0);
    total++;
    printf("Sent: 99799\n");
    correct += test(99799, 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a non-negative number "num", return TRUE if num is within 2
of a multiple of 10. Note: (a % b) is the remainder of dividing a
by b, so (7 % 5) is 2. See also: Introduction to Mod
*/

int nearTen(int num)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int num, int expected)
{
    int returned = nearTen(num);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 12\n");
    correct += test(12, TRUE);
    total++;
    printf("Sent: 17\n");
    correct += test(17, FALSE);
    total++;
    printf("Sent: 19\n");
    correct += test(19, TRUE);
    total++;
    printf("Sent: 31\n");
    correct += test(31, TRUE);
    total++;
    printf("Sent: 6\n");
    correct += test(6, FALSE);
    total++;
    printf("Sent: 10\n");
    correct += test(10, TRUE);
    total++;
    printf("Sent: 11\n");
    correct += test(11, TRUE);
    total++;
    printf("Sent: 21\n");
    correct += test(21, TRUE);
    total++;
    printf("Sent: 22\n");
    correct += test(22, TRUE);
    total++;
    printf("Sent: 23\n");
    correct += test(23, FALSE);
    total++;
    printf("Sent: 54\n");
    correct += test(54, FALSE);
    total++;
    printf("Sent: 155\n");
    correct += test(155, FALSE);
    total++;
    printf("Sent: 158\n");
    correct += test(158, TRUE);
    total++;
    printf("Sent: 3\n");
    correct += test(3, FALSE);
    total++;
    printf("Sent: 1\n");
    correct += test(1, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

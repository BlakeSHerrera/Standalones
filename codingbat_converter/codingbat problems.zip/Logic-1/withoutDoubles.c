#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return the sum of two 6-sided dice rolls, each in the range 1..6.
However, if noDoubles is TRUE, if the two dice show the same
value, increment one die to the next value, wrapping around to 1
if its value was 6.
*/

int withoutDoubles(int die1, int die2, int noDoubles)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int die1, int die2, int noDoubles, int expected)
{
    int returned = withoutDoubles(die1, die2, noDoubles);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 2, 3, TRUE\n");
    correct += test(2, 3, TRUE, 5);
    total++;
    printf("Sent: 3, 3, TRUE\n");
    correct += test(3, 3, TRUE, 7);
    total++;
    printf("Sent: 3, 3, FALSE\n");
    correct += test(3, 3, FALSE, 6);
    total++;
    printf("Sent: 2, 3, FALSE\n");
    correct += test(2, 3, FALSE, 5);
    total++;
    printf("Sent: 5, 4, TRUE\n");
    correct += test(5, 4, TRUE, 9);
    total++;
    printf("Sent: 5, 4, FALSE\n");
    correct += test(5, 4, FALSE, 9);
    total++;
    printf("Sent: 5, 5, TRUE\n");
    correct += test(5, 5, TRUE, 11);
    total++;
    printf("Sent: 5, 5, FALSE\n");
    correct += test(5, 5, FALSE, 10);
    total++;
    printf("Sent: 6, 6, TRUE\n");
    correct += test(6, 6, TRUE, 7);
    total++;
    printf("Sent: 6, 6, FALSE\n");
    correct += test(6, 6, FALSE, 12);
    total++;
    printf("Sent: 1, 6, TRUE\n");
    correct += test(1, 6, TRUE, 7);
    total++;
    printf("Sent: 6, 1, FALSE\n");
    correct += test(6, 1, FALSE, 7);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

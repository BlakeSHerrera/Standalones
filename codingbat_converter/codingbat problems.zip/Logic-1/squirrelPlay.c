#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
The squirrels in Palo Alto spend most of the day playing. In
particular, they play if the temperature is between 60 and 90
(inclusive). Unless it is summer, then the upper limit is 100
instead of 90. Given an int temperature and a int isSummer,
return TRUE if the squirrels play and FALSE otherwise.
*/

int squirrelPlay(int temp, int isSummer)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int temp, int isSummer, int expected)
{
    int returned = squirrelPlay(temp, isSummer);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 70, FALSE\n");
    correct += test(70, FALSE, TRUE);
    total++;
    printf("Sent: 95, FALSE\n");
    correct += test(95, FALSE, FALSE);
    total++;
    printf("Sent: 95, TRUE\n");
    correct += test(95, TRUE, TRUE);
    total++;
    printf("Sent: 90, FALSE\n");
    correct += test(90, FALSE, TRUE);
    total++;
    printf("Sent: 90, TRUE\n");
    correct += test(90, TRUE, TRUE);
    total++;
    printf("Sent: 50, FALSE\n");
    correct += test(50, FALSE, FALSE);
    total++;
    printf("Sent: 50, TRUE\n");
    correct += test(50, TRUE, FALSE);
    total++;
    printf("Sent: 100, FALSE\n");
    correct += test(100, FALSE, FALSE);
    total++;
    printf("Sent: 100, TRUE\n");
    correct += test(100, TRUE, TRUE);
    total++;
    printf("Sent: 105, TRUE\n");
    correct += test(105, TRUE, FALSE);
    total++;
    printf("Sent: 59, FALSE\n");
    correct += test(59, FALSE, FALSE);
    total++;
    printf("Sent: 59, TRUE\n");
    correct += test(59, TRUE, FALSE);
    total++;
    printf("Sent: 60, FALSE\n");
    correct += test(60, FALSE, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

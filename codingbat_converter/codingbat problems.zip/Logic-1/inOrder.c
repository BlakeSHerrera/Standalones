#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given three ints, a b c, return TRUE if b is greater than a, and
c is greater than b. However, with the exception that if "bOk" is
TRUE, b does not need to be greater than a.
*/

int inOrder(int a, int b, int c, int bOk)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int c, int bOk, int expected)
{
    int returned = inOrder(a, b, c, bOk);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 1, 2, 4, FALSE\n");
    correct += test(1, 2, 4, FALSE, TRUE);
    total++;
    printf("Sent: 1, 2, 1, FALSE\n");
    correct += test(1, 2, 1, FALSE, FALSE);
    total++;
    printf("Sent: 1, 1, 2, TRUE\n");
    correct += test(1, 1, 2, TRUE, TRUE);
    total++;
    printf("Sent: 3, 2, 4, FALSE\n");
    correct += test(3, 2, 4, FALSE, FALSE);
    total++;
    printf("Sent: 2, 3, 4, FALSE\n");
    correct += test(2, 3, 4, FALSE, TRUE);
    total++;
    printf("Sent: 3, 2, 4, TRUE\n");
    correct += test(3, 2, 4, TRUE, TRUE);
    total++;
    printf("Sent: 4, 2, 2, TRUE\n");
    correct += test(4, 2, 2, TRUE, FALSE);
    total++;
    printf("Sent: 4, 5, 2, TRUE\n");
    correct += test(4, 5, 2, TRUE, FALSE);
    total++;
    printf("Sent: 2, 4, 6, TRUE\n");
    correct += test(2, 4, 6, TRUE, TRUE);
    total++;
    printf("Sent: 7, 9, 10, FALSE\n");
    correct += test(7, 9, 10, FALSE, TRUE);
    total++;
    printf("Sent: 7, 5, 6, TRUE\n");
    correct += test(7, 5, 6, TRUE, TRUE);
    total++;
    printf("Sent: 7, 5, 4, TRUE\n");
    correct += test(7, 5, 4, TRUE, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

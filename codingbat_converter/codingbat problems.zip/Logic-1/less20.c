#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return TRUE if the given non-negative number is 1 or 2 less than
a multiple of 20. So for example 38 and 39 return TRUE, but 40
returns FALSE. See also: Introduction to Mod
*/

int less20(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int expected)
{
    int returned = less20(n);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 18\n");
    correct += test(18, TRUE);
    total++;
    printf("Sent: 19\n");
    correct += test(19, TRUE);
    total++;
    printf("Sent: 20\n");
    correct += test(20, FALSE);
    total++;
    printf("Sent: 8\n");
    correct += test(8, FALSE);
    total++;
    printf("Sent: 17\n");
    correct += test(17, FALSE);
    total++;
    printf("Sent: 23\n");
    correct += test(23, FALSE);
    total++;
    printf("Sent: 25\n");
    correct += test(25, FALSE);
    total++;
    printf("Sent: 30\n");
    correct += test(30, FALSE);
    total++;
    printf("Sent: 31\n");
    correct += test(31, FALSE);
    total++;
    printf("Sent: 58\n");
    correct += test(58, TRUE);
    total++;
    printf("Sent: 59\n");
    correct += test(59, TRUE);
    total++;
    printf("Sent: 60\n");
    correct += test(60, FALSE);
    total++;
    printf("Sent: 61\n");
    correct += test(61, FALSE);
    total++;
    printf("Sent: 62\n");
    correct += test(62, FALSE);
    total++;
    printf("Sent: 1017\n");
    correct += test(1017, FALSE);
    total++;
    printf("Sent: 1018\n");
    correct += test(1018, TRUE);
    total++;
    printf("Sent: 1019\n");
    correct += test(1019, TRUE);
    total++;
    printf("Sent: 1020\n");
    correct += test(1020, FALSE);
    total++;
    printf("Sent: 1021\n");
    correct += test(1021, FALSE);
    total++;
    printf("Sent: 1022\n");
    correct += test(1022, FALSE);
    total++;
    printf("Sent: 1023\n");
    correct += test(1023, FALSE);
    total++;
    printf("Sent: 37\n");
    correct += test(37, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

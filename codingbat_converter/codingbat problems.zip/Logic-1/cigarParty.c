#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
When squirrels get together for a party, they like to have
cigars. A squirrel party is successful when the number of cigars
is between 40 and 60, inclusive. Unless it is the weekend, in
which case there is no upper bound on the number of cigars.
Return TRUE if the party with the given values is successful, or
FALSE otherwise.
*/

int cigarParty(int cigars, int isWeekend)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int cigars, int isWeekend, int expected)
{
    int returned = cigarParty(cigars, isWeekend);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 30, FALSE\n");
    correct += test(30, FALSE, FALSE);
    total++;
    printf("Sent: 50, FALSE\n");
    correct += test(50, FALSE, TRUE);
    total++;
    printf("Sent: 70, TRUE\n");
    correct += test(70, TRUE, TRUE);
    total++;
    printf("Sent: 30, TRUE\n");
    correct += test(30, TRUE, FALSE);
    total++;
    printf("Sent: 50, TRUE\n");
    correct += test(50, TRUE, TRUE);
    total++;
    printf("Sent: 60, FALSE\n");
    correct += test(60, FALSE, TRUE);
    total++;
    printf("Sent: 61, FALSE\n");
    correct += test(61, FALSE, FALSE);
    total++;
    printf("Sent: 40, FALSE\n");
    correct += test(40, FALSE, TRUE);
    total++;
    printf("Sent: 39, FALSE\n");
    correct += test(39, FALSE, FALSE);
    total++;
    printf("Sent: 40, TRUE\n");
    correct += test(40, TRUE, TRUE);
    total++;
    printf("Sent: 39, TRUE\n");
    correct += test(39, TRUE, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 ints, a and b, return their sum. However, "teen" values
in the range 13..19 inclusive, are extra lucky. So if either
value is a teen, just return 19.
*/

int teenSum(int a, int b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int expected)
{
    int returned = teenSum(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 3, 4\n");
    correct += test(3, 4, 7);
    total++;
    printf("Sent: 10, 13\n");
    correct += test(10, 13, 19);
    total++;
    printf("Sent: 13, 2\n");
    correct += test(13, 2, 19);
    total++;
    printf("Sent: 3, 19\n");
    correct += test(3, 19, 19);
    total++;
    printf("Sent: 13, 13\n");
    correct += test(13, 13, 19);
    total++;
    printf("Sent: 10, 10\n");
    correct += test(10, 10, 20);
    total++;
    printf("Sent: 6, 14\n");
    correct += test(6, 14, 19);
    total++;
    printf("Sent: 15, 2\n");
    correct += test(15, 2, 19);
    total++;
    printf("Sent: 19, 19\n");
    correct += test(19, 19, 19);
    total++;
    printf("Sent: 19, 20\n");
    correct += test(19, 20, 19);
    total++;
    printf("Sent: 2, 18\n");
    correct += test(2, 18, 19);
    total++;
    printf("Sent: 12, 4\n");
    correct += test(12, 4, 16);
    total++;
    printf("Sent: 2, 20\n");
    correct += test(2, 20, 22);
    total++;
    printf("Sent: 2, 17\n");
    correct += test(2, 17, 19);
    total++;
    printf("Sent: 2, 16\n");
    correct += test(2, 16, 19);
    total++;
    printf("Sent: 6, 7\n");
    correct += test(6, 7, 13);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

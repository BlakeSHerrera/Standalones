#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We'll say a number is special if it is a multiple of 11 or if it
is one more than a multiple of 11. Return TRUE if the given
non-negative number is special. Use the % "mod" operator -- see
Introduction to Mod
*/

int specialEleven(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int expected)
{
    int returned = specialEleven(n);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 22\n");
    correct += test(22, TRUE);
    total++;
    printf("Sent: 23\n");
    correct += test(23, TRUE);
    total++;
    printf("Sent: 24\n");
    correct += test(24, FALSE);
    total++;
    printf("Sent: 21\n");
    correct += test(21, FALSE);
    total++;
    printf("Sent: 11\n");
    correct += test(11, TRUE);
    total++;
    printf("Sent: 12\n");
    correct += test(12, TRUE);
    total++;
    printf("Sent: 10\n");
    correct += test(10, FALSE);
    total++;
    printf("Sent: 9\n");
    correct += test(9, FALSE);
    total++;
    printf("Sent: 8\n");
    correct += test(8, FALSE);
    total++;
    printf("Sent: 0\n");
    correct += test(0, TRUE);
    total++;
    printf("Sent: 1\n");
    correct += test(1, TRUE);
    total++;
    printf("Sent: 2\n");
    correct += test(2, FALSE);
    total++;
    printf("Sent: 121\n");
    correct += test(121, TRUE);
    total++;
    printf("Sent: 122\n");
    correct += test(122, TRUE);
    total++;
    printf("Sent: 123\n");
    correct += test(123, FALSE);
    total++;
    printf("Sent: 46\n");
    correct += test(46, FALSE);
    total++;
    printf("Sent: 49\n");
    correct += test(49, FALSE);
    total++;
    printf("Sent: 52\n");
    correct += test(52, FALSE);
    total++;
    printf("Sent: 54\n");
    correct += test(54, FALSE);
    total++;
    printf("Sent: 55\n");
    correct += test(55, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

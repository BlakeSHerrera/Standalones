#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 non-negative ints, a and b, return their sum, so long as
the sum has the same number of digits as a. If the sum has more
digits than a, just return a without b. (Note: one way to compute
the number of digits of a non-negative int n is to convert it to
a string with char *.valueOf(n) and then check the length of the
string.)
*/

int sumLimit(int a, int b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int expected)
{
    int returned = sumLimit(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 2, 3\n");
    correct += test(2, 3, 5);
    total++;
    printf("Sent: 8, 3\n");
    correct += test(8, 3, 8);
    total++;
    printf("Sent: 8, 1\n");
    correct += test(8, 1, 9);
    total++;
    printf("Sent: 11, 39\n");
    correct += test(11, 39, 50);
    total++;
    printf("Sent: 11, 99\n");
    correct += test(11, 99, 11);
    total++;
    printf("Sent: 0, 0\n");
    correct += test(0, 0, 0);
    total++;
    printf("Sent: 99, 0\n");
    correct += test(99, 0, 99);
    total++;
    printf("Sent: 99, 1\n");
    correct += test(99, 1, 99);
    total++;
    printf("Sent: 123, 1\n");
    correct += test(123, 1, 124);
    total++;
    printf("Sent: 1, 123\n");
    correct += test(1, 123, 1);
    total++;
    printf("Sent: 23, 60\n");
    correct += test(23, 60, 83);
    total++;
    printf("Sent: 23, 80\n");
    correct += test(23, 80, 23);
    total++;
    printf("Sent: 9000, 1\n");
    correct += test(9000, 1, 9001);
    total++;
    printf("Sent: 90000000, 1\n");
    correct += test(90000000, 1, 90000001);
    total++;
    printf("Sent: 9000, 1000\n");
    correct += test(9000, 1000, 9000);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

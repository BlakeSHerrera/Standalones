#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given three ints, a b c, return TRUE if they are in strict
increasing order, such as 2 5 11, or 5 6 7, but not 6 5 7 or 5 5
7. However, with the exception that if "equalOk" is TRUE,
equality is allowed, such as 5 5 7 or 5 5 5.
*/

int inOrderEqual(int a, int b, int c, int equalOk)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int c, int equalOk, int expected)
{
    int returned = inOrderEqual(a, b, c, equalOk);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 2, 5, 11, FALSE\n");
    correct += test(2, 5, 11, FALSE, TRUE);
    total++;
    printf("Sent: 5, 7, 6, FALSE\n");
    correct += test(5, 7, 6, FALSE, FALSE);
    total++;
    printf("Sent: 5, 5, 7, TRUE\n");
    correct += test(5, 5, 7, TRUE, TRUE);
    total++;
    printf("Sent: 5, 5, 7, FALSE\n");
    correct += test(5, 5, 7, FALSE, FALSE);
    total++;
    printf("Sent: 2, 5, 4, FALSE\n");
    correct += test(2, 5, 4, FALSE, FALSE);
    total++;
    printf("Sent: 3, 4, 3, FALSE\n");
    correct += test(3, 4, 3, FALSE, FALSE);
    total++;
    printf("Sent: 3, 4, 4, FALSE\n");
    correct += test(3, 4, 4, FALSE, FALSE);
    total++;
    printf("Sent: 3, 4, 3, TRUE\n");
    correct += test(3, 4, 3, TRUE, FALSE);
    total++;
    printf("Sent: 3, 4, 4, TRUE\n");
    correct += test(3, 4, 4, TRUE, TRUE);
    total++;
    printf("Sent: 1, 5, 5, TRUE\n");
    correct += test(1, 5, 5, TRUE, TRUE);
    total++;
    printf("Sent: 5, 5, 5, TRUE\n");
    correct += test(5, 5, 5, TRUE, TRUE);
    total++;
    printf("Sent: 2, 2, 1, TRUE\n");
    correct += test(2, 2, 1, TRUE, FALSE);
    total++;
    printf("Sent: 9, 2, 2, TRUE\n");
    correct += test(9, 2, 2, TRUE, FALSE);
    total++;
    printf("Sent: 0, 1, 0, TRUE\n");
    correct += test(0, 1, 0, TRUE, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

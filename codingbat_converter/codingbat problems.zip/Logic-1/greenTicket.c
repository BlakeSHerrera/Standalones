#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
You have a green lottery ticket, with ints a, b, and c on it. If
the numbers are all different from each other, the result is 0.
If all of the numbers are the same, the result is 20. If two of
the numbers are the same, the result is 10.
*/

int greenTicket(int a, int b, int c)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int c, int expected)
{
    int returned = greenTicket(a, b, c);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 1, 2, 3\n");
    correct += test(1, 2, 3, 0);
    total++;
    printf("Sent: 2, 2, 2\n");
    correct += test(2, 2, 2, 20);
    total++;
    printf("Sent: 1, 1, 2\n");
    correct += test(1, 1, 2, 10);
    total++;
    printf("Sent: 2, 1, 1\n");
    correct += test(2, 1, 1, 10);
    total++;
    printf("Sent: 1, 2, 1\n");
    correct += test(1, 2, 1, 10);
    total++;
    printf("Sent: 3, 2, 1\n");
    correct += test(3, 2, 1, 0);
    total++;
    printf("Sent: 0, 0, 0\n");
    correct += test(0, 0, 0, 20);
    total++;
    printf("Sent: 2, 0, 0\n");
    correct += test(2, 0, 0, 10);
    total++;
    printf("Sent: 0, 9, 10\n");
    correct += test(0, 9, 10, 0);
    total++;
    printf("Sent: 0, 10, 0\n");
    correct += test(0, 10, 0, 10);
    total++;
    printf("Sent: 9, 9, 9\n");
    correct += test(9, 9, 9, 20);
    total++;
    printf("Sent: 9, 0, 9\n");
    correct += test(9, 0, 9, 10);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

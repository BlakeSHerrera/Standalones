#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We are having a party with amounts of tea and candy. Return the
int outcome of the party encoded as 0=bad, 1=good, or 2=great. A
party is good (1) if both tea and candy are at least 5. However,
if either tea or candy is at least double the amount of the other
one, the party is great (2). However, in all cases, if either tea
or candy is less than 5, the party is always bad (0).
*/

int teaParty(int tea, int candy)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int tea, int candy, int expected)
{
    int returned = teaParty(tea, candy);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 6, 8\n");
    correct += test(6, 8, 1);
    total++;
    printf("Sent: 3, 8\n");
    correct += test(3, 8, 0);
    total++;
    printf("Sent: 20, 6\n");
    correct += test(20, 6, 2);
    total++;
    printf("Sent: 12, 6\n");
    correct += test(12, 6, 2);
    total++;
    printf("Sent: 11, 6\n");
    correct += test(11, 6, 1);
    total++;
    printf("Sent: 11, 4\n");
    correct += test(11, 4, 0);
    total++;
    printf("Sent: 4, 5\n");
    correct += test(4, 5, 0);
    total++;
    printf("Sent: 5, 5\n");
    correct += test(5, 5, 1);
    total++;
    printf("Sent: 6, 6\n");
    correct += test(6, 6, 1);
    total++;
    printf("Sent: 5, 10\n");
    correct += test(5, 10, 2);
    total++;
    printf("Sent: 5, 9\n");
    correct += test(5, 9, 1);
    total++;
    printf("Sent: 10, 4\n");
    correct += test(10, 4, 0);
    total++;
    printf("Sent: 10, 20\n");
    correct += test(10, 20, 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

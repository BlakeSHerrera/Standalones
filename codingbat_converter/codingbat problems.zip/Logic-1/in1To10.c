#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a number n, return TRUE if n is in the range 1..10,
inclusive. Unless outsideMode is TRUE, in which case return TRUE
if the number is less or equal to 1, or greater or equal to 10.
*/

int in1To10(int n, int outsideMode)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int outsideMode, int expected)
{
    int returned = in1To10(n, outsideMode);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 5, FALSE\n");
    correct += test(5, FALSE, TRUE);
    total++;
    printf("Sent: 11, FALSE\n");
    correct += test(11, FALSE, FALSE);
    total++;
    printf("Sent: 11, TRUE\n");
    correct += test(11, TRUE, TRUE);
    total++;
    printf("Sent: 10, FALSE\n");
    correct += test(10, FALSE, TRUE);
    total++;
    printf("Sent: 10, TRUE\n");
    correct += test(10, TRUE, TRUE);
    total++;
    printf("Sent: 9, FALSE\n");
    correct += test(9, FALSE, TRUE);
    total++;
    printf("Sent: 9, TRUE\n");
    correct += test(9, TRUE, FALSE);
    total++;
    printf("Sent: 1, FALSE\n");
    correct += test(1, FALSE, TRUE);
    total++;
    printf("Sent: 1, TRUE\n");
    correct += test(1, TRUE, TRUE);
    total++;
    printf("Sent: 0, FALSE\n");
    correct += test(0, FALSE, FALSE);
    total++;
    printf("Sent: 0, TRUE\n");
    correct += test(0, TRUE, TRUE);
    total++;
    printf("Sent: -1, FALSE\n");
    correct += test(-1, FALSE, FALSE);
    total++;
    printf("Sent: -1, TRUE\n");
    correct += test(-1, TRUE, TRUE);
    total++;
    printf("Sent: 99, FALSE\n");
    correct += test(99, FALSE, FALSE);
    total++;
    printf("Sent: -99, TRUE\n");
    correct += test(-99, TRUE, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

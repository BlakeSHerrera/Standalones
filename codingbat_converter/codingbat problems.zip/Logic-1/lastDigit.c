#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given three ints, a b c, return TRUE if two or more of them have
the same rightmost digit. The ints are non-negative. Note: the %
"mod" operator computes the remainder, e.g. 17 % 10 is 7.
*/

int lastDigit(int a, int b, int c)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int c, int expected)
{
    int returned = lastDigit(a, b, c);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 23, 19, 13\n");
    correct += test(23, 19, 13, TRUE);
    total++;
    printf("Sent: 23, 19, 12\n");
    correct += test(23, 19, 12, FALSE);
    total++;
    printf("Sent: 23, 19, 3\n");
    correct += test(23, 19, 3, TRUE);
    total++;
    printf("Sent: 23, 19, 39\n");
    correct += test(23, 19, 39, TRUE);
    total++;
    printf("Sent: 1, 2, 3\n");
    correct += test(1, 2, 3, FALSE);
    total++;
    printf("Sent: 1, 1, 2\n");
    correct += test(1, 1, 2, TRUE);
    total++;
    printf("Sent: 1, 2, 2\n");
    correct += test(1, 2, 2, TRUE);
    total++;
    printf("Sent: 14, 25, 43\n");
    correct += test(14, 25, 43, FALSE);
    total++;
    printf("Sent: 14, 25, 45\n");
    correct += test(14, 25, 45, TRUE);
    total++;
    printf("Sent: 248, 106, 1002\n");
    correct += test(248, 106, 1002, FALSE);
    total++;
    printf("Sent: 248, 106, 1008\n");
    correct += test(248, 106, 1008, TRUE);
    total++;
    printf("Sent: 10, 11, 20\n");
    correct += test(10, 11, 20, TRUE);
    total++;
    printf("Sent: 0, 11, 0\n");
    correct += test(0, 11, 0, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

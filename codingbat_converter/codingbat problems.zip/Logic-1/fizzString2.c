#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an int n, return the string form of the number followed by
"!". So the int 6 yields "6!". Except if the number is divisible
by 3 use "Fizz" instead of the number, and if the number is
divisible by 5 use "Buzz", and if divisible by both 3 and 5, use
"FizzBuzz". Note: the % "mod" operator computes the remainder
after division, so 23 % 10 yields 3. What will the remainder be
when one number divides evenly into another? (See also: FizzBuzz
Code and Introduction to Mod)
*/

char * fizzString2(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, char * expected)
{
    char * returned = fizzString2(n);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 1\n");
    correct += test(1, "1!");
    total++;
    printf("Sent: 2\n");
    correct += test(2, "2!");
    total++;
    printf("Sent: 3\n");
    correct += test(3, "Fizz!");
    total++;
    printf("Sent: 4\n");
    correct += test(4, "4!");
    total++;
    printf("Sent: 5\n");
    correct += test(5, "Buzz!");
    total++;
    printf("Sent: 6\n");
    correct += test(6, "Fizz!");
    total++;
    printf("Sent: 7\n");
    correct += test(7, "7!");
    total++;
    printf("Sent: 8\n");
    correct += test(8, "8!");
    total++;
    printf("Sent: 9\n");
    correct += test(9, "Fizz!");
    total++;
    printf("Sent: 15\n");
    correct += test(15, "FizzBuzz!");
    total++;
    printf("Sent: 16\n");
    correct += test(16, "16!");
    total++;
    printf("Sent: 18\n");
    correct += test(18, "Fizz!");
    total++;
    printf("Sent: 19\n");
    correct += test(19, "19!");
    total++;
    printf("Sent: 21\n");
    correct += test(21, "Fizz!");
    total++;
    printf("Sent: 44\n");
    correct += test(44, "44!");
    total++;
    printf("Sent: 45\n");
    correct += test(45, "FizzBuzz!");
    total++;
    printf("Sent: 100\n");
    correct += test(100, "Buzz!");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

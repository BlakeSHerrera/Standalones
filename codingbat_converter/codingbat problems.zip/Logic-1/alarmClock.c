#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a day of the week encoded as 0=Sun, 1=Mon, 2=Tue, ...6=Sat,
and a int indicating if we are on vacation, return a string of
the form "7:00" indicating when the alarm clock should ring.
Weekdays, the alarm should be "7:00" and on the weekend it should
be "10:00". Unless we are on vacation -- then on weekdays it
should be "10:00" and weekends it should be "off".
*/

char * alarmClock(int day, int vacation)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int day, int vacation, char * expected)
{
    char * returned = alarmClock(day, vacation);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 1, FALSE\n");
    correct += test(1, FALSE, "7:00");
    total++;
    printf("Sent: 5, FALSE\n");
    correct += test(5, FALSE, "7:00");
    total++;
    printf("Sent: 0, FALSE\n");
    correct += test(0, FALSE, "10:00");
    total++;
    printf("Sent: 6, FALSE\n");
    correct += test(6, FALSE, "10:00");
    total++;
    printf("Sent: 0, TRUE\n");
    correct += test(0, TRUE, "off");
    total++;
    printf("Sent: 6, TRUE\n");
    correct += test(6, TRUE, "off");
    total++;
    printf("Sent: 1, TRUE\n");
    correct += test(1, TRUE, "10:00");
    total++;
    printf("Sent: 3, TRUE\n");
    correct += test(3, TRUE, "10:00");
    total++;
    printf("Sent: 5, TRUE\n");
    correct += test(5, TRUE, "10:00");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

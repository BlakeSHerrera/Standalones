#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 ints, a and b, return their sum. However, sums in the
range 10..19 inclusive, are forbidden, so in that case just
return 20.
*/

int sortaSum(int a, int b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int expected)
{
    int returned = sortaSum(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 3, 4\n");
    correct += test(3, 4, 7);
    total++;
    printf("Sent: 9, 4\n");
    correct += test(9, 4, 20);
    total++;
    printf("Sent: 10, 11\n");
    correct += test(10, 11, 21);
    total++;
    printf("Sent: 12, -3\n");
    correct += test(12, -3, 9);
    total++;
    printf("Sent: -3, 12\n");
    correct += test(-3, 12, 9);
    total++;
    printf("Sent: 4, 5\n");
    correct += test(4, 5, 9);
    total++;
    printf("Sent: 4, 6\n");
    correct += test(4, 6, 20);
    total++;
    printf("Sent: 14, 7\n");
    correct += test(14, 7, 21);
    total++;
    printf("Sent: 14, 6\n");
    correct += test(14, 6, 20);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

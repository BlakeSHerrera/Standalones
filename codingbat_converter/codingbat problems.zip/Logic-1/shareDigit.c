#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given two ints, each in the range 10..99, return TRUE if there is
a digit that appears in both numbers, such as the 2 in 12 and 23.
(Note: division, e.g. n/10, gives the left digit while the %
"mod" n%10 gives the right digit.)
*/

int shareDigit(int a, int b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int expected)
{
    int returned = shareDigit(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 12, 23\n");
    correct += test(12, 23, TRUE);
    total++;
    printf("Sent: 12, 43\n");
    correct += test(12, 43, FALSE);
    total++;
    printf("Sent: 12, 44\n");
    correct += test(12, 44, FALSE);
    total++;
    printf("Sent: 23, 12\n");
    correct += test(23, 12, TRUE);
    total++;
    printf("Sent: 23, 39\n");
    correct += test(23, 39, TRUE);
    total++;
    printf("Sent: 23, 19\n");
    correct += test(23, 19, FALSE);
    total++;
    printf("Sent: 30, 90\n");
    correct += test(30, 90, TRUE);
    total++;
    printf("Sent: 30, 91\n");
    correct += test(30, 91, FALSE);
    total++;
    printf("Sent: 55, 55\n");
    correct += test(55, 55, TRUE);
    total++;
    printf("Sent: 55, 44\n");
    correct += test(55, 44, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

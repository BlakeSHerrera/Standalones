#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Your cell phone rings. Return TRUE if you should answer it.
Normally you answer, except in the morning you only answer if it
is your mom calling. In all cases, if you are asleep, you do not
answer.
*/

int answerCell(int isMorning, int isMom, int isAsleep)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int isMorning, int isMom, int isAsleep, int expected)
{
    int returned = answerCell(isMorning, isMom, isAsleep);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: FALSE, FALSE, FALSE\n");
    correct += test(FALSE, FALSE, FALSE, TRUE);
    total++;
    printf("Sent: FALSE, FALSE, TRUE\n");
    correct += test(FALSE, FALSE, TRUE, FALSE);
    total++;
    printf("Sent: TRUE, FALSE, FALSE\n");
    correct += test(TRUE, FALSE, FALSE, FALSE);
    total++;
    printf("Sent: TRUE, TRUE, FALSE\n");
    correct += test(TRUE, TRUE, FALSE, TRUE);
    total++;
    printf("Sent: FALSE, TRUE, FALSE\n");
    correct += test(FALSE, TRUE, FALSE, TRUE);
    total++;
    printf("Sent: TRUE, TRUE, TRUE\n");
    correct += test(TRUE, TRUE, TRUE, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

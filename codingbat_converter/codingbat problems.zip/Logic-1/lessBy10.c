#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given three ints, a b c, return TRUE if one of them is 10 or more
less than one of the others.
*/

int lessBy10(int a, int b, int c)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int c, int expected)
{
    int returned = lessBy10(a, b, c);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 1, 7, 11\n");
    correct += test(1, 7, 11, TRUE);
    total++;
    printf("Sent: 1, 7, 10\n");
    correct += test(1, 7, 10, FALSE);
    total++;
    printf("Sent: 11, 1, 7\n");
    correct += test(11, 1, 7, TRUE);
    total++;
    printf("Sent: 10, 7, 1\n");
    correct += test(10, 7, 1, FALSE);
    total++;
    printf("Sent: -10, 2, 2\n");
    correct += test(-10, 2, 2, TRUE);
    total++;
    printf("Sent: 2, 11, 11\n");
    correct += test(2, 11, 11, FALSE);
    total++;
    printf("Sent: 3, 3, 30\n");
    correct += test(3, 3, 30, TRUE);
    total++;
    printf("Sent: 3, 3, 3\n");
    correct += test(3, 3, 3, FALSE);
    total++;
    printf("Sent: 10, 1, 11\n");
    correct += test(10, 1, 11, TRUE);
    total++;
    printf("Sent: 10, 11, 1\n");
    correct += test(10, 11, 1, TRUE);
    total++;
    printf("Sent: 10, 11, 2\n");
    correct += test(10, 11, 2, FALSE);
    total++;
    printf("Sent: 3, 30, 3\n");
    correct += test(3, 30, 3, TRUE);
    total++;
    printf("Sent: 2, 2, -8\n");
    correct += test(2, 2, -8, TRUE);
    total++;
    printf("Sent: 2, 8, 12\n");
    correct += test(2, 8, 12, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

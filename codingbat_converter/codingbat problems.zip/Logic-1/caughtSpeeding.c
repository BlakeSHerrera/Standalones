#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
You are driving a little too fast, and a police officer stops
you. Write code to compute the result, encoded as an int value:
0=no ticket, 1=small ticket, 2=big ticket. If speed is 60 or
less, the result is 0. If speed is between 61 and 80 inclusive,
the result is 1. If speed is 81 or more, the result is 2. Unless
it is your birthday -- on that day, your speed can be 5 higher in
all cases.
*/

int caughtSpeeding(int speed, int isBirthday)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int speed, int isBirthday, int expected)
{
    int returned = caughtSpeeding(speed, isBirthday);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 60, FALSE\n");
    correct += test(60, FALSE, 0);
    total++;
    printf("Sent: 65, FALSE\n");
    correct += test(65, FALSE, 1);
    total++;
    printf("Sent: 65, TRUE\n");
    correct += test(65, TRUE, 0);
    total++;
    printf("Sent: 80, FALSE\n");
    correct += test(80, FALSE, 1);
    total++;
    printf("Sent: 85, FALSE\n");
    correct += test(85, FALSE, 2);
    total++;
    printf("Sent: 85, TRUE\n");
    correct += test(85, TRUE, 1);
    total++;
    printf("Sent: 70, FALSE\n");
    correct += test(70, FALSE, 1);
    total++;
    printf("Sent: 75, FALSE\n");
    correct += test(75, FALSE, 1);
    total++;
    printf("Sent: 75, TRUE\n");
    correct += test(75, TRUE, 1);
    total++;
    printf("Sent: 40, FALSE\n");
    correct += test(40, FALSE, 0);
    total++;
    printf("Sent: 40, TRUE\n");
    correct += test(40, TRUE, 0);
    total++;
    printf("Sent: 90, FALSE\n");
    correct += test(90, FALSE, 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

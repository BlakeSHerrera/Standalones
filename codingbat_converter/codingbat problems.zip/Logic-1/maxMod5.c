#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given two int values, return whichever value is larger. However
if the two values have the same remainder when divided by 5, then
the return the smaller value. However, in all cases, if the two
values are the same, return 0. Note: the % "mod" operator
computes the remainder, e.g. 7 % 5 is 2.
*/

int maxMod5(int a, int b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int expected)
{
    int returned = maxMod5(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 2, 3\n");
    correct += test(2, 3, 3);
    total++;
    printf("Sent: 6, 2\n");
    correct += test(6, 2, 6);
    total++;
    printf("Sent: 3, 2\n");
    correct += test(3, 2, 3);
    total++;
    printf("Sent: 8, 12\n");
    correct += test(8, 12, 12);
    total++;
    printf("Sent: 7, 12\n");
    correct += test(7, 12, 7);
    total++;
    printf("Sent: 11, 6\n");
    correct += test(11, 6, 6);
    total++;
    printf("Sent: 2, 7\n");
    correct += test(2, 7, 2);
    total++;
    printf("Sent: 7, 7\n");
    correct += test(7, 7, 0);
    total++;
    printf("Sent: 9, 1\n");
    correct += test(9, 1, 9);
    total++;
    printf("Sent: 9, 14\n");
    correct += test(9, 14, 9);
    total++;
    printf("Sent: 1, 2\n");
    correct += test(1, 2, 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string str, if the string starts with "f" return "Fizz".
If the string ends with "b" return "Buzz". If both the "f" and
"b" conditions are TRUE, return "FizzBuzz". In all other cases,
return the string unchanged. (See also: FizzBuzz Code)
*/

char * fizzString(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = fizzString(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"fig\"\n");
    correct += test("fig", "Fizz");
    total++;
    printf("Sent: \"dib\"\n");
    correct += test("dib", "Buzz");
    total++;
    printf("Sent: \"fib\"\n");
    correct += test("fib", "FizzBuzz");
    total++;
    printf("Sent: \"abc\"\n");
    correct += test("abc", "abc");
    total++;
    printf("Sent: \"fooo\"\n");
    correct += test("fooo", "Fizz");
    total++;
    printf("Sent: \"booo\"\n");
    correct += test("booo", "booo");
    total++;
    printf("Sent: \"ooob\"\n");
    correct += test("ooob", "Buzz");
    total++;
    printf("Sent: \"fooob\"\n");
    correct += test("fooob", "FizzBuzz");
    total++;
    printf("Sent: \"f\"\n");
    correct += test("f", "Fizz");
    total++;
    printf("Sent: \"b\"\n");
    correct += test("b", "Buzz");
    total++;
    printf("Sent: \"abcb\"\n");
    correct += test("abcb", "Buzz");
    total++;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", "Hello");
    total++;
    printf("Sent: \"Hellob\"\n");
    correct += test("Hellob", "Buzz");
    total++;
    printf("Sent: \"af\"\n");
    correct += test("af", "af");
    total++;
    printf("Sent: \"bf\"\n");
    correct += test("bf", "bf");
    total++;
    printf("Sent: \"fb\"\n");
    correct += test("fb", "FizzBuzz");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

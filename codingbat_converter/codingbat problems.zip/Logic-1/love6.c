#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
The number 6 is a truly great number. Given two int values, a and
b, return TRUE if either one is 6. Or if their sum or difference
is 6. Note: the function Math.abs(num) computes the absolute
value of a number.
*/

int love6(int a, int b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int expected)
{
    int returned = love6(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 6, 4\n");
    correct += test(6, 4, TRUE);
    total++;
    printf("Sent: 4, 5\n");
    correct += test(4, 5, FALSE);
    total++;
    printf("Sent: 1, 5\n");
    correct += test(1, 5, TRUE);
    total++;
    printf("Sent: 1, 6\n");
    correct += test(1, 6, TRUE);
    total++;
    printf("Sent: 1, 8\n");
    correct += test(1, 8, FALSE);
    total++;
    printf("Sent: 1, 7\n");
    correct += test(1, 7, TRUE);
    total++;
    printf("Sent: 7, 5\n");
    correct += test(7, 5, FALSE);
    total++;
    printf("Sent: 8, 2\n");
    correct += test(8, 2, TRUE);
    total++;
    printf("Sent: 6, 6\n");
    correct += test(6, 6, TRUE);
    total++;
    printf("Sent: -6, 2\n");
    correct += test(-6, 2, FALSE);
    total++;
    printf("Sent: -4, -10\n");
    correct += test(-4, -10, TRUE);
    total++;
    printf("Sent: -7, 1\n");
    correct += test(-7, 1, FALSE);
    total++;
    printf("Sent: 7, -1\n");
    correct += test(7, -1, TRUE);
    total++;
    printf("Sent: -6, 12\n");
    correct += test(-6, 12, TRUE);
    total++;
    printf("Sent: -2, -4\n");
    correct += test(-2, -4, FALSE);
    total++;
    printf("Sent: 7, 1\n");
    correct += test(7, 1, TRUE);
    total++;
    printf("Sent: 0, 9\n");
    correct += test(0, 9, FALSE);
    total++;
    printf("Sent: 8, 3\n");
    correct += test(8, 3, FALSE);
    total++;
    printf("Sent: 3, 3\n");
    correct += test(3, 3, TRUE);
    total++;
    printf("Sent: 3, 4\n");
    correct += test(3, 4, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

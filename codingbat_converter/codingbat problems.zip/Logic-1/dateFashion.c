#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
You and your date are trying to get a table at a restaurant. The
parameter "you" is the stylishness of your clothes, in the range
0..10, and "date" is the stylishness of your date's clothes. The
result getting the table is encoded as an int value with 0=no,
1=maybe, 2=yes. If either of you is very stylish, 8 or more, then
the result is 2 (yes). With the exception that if either of you
has style of 2 or less, then the result is 0 (no). Otherwise the
result is 1 (maybe).
*/

int dateFashion(int you, int date)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int you, int date, int expected)
{
    int returned = dateFashion(you, date);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 5, 10\n");
    correct += test(5, 10, 2);
    total++;
    printf("Sent: 5, 2\n");
    correct += test(5, 2, 0);
    total++;
    printf("Sent: 5, 5\n");
    correct += test(5, 5, 1);
    total++;
    printf("Sent: 3, 3\n");
    correct += test(3, 3, 1);
    total++;
    printf("Sent: 10, 2\n");
    correct += test(10, 2, 0);
    total++;
    printf("Sent: 2, 9\n");
    correct += test(2, 9, 0);
    total++;
    printf("Sent: 9, 9\n");
    correct += test(9, 9, 2);
    total++;
    printf("Sent: 10, 5\n");
    correct += test(10, 5, 2);
    total++;
    printf("Sent: 2, 2\n");
    correct += test(2, 2, 0);
    total++;
    printf("Sent: 3, 7\n");
    correct += test(3, 7, 1);
    total++;
    printf("Sent: 2, 7\n");
    correct += test(2, 7, 0);
    total++;
    printf("Sent: 6, 2\n");
    correct += test(6, 2, 0);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
You have a red lottery ticket showing ints a, b, and c, each of
which is 0, 1, or 2. If they are all the value 2, the result is
10. Otherwise if they are all the same, the result is 5.
Otherwise so long as both b and c are different from a, the
result is 1. Otherwise the result is 0.
*/

int redTicket(int a, int b, int c)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int c, int expected)
{
    int returned = redTicket(a, b, c);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 2, 2, 2\n");
    correct += test(2, 2, 2, 10);
    total++;
    printf("Sent: 2, 2, 1\n");
    correct += test(2, 2, 1, 0);
    total++;
    printf("Sent: 0, 0, 0\n");
    correct += test(0, 0, 0, 5);
    total++;
    printf("Sent: 2, 0, 0\n");
    correct += test(2, 0, 0, 1);
    total++;
    printf("Sent: 1, 1, 1\n");
    correct += test(1, 1, 1, 5);
    total++;
    printf("Sent: 1, 2, 1\n");
    correct += test(1, 2, 1, 0);
    total++;
    printf("Sent: 1, 2, 0\n");
    correct += test(1, 2, 0, 1);
    total++;
    printf("Sent: 0, 2, 2\n");
    correct += test(0, 2, 2, 1);
    total++;
    printf("Sent: 1, 2, 2\n");
    correct += test(1, 2, 2, 1);
    total++;
    printf("Sent: 0, 2, 0\n");
    correct += test(0, 2, 0, 0);
    total++;
    printf("Sent: 1, 1, 2\n");
    correct += test(1, 1, 2, 0);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of strings, return a new array without the strings
that are equal to the target string. One approach is to count the
occurrences of the target string, make a new array of the correct
length, and then copy over the correct strings.
*/

String[] wordsWithout(String[] words, char * target)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(String[] words, char * target, String[] expected)
{

}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [\"a\", \"b\", \"c\", \"a\"], \"a\"\n");
    correct += test((int[]){"a", "b", "c", "a"}, 4, "a", ialloc((int[]){"b", "c"}), 2);
    total++;
    printf("Sent: [\"a\", \"b\", \"c\", \"a\"], \"b\"\n");
    correct += test((int[]){"a", "b", "c", "a"}, 4, "b", ialloc((int[]){"a", "c", "a"}), 3);
    total++;
    printf("Sent: [\"a\", \"b\", \"c\", \"a\"], \"c\"\n");
    correct += test((int[]){"a", "b", "c", "a"}, 4, "c", ialloc((int[]){"a", "b", "a"}), 3);
    total++;
    printf("Sent: [\"b\", \"c\", \"a\", \"a\"], \"b\"\n");
    correct += test((int[]){"b", "c", "a", "a"}, 4, "b", ialloc((int[]){"c", "a", "a"}), 3);
    total++;
    printf("Sent: [\"xx\", \"yyy\", \"x\", \"yy\", \"x\"], \"x\"\n");
    correct += test((int[]){"xx", "yyy", "x", "yy", "x"}, 5, "x", ialloc((int[]){"xx", "yyy", "yy"}), 3);
    total++;
    printf("Sent: [\"xx\", \"yyy\", \"x\", \"yy\", \"x\"], \"yy\"\n");
    correct += test((int[]){"xx", "yyy", "x", "yy", "x"}, 5, "yy", ialloc((int[]){"xx", "yyy", "x", "x"}), 4);
    total++;
    printf("Sent: [\"aa\", \"ab\", \"ac\", \"aa\"], \"aa\"\n");
    correct += test((int[]){"aa", "ab", "ac", "aa"}, 4, "aa", ialloc((int[]){"ab", "ac"}), 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

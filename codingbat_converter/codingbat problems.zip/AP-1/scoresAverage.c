#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of scores, compute the int average of the first
half and the second half, and return whichever is larger. We'll
say that the second half begins at index length/2. The array
length will be at least 2. To practice decomposition, write a
separate helper method int average(int[] scores, int start, int
end) {  which computes the average of the elements between
indexes start..end. Call your helper method twice to implement
scoresAverage(). Write your helper method after your
scoresAverage() method in the JavaBat text area. Normally you
would compute averages with doubles, but here we use ints so the
expected results are exact.
*/

int scoresAverage(int scores[], int scoresSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int scores[], int scoresSize, int expected)
{
    int returned = scoresAverage(scores, scoresSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [2, 2, 4, 4]\n");
    correct += test((int[]){2, 2, 4, 4}, 4, 4);
    total++;
    printf("Sent: [4, 4, 4, 2, 2, 2]\n");
    correct += test((int[]){4, 4, 4, 2, 2, 2}, 6, 4);
    total++;
    printf("Sent: [3, 4, 5, 1, 2, 3]\n");
    correct += test((int[]){3, 4, 5, 1, 2, 3}, 6, 4);
    total++;
    printf("Sent: [5, 6]\n");
    correct += test((int[]){5, 6}, 2, 6);
    total++;
    printf("Sent: [5, 4]\n");
    correct += test((int[]){5, 4}, 2, 5);
    total++;
    printf("Sent: [5, 4, 5, 6, 2, 1, 2, 3]\n");
    correct += test((int[]){5, 4, 5, 6, 2, 1, 2, 3}, 8, 5);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We have data for two users, A and B, each with a char * name and
an int id. The goal is to order the users such as for sorting.
Return -1 if A comes before B, 1 if A comes after B, and 0 if
they are the same. Order first by the string names, and then by
the id numbers if the names are the same. Note: with char *s
str1.compareTo(str2) returns an int value which is
negative/0/positive to indicate how str1 is ordered to str2 (the
value is not limited to -1/0/1). (On the AP, there would be two
User objects, but here the code simply takes the two strings and
two ints directly. The code logic is the same.)
*/

int userCompare(char * aName, int aId, char * bName, int bId)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * aName, int aId, char * bName, int bId, int expected)
{
    int returned = userCompare(aName, aId, bName, bId);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"bb\", 1, \"zz\", 2\n");
    correct += test("bb", 1, "zz", 2, -1);
    total++;
    printf("Sent: \"bb\", 1, \"aa\", 2\n");
    correct += test("bb", 1, "aa", 2, 1);
    total++;
    printf("Sent: \"bb\", 1, \"bb\", 1\n");
    correct += test("bb", 1, "bb", 1, 0);
    total++;
    printf("Sent: \"bb\", 5, \"bb\", 1\n");
    correct += test("bb", 5, "bb", 1, 1);
    total++;
    printf("Sent: \"bb\", 5, \"bb\", 10\n");
    correct += test("bb", 5, "bb", 10, -1);
    total++;
    printf("Sent: \"adam\", 1, \"bob\", 2\n");
    correct += test("adam", 1, "bob", 2, -1);
    total++;
    printf("Sent: \"bob\", 1, \"bob\", 2\n");
    correct += test("bob", 1, "bob", 2, -1);
    total++;
    printf("Sent: \"bzb\", 1, \"bob\", 2\n");
    correct += test("bzb", 1, "bob", 2, 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

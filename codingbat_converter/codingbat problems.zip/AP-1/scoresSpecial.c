#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given two arrays, A and B, of non-negative int scores. A
"special" score is one which is a multiple of 10, such as 40 or
90. Return the sum of largest special score in A and the largest
special score in B. To practice decomposition, write a separate
helper method which finds the largest special score in an array.
Write your helper method after your scoresSpecial() method in the
JavaBat text area.
*/

int scoresSpecial(int a[], int aSize, int b[], int bSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a[], int aSize, int b[], int bSize, int expected)
{
    int returned = scoresSpecial(a, aSize, b, bSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [12, 10, 4], [2, 20, 30]\n");
    correct += test((int[]){12, 10, 4}, 3, (int[]){2, 20, 30}, 3, 40);
    total++;
    printf("Sent: [20, 10, 4], [2, 20, 10]\n");
    correct += test((int[]){20, 10, 4}, 3, (int[]){2, 20, 10}, 3, 40);
    total++;
    printf("Sent: [12, 11, 4], [2, 20, 31]\n");
    correct += test((int[]){12, 11, 4}, 3, (int[]){2, 20, 31}, 3, 20);
    total++;
    printf("Sent: [1, 20, 2, 50], [3, 4, 5]\n");
    correct += test((int[]){1, 20, 2, 50}, 4, (int[]){3, 4, 5}, 3, 50);
    total++;
    printf("Sent: [3, 4, 5], [1, 50, 2, 20]\n");
    correct += test((int[]){3, 4, 5}, 3, (int[]){1, 50, 2, 20}, 4, 50);
    total++;
    printf("Sent: [10, 4, 20, 30], [20]\n");
    correct += test((int[]){10, 4, 20, 30}, 4, (int[]){20}, 1, 50);
    total++;
    printf("Sent: [10, 4, 20, 30], [20]\n");
    correct += test((int[]){10, 4, 20, 30}, 4, (int[]){20}, 1, 50);
    total++;
    printf("Sent: [10, 4, 20, 30], [3, 20, 99]\n");
    correct += test((int[]){10, 4, 20, 30}, 4, (int[]){3, 20, 99}, 3, 50);
    total++;
    printf("Sent: [10, 4, 20, 30], [30, 20, 99]\n");
    correct += test((int[]){10, 4, 20, 30}, 4, (int[]){30, 20, 99}, 3, 60);
    total++;
    printf("Sent: [], [2]\n");
    correct += test((int[]){}, 1, (int[]){2}, 1, 0);
    total++;
    printf("Sent: [], [20]\n");
    correct += test((int[]){}, 1, (int[]){20}, 1, 20);
    total++;
    printf("Sent: [14, 10, 4], [4, 20, 30]\n");
    correct += test((int[]){14, 10, 4}, 3, (int[]){4, 20, 30}, 3, 40);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of strings, return a new List (e.g. an ArrayList)
where all the strings of the given length are omitted. See
wordsWithout() below which is more difficult because it uses
arrays.
*/

List wordsWithoutList(String[] words, int len)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(String[] words, int len, List expected)
{

}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [\"a\", \"bb\", \"b\", \"ccc\"], 1\n");
    correct += test((int[]){"a", "bb", "b", "ccc"}, 4, 1, ialloc((int[]){"bb", "ccc"}), 2);
    total++;
    printf("Sent: [\"a\", \"bb\", \"b\", \"ccc\"], 3\n");
    correct += test((int[]){"a", "bb", "b", "ccc"}, 4, 3, ialloc((int[]){"a", "bb", "b"}), 3);
    total++;
    printf("Sent: [\"a\", \"bb\", \"b\", \"ccc\"], 4\n");
    correct += test((int[]){"a", "bb", "b", "ccc"}, 4, 4, ialloc((int[]){"a", "bb", "b", "ccc"}), 4);
    total++;
    printf("Sent: [\"xx\", \"yyy\", \"x\", \"yy\", \"z\"], 1\n");
    correct += test((int[]){"xx", "yyy", "x", "yy", "z"}, 5, 1, ialloc((int[]){"xx", "yyy", "yy"}), 3);
    total++;
    printf("Sent: [\"xx\", \"yyy\", \"x\", \"yy\", \"z\"], 2\n");
    correct += test((int[]){"xx", "yyy", "x", "yy", "z"}, 5, 2, ialloc((int[]){"yyy", "x", "z"}), 3);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

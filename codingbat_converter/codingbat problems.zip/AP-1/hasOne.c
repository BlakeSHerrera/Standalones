#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a positive int n, return TRUE if it contains a 1 digit.
Note: use % to get the rightmost digit, and / to discard the
rightmost digit.
*/

int hasOne(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int expected)
{
    int returned = hasOne(n);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 10\n");
    correct += test(10, TRUE);
    total++;
    printf("Sent: 22\n");
    correct += test(22, FALSE);
    total++;
    printf("Sent: 220\n");
    correct += test(220, FALSE);
    total++;
    printf("Sent: 212\n");
    correct += test(212, TRUE);
    total++;
    printf("Sent: 1\n");
    correct += test(1, TRUE);
    total++;
    printf("Sent: 9\n");
    correct += test(9, FALSE);
    total++;
    printf("Sent: 211112\n");
    correct += test(211112, TRUE);
    total++;
    printf("Sent: 121121\n");
    correct += test(121121, TRUE);
    total++;
    printf("Sent: 222222\n");
    correct += test(222222, FALSE);
    total++;
    printf("Sent: 56156\n");
    correct += test(56156, TRUE);
    total++;
    printf("Sent: 56556\n");
    correct += test(56556, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

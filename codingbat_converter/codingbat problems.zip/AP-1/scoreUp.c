#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
The "key" array is an array containing the correct answers to an
exam, like {"a", "a", "b", "b"}. the "answers" array contains a
student's answers, with "?" representing a question left blank.
The two arrays are not empty and are the same length. Return the
score for this array of answers, giving +4 for each correct
answer, -1 for each incorrect answer, and +0 for each blank
answer.
*/

int scoreUp(String[] key, String[] answers)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(String[] key, String[] answers, int expected)
{
    int returned = scoreUp(key, answers);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\"], [\"a\", \"c\", \"b\", \"c\"]\n");
    correct += test((int[]){"a", "a", "b", "b"}, 4, (int[]){"a", "c", "b", "c"}, 4, 6);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\"], [\"a\", \"a\", \"b\", \"c\"]\n");
    correct += test((int[]){"a", "a", "b", "b"}, 4, (int[]){"a", "a", "b", "c"}, 4, 11);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\"], [\"a\", \"a\", \"b\", \"b\"]\n");
    correct += test((int[]){"a", "a", "b", "b"}, 4, (int[]){"a", "a", "b", "b"}, 4, 16);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\"], [\"?\", \"c\", \"b\", \"?\"]\n");
    correct += test((int[]){"a", "a", "b", "b"}, 4, (int[]){"?", "c", "b", "?"}, 4, 3);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\"], [\"?\", \"c\", \"?\", \"?\"]\n");
    correct += test((int[]){"a", "a", "b", "b"}, 4, (int[]){"?", "c", "?", "?"}, 4, -1);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\"], [\"c\", \"?\", \"b\", \"b\"]\n");
    correct += test((int[]){"a", "a", "b", "b"}, 4, (int[]){"c", "?", "b", "b"}, 4, 7);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\"], [\"c\", \"?\", \"b\", \"?\"]\n");
    correct += test((int[]){"a", "a", "b", "b"}, 4, (int[]){"c", "?", "b", "?"}, 4, 3);
    total++;
    printf("Sent: [\"a\", \"b\", \"c\"], [\"a\", \"c\", \"b\"]\n");
    correct += test((int[]){"a", "b", "c"}, 3, (int[]){"a", "c", "b"}, 3, 2);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\", \"c\", \"c\"], [\"a\", \"c\", \"a\", \"c\", \"a\", \"c\"]\n");
    correct += test((int[]){"a", "a", "b", "b", "c", "c"}, 6, (int[]){"a", "c", "a", "c", "a", "c"}, 6, 4);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\", \"c\", \"c\"], [\"a\", \"c\", \"?\", \"?\", \"a\", \"c\"]\n");
    correct += test((int[]){"a", "a", "b", "b", "c", "c"}, 6, (int[]){"a", "c", "?", "?", "a", "c"}, 6, 6);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\", \"c\", \"c\"], [\"a\", \"c\", \"?\", \"?\", \"c\", \"c\"]\n");
    correct += test((int[]){"a", "a", "b", "b", "c", "c"}, 6, (int[]){"a", "c", "?", "?", "c", "c"}, 6, 11);
    total++;
    printf("Sent: [\"a\", \"b\", \"c\"], [\"a\", \"b\", \"c\"]\n");
    correct += test((int[]){"a", "b", "c"}, 3, (int[]){"a", "b", "c"}, 3, 12);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

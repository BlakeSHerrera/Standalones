#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of positive ints, return a new array of length
"count" containing the first even numbers from the original
array. The original array will contain at least "count" even
numbers.
*/

int * copyEvens(int nums[], int numsSize, int count)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int count, int * expected, int expectedSize)
{
    int * returned = copyEvens(nums, numsSize, count);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [3, 2, 4, 5, 8], 2\n");
    correct += test((int[]){3, 2, 4, 5, 8}, 5, 2, ialloc((int[]){2, 4}), 2);
    total++;
    printf("Sent: [3, 2, 4, 5, 8], 3\n");
    correct += test((int[]){3, 2, 4, 5, 8}, 5, 3, ialloc((int[]){2, 4, 8}), 3);
    total++;
    printf("Sent: [6, 1, 2, 4, 5, 8], 3\n");
    correct += test((int[]){6, 1, 2, 4, 5, 8}, 6, 3, ialloc((int[]){6, 2, 4}), 3);
    total++;
    printf("Sent: [6, 1, 2, 4, 5, 8], 4\n");
    correct += test((int[]){6, 1, 2, 4, 5, 8}, 6, 4, ialloc((int[]){6, 2, 4, 8}), 4);
    total++;
    printf("Sent: [3, 1, 4, 1, 5], 1\n");
    correct += test((int[]){3, 1, 4, 1, 5}, 5, 1, ialloc((int[]){4}), 1);
    total++;
    printf("Sent: [2], 1\n");
    correct += test((int[]){2}, 1, 1, ialloc((int[]){2}), 1);
    total++;
    printf("Sent: [6, 2, 4, 8], 2\n");
    correct += test((int[]){6, 2, 4, 8}, 4, 2, ialloc((int[]){6, 2}), 2);
    total++;
    printf("Sent: [6, 2, 4, 8], 3\n");
    correct += test((int[]){6, 2, 4, 8}, 4, 3, ialloc((int[]){6, 2, 4}), 3);
    total++;
    printf("Sent: [6, 2, 4, 8], 4\n");
    correct += test((int[]){6, 2, 4, 8}, 4, 4, ialloc((int[]){6, 2, 4, 8}), 4);
    total++;
    printf("Sent: [1, 8, 4], 1\n");
    correct += test((int[]){1, 8, 4}, 3, 1, ialloc((int[]){8}), 1);
    total++;
    printf("Sent: [1, 8, 4], 2\n");
    correct += test((int[]){1, 8, 4}, 3, 2, ialloc((int[]){8, 4}), 2);
    total++;
    printf("Sent: [2, 8, 4], 2\n");
    correct += test((int[]){2, 8, 4}, 3, 2, ialloc((int[]){2, 8}), 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

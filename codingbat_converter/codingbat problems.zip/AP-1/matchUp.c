#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 arrays that are the same length containing strings,
compare the 1st string in one array to the 1st string in the
other array, the 2nd to the 2nd and so on. Count the number of
times that the 2 strings are non-empty and start with the same
char. The strings may be any length, including 0.
*/

int matchUp(String[] a, String[] b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(String[] a, String[] b, int expected)
{
    int returned = matchUp(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [\"aa\", \"bb\", \"cc\"], [\"aaa\", \"xx\", \"bb\"]\n");
    correct += test((int[]){"aa", "bb", "cc"}, 3, (int[]){"aaa", "xx", "bb"}, 3, 1);
    total++;
    printf("Sent: [\"aa\", \"bb\", \"cc\"], [\"aaa\", \"b\", \"bb\"]\n");
    correct += test((int[]){"aa", "bb", "cc"}, 3, (int[]){"aaa", "b", "bb"}, 3, 2);
    total++;
    printf("Sent: [\"aa\", \"bb\", \"cc\"], [\"\", \"\", \"ccc\"]\n");
    correct += test((int[]){"aa", "bb", "cc"}, 3, (int[]){"", "", "ccc"}, 3, 1);
    total++;
    printf("Sent: [\"\", \"\", \"ccc\"], [\"aa\", \"bb\", \"cc\"]\n");
    correct += test((int[]){"", "", "ccc"}, 3, (int[]){"aa", "bb", "cc"}, 3, 1);
    total++;
    printf("Sent: [\"\", \"\", \"\"], [\"\", \"bb\", \"cc\"]\n");
    correct += test((int[]){"", "", ""}, 3, (int[]){"", "bb", "cc"}, 3, 0);
    total++;
    printf("Sent: [\"aa\", \"bb\", \"cc\"], [\"\", \"\", \"\"]\n");
    correct += test((int[]){"aa", "bb", "cc"}, 3, (int[]){"", "", ""}, 3, 0);
    total++;
    printf("Sent: [\"aa\", \"\", \"ccc\"], [\"\", \"bb\", \"cc\"]\n");
    correct += test((int[]){"aa", "", "ccc"}, 3, (int[]){"", "bb", "cc"}, 3, 1);
    total++;
    printf("Sent: [\"x\", \"y\", \"z\"], [\"y\", \"z\", \"x\"]\n");
    correct += test((int[]){"x", "y", "z"}, 3, (int[]){"y", "z", "x"}, 3, 0);
    total++;
    printf("Sent: [\"\", \"y\", \"z\"], [\"\", \"y\", \"x\"]\n");
    correct += test((int[]){"", "y", "z"}, 3, (int[]){"", "y", "x"}, 3, 1);
    total++;
    printf("Sent: [\"x\", \"y\", \"z\"], [\"xx\", \"yyy\", \"zzz\"]\n");
    correct += test((int[]){"x", "y", "z"}, 3, (int[]){"xx", "yyy", "zzz"}, 3, 3);
    total++;
    printf("Sent: [\"x\", \"y\", \"z\"], [\"xx\", \"yyy\", \"\"]\n");
    correct += test((int[]){"x", "y", "z"}, 3, (int[]){"xx", "yyy", ""}, 3, 2);
    total++;
    printf("Sent: [\"b\", \"x\", \"y\", \"z\"], [\"a\", \"xx\", \"yyy\", \"zzz\"]\n");
    correct += test((int[]){"b", "x", "y", "z"}, 4, (int[]){"a", "xx", "yyy", "zzz"}, 4, 3);
    total++;
    printf("Sent: [\"aaa\", \"bb\", \"c\"], [\"aaa\", \"xx\", \"bb\"]\n");
    correct += test((int[]){"aaa", "bb", "c"}, 3, (int[]){"aaa", "xx", "bb"}, 3, 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

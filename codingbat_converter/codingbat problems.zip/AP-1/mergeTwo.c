#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Start with two arrays of strings, A and B, each with its elements
in alphabetical order and without duplicates. Return a new array
containing the first N elements from the two arrays. The result
array should be in alphabetical order and without duplicates. A
and B will both have a length which is N or more. The best
"linear" solution makes a single pass over A and B, taking
advantage of the fact that they are in alphabetical order,
copying elements directly to the new array.
*/

String[] mergeTwo(String[] a, String[] b, int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(String[] a, String[] b, int n, String[] expected)
{

}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [\"a\", \"c\", \"z\"], [\"b\", \"f\", \"z\"], 3\n");
    correct += test((int[]){"a", "c", "z"}, 3, (int[]){"b", "f", "z"}, 3, 3, ialloc((int[]){"a", "b", "c"}), 3);
    total++;
    printf("Sent: [\"a\", \"c\", \"z\"], [\"c\", \"f\", \"z\"], 3\n");
    correct += test((int[]){"a", "c", "z"}, 3, (int[]){"c", "f", "z"}, 3, 3, ialloc((int[]){"a", "c", "f"}), 3);
    total++;
    printf("Sent: [\"f\", \"g\", \"z\"], [\"c\", \"f\", \"g\"], 3\n");
    correct += test((int[]){"f", "g", "z"}, 3, (int[]){"c", "f", "g"}, 3, 3, ialloc((int[]){"c", "f", "g"}), 3);
    total++;
    printf("Sent: [\"a\", \"c\", \"z\"], [\"a\", \"c\", \"z\"], 3\n");
    correct += test((int[]){"a", "c", "z"}, 3, (int[]){"a", "c", "z"}, 3, 3, ialloc((int[]){"a", "c", "z"}), 3);
    total++;
    printf("Sent: [\"a\", \"b\", \"c\", \"z\"], [\"a\", \"c\", \"z\"], 3\n");
    correct += test((int[]){"a", "b", "c", "z"}, 4, (int[]){"a", "c", "z"}, 3, 3, ialloc((int[]){"a", "b", "c"}), 3);
    total++;
    printf("Sent: [\"a\", \"c\", \"z\"], [\"a\", \"b\", \"c\", \"z\"], 3\n");
    correct += test((int[]){"a", "c", "z"}, 3, (int[]){"a", "b", "c", "z"}, 4, 3, ialloc((int[]){"a", "b", "c"}), 3);
    total++;
    printf("Sent: [\"a\", \"c\", \"z\"], [\"a\", \"c\", \"z\"], 2\n");
    correct += test((int[]){"a", "c", "z"}, 3, (int[]){"a", "c", "z"}, 3, 2, ialloc((int[]){"a", "c"}), 2);
    total++;
    printf("Sent: [\"a\", \"c\", \"z\"], [\"a\", \"c\", \"y\", \"z\"], 3\n");
    correct += test((int[]){"a", "c", "z"}, 3, (int[]){"a", "c", "y", "z"}, 4, 3, ialloc((int[]){"a", "c", "y"}), 3);
    total++;
    printf("Sent: [\"x\", \"y\", \"z\"], [\"a\", \"b\", \"z\"], 3\n");
    correct += test((int[]){"x", "y", "z"}, 3, (int[]){"a", "b", "z"}, 3, 3, ialloc((int[]){"a", "b", "x"}), 3);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We'll say that a positive int n is "endy" if it is in the range
0..10 or 90..100 (inclusive). Given an array of positive ints,
return a new array of length "count" containing the first endy
numbers from the original array. Decompose out a separate
isEndy(int n) method to test if a number is endy. The original
array will contain at least "count" endy numbers.
*/

int * copyEndy(int nums[], int numsSize, int count)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int count, int * expected, int expectedSize)
{
    int * returned = copyEndy(nums, numsSize, count);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [9, 11, 90, 22, 6], 2\n");
    correct += test((int[]){9, 11, 90, 22, 6}, 5, 2, ialloc((int[]){9, 90}), 2);
    total++;
    printf("Sent: [9, 11, 90, 22, 6], 3\n");
    correct += test((int[]){9, 11, 90, 22, 6}, 5, 3, ialloc((int[]){9, 90, 6}), 3);
    total++;
    printf("Sent: [12, 1, 1, 13, 0, 20], 2\n");
    correct += test((int[]){12, 1, 1, 13, 0, 20}, 6, 2, ialloc((int[]){1, 1}), 2);
    total++;
    printf("Sent: [12, 1, 1, 13, 0, 20], 3\n");
    correct += test((int[]){12, 1, 1, 13, 0, 20}, 6, 3, ialloc((int[]){1, 1, 0}), 3);
    total++;
    printf("Sent: [0], 1\n");
    correct += test((int[]){0}, 1, 1, ialloc((int[]){0}), 1);
    total++;
    printf("Sent: [10, 11, 90], 2\n");
    correct += test((int[]){10, 11, 90}, 3, 2, ialloc((int[]){10, 90}), 2);
    total++;
    printf("Sent: [90, 22, 100], 2\n");
    correct += test((int[]){90, 22, 100}, 3, 2, ialloc((int[]){90, 100}), 2);
    total++;
    printf("Sent: [12, 11, 10, 89, 101, 4], 1\n");
    correct += test((int[]){12, 11, 10, 89, 101, 4}, 6, 1, ialloc((int[]){10}), 1);
    total++;
    printf("Sent: [13, 2, 2, 0], 2\n");
    correct += test((int[]){13, 2, 2, 0}, 4, 2, ialloc((int[]){2, 2}), 2);
    total++;
    printf("Sent: [13, 2, 2, 0], 3\n");
    correct += test((int[]){13, 2, 2, 0}, 4, 3, ialloc((int[]){2, 2, 0}), 3);
    total++;
    printf("Sent: [13, 2, 13, 2, 0, 30], 2\n");
    correct += test((int[]){13, 2, 13, 2, 0, 30}, 6, 2, ialloc((int[]){2, 2}), 2);
    total++;
    printf("Sent: [13, 2, 13, 2, 0, 30], 3\n");
    correct += test((int[]){13, 2, 13, 2, 0, 30}, 6, 3, ialloc((int[]){2, 2, 0}), 3);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

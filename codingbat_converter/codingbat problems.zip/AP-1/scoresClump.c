#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of scores sorted in increasing order, return TRUE
if the array contains 3 adjacent scores that differ from each
other by at most 2, such as with {3, 4, 5} or {3, 5, 5}.
*/

int scoresClump(int scores[], int scoresSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int scores[], int scoresSize, int expected)
{
    int returned = scoresClump(scores, scoresSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [3, 4, 5]\n");
    correct += test((int[]){3, 4, 5}, 3, TRUE);
    total++;
    printf("Sent: [3, 4, 6]\n");
    correct += test((int[]){3, 4, 6}, 3, FALSE);
    total++;
    printf("Sent: [1, 3, 5, 5]\n");
    correct += test((int[]){1, 3, 5, 5}, 4, TRUE);
    total++;
    printf("Sent: [2, 4, 5, 6]\n");
    correct += test((int[]){2, 4, 5, 6}, 4, TRUE);
    total++;
    printf("Sent: [2, 4, 5, 7]\n");
    correct += test((int[]){2, 4, 5, 7}, 4, FALSE);
    total++;
    printf("Sent: [2, 4, 4, 7]\n");
    correct += test((int[]){2, 4, 4, 7}, 4, TRUE);
    total++;
    printf("Sent: [3, 3, 6, 7, 9]\n");
    correct += test((int[]){3, 3, 6, 7, 9}, 5, FALSE);
    total++;
    printf("Sent: [3, 3, 7, 7, 9]\n");
    correct += test((int[]){3, 3, 7, 7, 9}, 5, TRUE);
    total++;
    printf("Sent: [4, 5, 8]\n");
    correct += test((int[]){4, 5, 8}, 3, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We'll say that a positive int divides itself if every digit in
the number divides into the number evenly. So for example 128
divides itself since 1, 2, and 8 all divide into 128 evenly.
We'll say that 0 does not divide into anything evenly, so no
number with a 0 digit divides itself. Note: use % to get the
rightmost digit, and / to discard the rightmost digit.
*/

int dividesSelf(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int expected)
{
    int returned = dividesSelf(n);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 128\n");
    correct += test(128, TRUE);
    total++;
    printf("Sent: 12\n");
    correct += test(12, TRUE);
    total++;
    printf("Sent: 120\n");
    correct += test(120, FALSE);
    total++;
    printf("Sent: 122\n");
    correct += test(122, TRUE);
    total++;
    printf("Sent: 13\n");
    correct += test(13, FALSE);
    total++;
    printf("Sent: 32\n");
    correct += test(32, FALSE);
    total++;
    printf("Sent: 22\n");
    correct += test(22, TRUE);
    total++;
    printf("Sent: 42\n");
    correct += test(42, FALSE);
    total++;
    printf("Sent: 212\n");
    correct += test(212, TRUE);
    total++;
    printf("Sent: 213\n");
    correct += test(213, FALSE);
    total++;
    printf("Sent: 162\n");
    correct += test(162, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of strings, return a new array containing the
first N strings. N will be in the range 1..length.
*/

String[] wordsFront(String[] words, int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(String[] words, int n, String[] expected)
{

}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [\"a\", \"b\", \"c\", \"d\"], 1\n");
    correct += test((int[]){"a", "b", "c", "d"}, 4, 1, ialloc((int[]){"a"}), 1);
    total++;
    printf("Sent: [\"a\", \"b\", \"c\", \"d\"], 2\n");
    correct += test((int[]){"a", "b", "c", "d"}, 4, 2, ialloc((int[]){"a", "b"}), 2);
    total++;
    printf("Sent: [\"a\", \"b\", \"c\", \"d\"], 3\n");
    correct += test((int[]){"a", "b", "c", "d"}, 4, 3, ialloc((int[]){"a", "b", "c"}), 3);
    total++;
    printf("Sent: [\"a\", \"b\", \"c\", \"d\"], 4\n");
    correct += test((int[]){"a", "b", "c", "d"}, 4, 4, ialloc((int[]){"a", "b", "c", "d"}), 4);
    total++;
    printf("Sent: [\"Hi\", \"There\"], 1\n");
    correct += test((int[]){"Hi", "There"}, 2, 1, ialloc((int[]){"Hi"}), 1);
    total++;
    printf("Sent: [\"Hi\", \"There\"], 2\n");
    correct += test((int[]){"Hi", "There"}, 2, 2, ialloc((int[]){"Hi", "There"}), 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

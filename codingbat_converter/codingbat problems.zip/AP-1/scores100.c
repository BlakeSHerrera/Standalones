#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of scores, return TRUE if there are scores of 100
next to each other in the array. The array length will be at
least 2.
*/

int scores100(int scores[], int scoresSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int scores[], int scoresSize, int expected)
{
    int returned = scores100(scores, scoresSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 100, 100]\n");
    correct += test((int[]){1, 100, 100}, 3, TRUE);
    total++;
    printf("Sent: [1, 100, 99, 100]\n");
    correct += test((int[]){1, 100, 99, 100}, 4, FALSE);
    total++;
    printf("Sent: [100, 1, 100, 100]\n");
    correct += test((int[]){100, 1, 100, 100}, 4, TRUE);
    total++;
    printf("Sent: [100, 1, 100, 1]\n");
    correct += test((int[]){100, 1, 100, 1}, 4, FALSE);
    total++;
    printf("Sent: [1, 2, 3, 4, 5]\n");
    correct += test((int[]){1, 2, 3, 4, 5}, 5, FALSE);
    total++;
    printf("Sent: [1, 2, 100, 4, 5]\n");
    correct += test((int[]){1, 2, 100, 4, 5}, 5, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

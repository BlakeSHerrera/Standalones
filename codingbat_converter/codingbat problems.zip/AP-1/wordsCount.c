#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of strings, return the count of the number of
strings with the given length.
*/

int wordsCount(String[] words, int len)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(String[] words, int len, int expected)
{
    int returned = wordsCount(words, len);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [\"a\", \"bb\", \"b\", \"ccc\"], 1\n");
    correct += test((int[]){"a", "bb", "b", "ccc"}, 4, 1, 2);
    total++;
    printf("Sent: [\"a\", \"bb\", \"b\", \"ccc\"], 3\n");
    correct += test((int[]){"a", "bb", "b", "ccc"}, 4, 3, 1);
    total++;
    printf("Sent: [\"a\", \"bb\", \"b\", \"ccc\"], 4\n");
    correct += test((int[]){"a", "bb", "b", "ccc"}, 4, 4, 0);
    total++;
    printf("Sent: [\"xx\", \"yyy\", \"x\", \"yy\", \"z\"], 1\n");
    correct += test((int[]){"xx", "yyy", "x", "yy", "z"}, 5, 1, 2);
    total++;
    printf("Sent: [\"xx\", \"yyy\", \"x\", \"yy\", \"z\"], 2\n");
    correct += test((int[]){"xx", "yyy", "x", "yy", "z"}, 5, 2, 2);
    total++;
    printf("Sent: [\"xx\", \"yyy\", \"x\", \"yy\", \"z\"], 3\n");
    correct += test((int[]){"xx", "yyy", "x", "yy", "z"}, 5, 3, 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

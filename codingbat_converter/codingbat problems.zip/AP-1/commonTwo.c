#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Start with two arrays of strings, a and b, each in alphabetical
order, possibly with duplicates. Return the count of the number
of strings which appear in both arrays. The best "linear"
solution makes a single pass over both arrays, taking advantage
of the fact that they are in alphabetical order.
*/

int commonTwo(String[] a, String[] b)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(String[] a, String[] b, int expected)
{
    int returned = commonTwo(a, b);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [\"a\", \"c\", \"x\"], [\"b\", \"c\", \"d\", \"x\"]\n");
    correct += test((int[]){"a", "c", "x"}, 3, (int[]){"b", "c", "d", "x"}, 4, 2);
    total++;
    printf("Sent: [\"a\", \"c\", \"x\"], [\"a\", \"b\", \"c\", \"x\", \"z\"]\n");
    correct += test((int[]){"a", "c", "x"}, 3, (int[]){"a", "b", "c", "x", "z"}, 5, 3);
    total++;
    printf("Sent: [\"a\", \"b\", \"c\"], [\"a\", \"b\", \"c\"]\n");
    correct += test((int[]){"a", "b", "c"}, 3, (int[]){"a", "b", "c"}, 3, 3);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\", \"c\"], [\"a\", \"b\", \"c\"]\n");
    correct += test((int[]){"a", "a", "b", "b", "c"}, 5, (int[]){"a", "b", "c"}, 3, 3);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\", \"c\"], [\"a\", \"b\", \"b\", \"b\", \"c\"]\n");
    correct += test((int[]){"a", "a", "b", "b", "c"}, 5, (int[]){"a", "b", "b", "b", "c"}, 5, 3);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\", \"c\"], [\"a\", \"b\", \"b\", \"c\", \"c\"]\n");
    correct += test((int[]){"a", "a", "b", "b", "c"}, 5, (int[]){"a", "b", "b", "c", "c"}, 5, 3);
    total++;
    printf("Sent: [\"b\", \"b\", \"b\", \"b\", \"c\"], [\"a\", \"b\", \"b\", \"b\", \"c\"]\n");
    correct += test((int[]){"b", "b", "b", "b", "c"}, 5, (int[]){"a", "b", "b", "b", "c"}, 5, 2);
    total++;
    printf("Sent: [\"a\", \"b\", \"c\", \"c\", \"d\"], [\"a\", \"b\", \"b\", \"c\", \"d\", \"d\"]\n");
    correct += test((int[]){"a", "b", "c", "c", "d"}, 5, (int[]){"a", "b", "b", "c", "d", "d"}, 6, 4);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\", \"c\"], [\"b\", \"b\", \"b\"]\n");
    correct += test((int[]){"a", "a", "b", "b", "c"}, 5, (int[]){"b", "b", "b"}, 3, 1);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\", \"c\"], [\"c\", \"c\"]\n");
    correct += test((int[]){"a", "a", "b", "b", "c"}, 5, (int[]){"c", "c"}, 2, 1);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\", \"c\"], [\"b\", \"b\", \"b\", \"x\"]\n");
    correct += test((int[]){"a", "a", "b", "b", "c"}, 5, (int[]){"b", "b", "b", "x"}, 4, 1);
    total++;
    printf("Sent: [\"a\", \"a\", \"b\", \"b\", \"c\"], [\"b\", \"b\"]\n");
    correct += test((int[]){"a", "a", "b", "b", "c"}, 5, (int[]){"b", "b"}, 2, 1);
    total++;
    printf("Sent: [\"a\"], [\"a\", \"b\"]\n");
    correct += test((int[]){"a"}, 1, (int[]){"a", "b"}, 2, 1);
    total++;
    printf("Sent: [\"a\"], [\"b\"]\n");
    correct += test((int[]){"a"}, 1, (int[]){"b"}, 1, 0);
    total++;
    printf("Sent: [\"a\", \"a\"], [\"b\", \"b\"]\n");
    correct += test((int[]){"a", "a"}, 2, (int[]){"b", "b"}, 2, 0);
    total++;
    printf("Sent: [\"a\", \"b\"], [\"a\", \"b\"]\n");
    correct += test((int[]){"a", "b"}, 2, (int[]){"a", "b"}, 2, 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
(A variation on the sumHeights problem.) We have an array of
heights, representing the altitude along a walking trail. Given
start/end indexes into the array, return the sum of the changes
for a walk beginning at the start index and ending at the end
index, however increases in height count double. For example,
with the heights {5, 3, 6, 7, 2} and start=2, end=4 yields a sum
of 1*2 + 5 = 7. The start end end index will both be valid
indexes into the array with start <= end.
*/

int sumHeights2(int heights[], int heightsSize, int start, int end)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int heights[], int heightsSize, int start, int end, int expected)
{
    int returned = sumHeights2(heights, heightsSize, start, end);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [5, 3, 6, 7, 2], 2, 4\n");
    correct += test((int[]){5, 3, 6, 7, 2}, 5, 2, 4, 7);
    total++;
    printf("Sent: [5, 3, 6, 7, 2], 0, 1\n");
    correct += test((int[]){5, 3, 6, 7, 2}, 5, 0, 1, 2);
    total++;
    printf("Sent: [5, 3, 6, 7, 2], 0, 4\n");
    correct += test((int[]){5, 3, 6, 7, 2}, 5, 0, 4, 15);
    total++;
    printf("Sent: [5, 3, 6, 7, 2], 1, 1\n");
    correct += test((int[]){5, 3, 6, 7, 2}, 5, 1, 1, 0);
    total++;
    printf("Sent: [1, 2, 3, 4, 5, 4, 3, 2, 10], 0, 3\n");
    correct += test((int[]){1, 2, 3, 4, 5, 4, 3, 2, 10}, 9, 0, 3, 6);
    total++;
    printf("Sent: [1, 2, 3, 4, 5, 4, 3, 2, 10], 4, 8\n");
    correct += test((int[]){1, 2, 3, 4, 5, 4, 3, 2, 10}, 9, 4, 8, 19);
    total++;
    printf("Sent: [1, 2, 3, 4, 5, 4, 3, 2, 10], 7, 8\n");
    correct += test((int[]){1, 2, 3, 4, 5, 4, 3, 2, 10}, 9, 7, 8, 16);
    total++;
    printf("Sent: [1, 2, 3, 4, 5, 4, 3, 2, 10], 8, 8\n");
    correct += test((int[]){1, 2, 3, 4, 5, 4, 3, 2, 10}, 9, 8, 8, 0);
    total++;
    printf("Sent: [1, 2, 3, 4, 5, 4, 3, 2, 10], 2, 2\n");
    correct += test((int[]){1, 2, 3, 4, 5, 4, 3, 2, 10}, 9, 2, 2, 0);
    total++;
    printf("Sent: [1, 2, 3, 4, 5, 4, 3, 2, 10], 3, 6\n");
    correct += test((int[]){1, 2, 3, 4, 5, 4, 3, 2, 10}, 9, 3, 6, 4);
    total++;
    printf("Sent: [10, 8, 7, 7, 7, 6, 7], 1, 4\n");
    correct += test((int[]){10, 8, 7, 7, 7, 6, 7}, 7, 1, 4, 1);
    total++;
    printf("Sent: [10, 8, 7, 7, 7, 6, 7], 1, 5\n");
    correct += test((int[]){10, 8, 7, 7, 7, 6, 7}, 7, 1, 5, 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

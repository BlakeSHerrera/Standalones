#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given three ints, a b c, return TRUE if one of b or c is "close"
(differing from a by at most 1), while the other is "far",
differing from both other values by 2 or more. Note:
Math.abs(num) computes the absolute value of a number.
*/

int closeFar(int a, int b, int c)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int c, int expected)
{
    int returned = closeFar(a, b, c);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 1, 2, 10\n");
    correct += test(1, 2, 10, TRUE);
    total++;
    printf("Sent: 1, 2, 3\n");
    correct += test(1, 2, 3, FALSE);
    total++;
    printf("Sent: 4, 1, 3\n");
    correct += test(4, 1, 3, TRUE);
    total++;
    printf("Sent: 4, 5, 3\n");
    correct += test(4, 5, 3, FALSE);
    total++;
    printf("Sent: 4, 3, 5\n");
    correct += test(4, 3, 5, FALSE);
    total++;
    printf("Sent: -1, 10, 0\n");
    correct += test(-1, 10, 0, TRUE);
    total++;
    printf("Sent: 0, -1, 10\n");
    correct += test(0, -1, 10, TRUE);
    total++;
    printf("Sent: 10, 10, 8\n");
    correct += test(10, 10, 8, TRUE);
    total++;
    printf("Sent: 10, 8, 9\n");
    correct += test(10, 8, 9, FALSE);
    total++;
    printf("Sent: 8, 9, 10\n");
    correct += test(8, 9, 10, FALSE);
    total++;
    printf("Sent: 8, 9, 7\n");
    correct += test(8, 9, 7, FALSE);
    total++;
    printf("Sent: 8, 6, 9\n");
    correct += test(8, 6, 9, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

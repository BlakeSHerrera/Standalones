#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 3 int values, a b c, return their sum. However, if one of
the values is 13 then it does not count towards the sum and
values to its right do not count. So for example, if b is 13,
then both b and c do not count.
*/

int luckySum(int a, int b, int c)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int c, int expected)
{
    int returned = luckySum(a, b, c);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 1, 2, 3\n");
    correct += test(1, 2, 3, 6);
    total++;
    printf("Sent: 1, 2, 13\n");
    correct += test(1, 2, 13, 3);
    total++;
    printf("Sent: 1, 13, 3\n");
    correct += test(1, 13, 3, 1);
    total++;
    printf("Sent: 1, 13, 13\n");
    correct += test(1, 13, 13, 1);
    total++;
    printf("Sent: 6, 5, 2\n");
    correct += test(6, 5, 2, 13);
    total++;
    printf("Sent: 13, 2, 3\n");
    correct += test(13, 2, 3, 0);
    total++;
    printf("Sent: 13, 2, 13\n");
    correct += test(13, 2, 13, 0);
    total++;
    printf("Sent: 13, 13, 2\n");
    correct += test(13, 13, 2, 0);
    total++;
    printf("Sent: 9, 4, 13\n");
    correct += test(9, 4, 13, 13);
    total++;
    printf("Sent: 8, 13, 2\n");
    correct += test(8, 13, 2, 8);
    total++;
    printf("Sent: 7, 2, 1\n");
    correct += test(7, 2, 1, 10);
    total++;
    printf("Sent: 3, 3, 13\n");
    correct += test(3, 3, 13, 6);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 3 int values, a b c, return their sum. However, if any of
the values is a teen -- in the range 13..19 inclusive -- then
that value counts as 0, except 15 and 16 do not count as a teens.
Write a separate helper "public int fixTeen(int n) {"that takes
in an int value and returns that value fixed for the teen rule.
In this way, you avoid repeating the teen code 3 times (i.e.
"decomposition"). Define the helper below and at the same indent
level as the main noTeenSum().
*/

int noTeenSum(int a, int b, int c)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int c, int expected)
{
    int returned = noTeenSum(a, b, c);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 1, 2, 3\n");
    correct += test(1, 2, 3, 6);
    total++;
    printf("Sent: 2, 13, 1\n");
    correct += test(2, 13, 1, 3);
    total++;
    printf("Sent: 2, 1, 14\n");
    correct += test(2, 1, 14, 3);
    total++;
    printf("Sent: 2, 1, 15\n");
    correct += test(2, 1, 15, 18);
    total++;
    printf("Sent: 2, 1, 16\n");
    correct += test(2, 1, 16, 19);
    total++;
    printf("Sent: 2, 1, 17\n");
    correct += test(2, 1, 17, 3);
    total++;
    printf("Sent: 17, 1, 2\n");
    correct += test(17, 1, 2, 3);
    total++;
    printf("Sent: 2, 15, 2\n");
    correct += test(2, 15, 2, 19);
    total++;
    printf("Sent: 16, 17, 18\n");
    correct += test(16, 17, 18, 16);
    total++;
    printf("Sent: 17, 18, 19\n");
    correct += test(17, 18, 19, 0);
    total++;
    printf("Sent: 15, 16, 1\n");
    correct += test(15, 16, 1, 32);
    total++;
    printf("Sent: 15, 15, 19\n");
    correct += test(15, 15, 19, 30);
    total++;
    printf("Sent: 15, 19, 16\n");
    correct += test(15, 19, 16, 31);
    total++;
    printf("Sent: 5, 17, 18\n");
    correct += test(5, 17, 18, 5);
    total++;
    printf("Sent: 17, 18, 16\n");
    correct += test(17, 18, 16, 16);
    total++;
    printf("Sent: 17, 19, 18\n");
    correct += test(17, 19, 18, 0);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
For this problem, we'll round an int value up to the next
multiple of 10 if its rightmost digit is 5 or more, so 15 rounds
up to 20. Alternately, round down to the previous multiple of 10
if its rightmost digit is less than 5, so 12 rounds down to 10.
Given 3 ints, a b c, return the sum of their rounded values. To
avoid code repetition, write a separate helper "public int
round10(int num) {" and call it 3 times. Write the helper
entirely below and at the same indent level as roundSum().
*/

int roundSum(int a, int b, int c)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a, int b, int c, int expected)
{
    int returned = roundSum(a, b, c);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 16, 17, 18\n");
    correct += test(16, 17, 18, 60);
    total++;
    printf("Sent: 12, 13, 14\n");
    correct += test(12, 13, 14, 30);
    total++;
    printf("Sent: 6, 4, 4\n");
    correct += test(6, 4, 4, 10);
    total++;
    printf("Sent: 4, 6, 5\n");
    correct += test(4, 6, 5, 20);
    total++;
    printf("Sent: 4, 4, 6\n");
    correct += test(4, 4, 6, 10);
    total++;
    printf("Sent: 9, 4, 4\n");
    correct += test(9, 4, 4, 10);
    total++;
    printf("Sent: 0, 0, 1\n");
    correct += test(0, 0, 1, 0);
    total++;
    printf("Sent: 0, 9, 0\n");
    correct += test(0, 9, 0, 10);
    total++;
    printf("Sent: 10, 10, 19\n");
    correct += test(10, 10, 19, 40);
    total++;
    printf("Sent: 20, 30, 40\n");
    correct += test(20, 30, 40, 90);
    total++;
    printf("Sent: 45, 21, 30\n");
    correct += test(45, 21, 30, 100);
    total++;
    printf("Sent: 23, 11, 26\n");
    correct += test(23, 11, 26, 60);
    total++;
    printf("Sent: 23, 24, 25\n");
    correct += test(23, 24, 25, 70);
    total++;
    printf("Sent: 25, 24, 25\n");
    correct += test(25, 24, 25, 80);
    total++;
    printf("Sent: 23, 24, 29\n");
    correct += test(23, 24, 29, 70);
    total++;
    printf("Sent: 11, 24, 36\n");
    correct += test(11, 24, 36, 70);
    total++;
    printf("Sent: 24, 36, 32\n");
    correct += test(24, 36, 32, 90);
    total++;
    printf("Sent: 14, 12, 26\n");
    correct += test(14, 12, 26, 50);
    total++;
    printf("Sent: 12, 10, 24\n");
    correct += test(12, 10, 24, 40);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We want make a package of goal kilos of chocolate. We have small
bars (1 kilo each) and big bars (5 kilos each). Return the number
of small bars to use, assuming we always use big bars before
small bars. Return -1 if it can't be done.
*/

int makeChocolate(int small, int big, int goal)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int small, int big, int goal, int expected)
{
    int returned = makeChocolate(small, big, goal);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 4, 1, 9\n");
    correct += test(4, 1, 9, 4);
    total++;
    printf("Sent: 4, 1, 10\n");
    correct += test(4, 1, 10, -1);
    total++;
    printf("Sent: 4, 1, 7\n");
    correct += test(4, 1, 7, 2);
    total++;
    printf("Sent: 6, 2, 7\n");
    correct += test(6, 2, 7, 2);
    total++;
    printf("Sent: 4, 1, 5\n");
    correct += test(4, 1, 5, 0);
    total++;
    printf("Sent: 4, 1, 4\n");
    correct += test(4, 1, 4, 4);
    total++;
    printf("Sent: 5, 4, 9\n");
    correct += test(5, 4, 9, 4);
    total++;
    printf("Sent: 9, 3, 18\n");
    correct += test(9, 3, 18, 3);
    total++;
    printf("Sent: 3, 1, 9\n");
    correct += test(3, 1, 9, -1);
    total++;
    printf("Sent: 1, 2, 7\n");
    correct += test(1, 2, 7, -1);
    total++;
    printf("Sent: 1, 2, 6\n");
    correct += test(1, 2, 6, 1);
    total++;
    printf("Sent: 1, 2, 5\n");
    correct += test(1, 2, 5, 0);
    total++;
    printf("Sent: 6, 1, 10\n");
    correct += test(6, 1, 10, 5);
    total++;
    printf("Sent: 6, 1, 11\n");
    correct += test(6, 1, 11, 6);
    total++;
    printf("Sent: 6, 1, 12\n");
    correct += test(6, 1, 12, -1);
    total++;
    printf("Sent: 6, 1, 13\n");
    correct += test(6, 1, 13, -1);
    total++;
    printf("Sent: 6, 2, 10\n");
    correct += test(6, 2, 10, 0);
    total++;
    printf("Sent: 6, 2, 11\n");
    correct += test(6, 2, 11, 1);
    total++;
    printf("Sent: 6, 2, 12\n");
    correct += test(6, 2, 12, 2);
    total++;
    printf("Sent: 60, 100, 550\n");
    correct += test(60, 100, 550, 50);
    total++;
    printf("Sent: 1000, 1000000, 5000006\n");
    correct += test(1000, 1000000, 5000006, 6);
    total++;
    printf("Sent: 7, 1, 12\n");
    correct += test(7, 1, 12, 7);
    total++;
    printf("Sent: 7, 1, 13\n");
    correct += test(7, 1, 13, -1);
    total++;
    printf("Sent: 7, 2, 13\n");
    correct += test(7, 2, 13, 3);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

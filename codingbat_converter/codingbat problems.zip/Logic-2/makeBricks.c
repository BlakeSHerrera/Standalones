#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We want to make a row of bricks that is goal inches long. We have
a number of small bricks (1 inch each) and big bricks (5 inches
each). Return TRUE if it is possible to make the goal by choosing
from the given bricks. This is a little harder than it looks and
can be done without any loops. See also: Introduction to
MakeBricks
*/

int makeBricks(int small, int big, int goal)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int small, int big, int goal, int expected)
{
    int returned = makeBricks(small, big, goal);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 3, 1, 8\n");
    correct += test(3, 1, 8, TRUE);
    total++;
    printf("Sent: 3, 1, 9\n");
    correct += test(3, 1, 9, FALSE);
    total++;
    printf("Sent: 3, 2, 10\n");
    correct += test(3, 2, 10, TRUE);
    total++;
    printf("Sent: 3, 2, 8\n");
    correct += test(3, 2, 8, TRUE);
    total++;
    printf("Sent: 3, 2, 9\n");
    correct += test(3, 2, 9, FALSE);
    total++;
    printf("Sent: 6, 1, 11\n");
    correct += test(6, 1, 11, TRUE);
    total++;
    printf("Sent: 6, 0, 11\n");
    correct += test(6, 0, 11, FALSE);
    total++;
    printf("Sent: 1, 4, 11\n");
    correct += test(1, 4, 11, TRUE);
    total++;
    printf("Sent: 0, 3, 10\n");
    correct += test(0, 3, 10, TRUE);
    total++;
    printf("Sent: 1, 4, 12\n");
    correct += test(1, 4, 12, FALSE);
    total++;
    printf("Sent: 3, 1, 7\n");
    correct += test(3, 1, 7, TRUE);
    total++;
    printf("Sent: 1, 1, 7\n");
    correct += test(1, 1, 7, FALSE);
    total++;
    printf("Sent: 2, 1, 7\n");
    correct += test(2, 1, 7, TRUE);
    total++;
    printf("Sent: 7, 1, 11\n");
    correct += test(7, 1, 11, TRUE);
    total++;
    printf("Sent: 7, 1, 8\n");
    correct += test(7, 1, 8, TRUE);
    total++;
    printf("Sent: 7, 1, 13\n");
    correct += test(7, 1, 13, FALSE);
    total++;
    printf("Sent: 43, 1, 46\n");
    correct += test(43, 1, 46, TRUE);
    total++;
    printf("Sent: 40, 1, 46\n");
    correct += test(40, 1, 46, FALSE);
    total++;
    printf("Sent: 40, 2, 47\n");
    correct += test(40, 2, 47, TRUE);
    total++;
    printf("Sent: 40, 2, 50\n");
    correct += test(40, 2, 50, TRUE);
    total++;
    printf("Sent: 40, 2, 52\n");
    correct += test(40, 2, 52, FALSE);
    total++;
    printf("Sent: 22, 2, 33\n");
    correct += test(22, 2, 33, FALSE);
    total++;
    printf("Sent: 0, 2, 10\n");
    correct += test(0, 2, 10, TRUE);
    total++;
    printf("Sent: 1000000, 1000, 1000100\n");
    correct += test(1000000, 1000, 1000100, TRUE);
    total++;
    printf("Sent: 2, 1000000, 100003\n");
    correct += test(2, 1000000, 100003, FALSE);
    total++;
    printf("Sent: 20, 0, 19\n");
    correct += test(20, 0, 19, TRUE);
    total++;
    printf("Sent: 20, 0, 21\n");
    correct += test(20, 0, 21, FALSE);
    total++;
    printf("Sent: 20, 4, 51\n");
    correct += test(20, 4, 51, FALSE);
    total++;
    printf("Sent: 20, 4, 39\n");
    correct += test(20, 4, 39, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

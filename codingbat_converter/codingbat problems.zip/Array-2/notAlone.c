#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We'll say that an element in an array is "alone" if there are
values before and after it, and those values are different from
it. Return a version of the given array where every instance of
the given value which is alone is replaced by whichever value to
its left or right is larger.
*/

int * notAlone(int nums[], int numsSize, int val)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int val, int * expected, int expectedSize)
{
    int * returned = notAlone(nums, numsSize, val);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3], 2\n");
    correct += test((int[]){1, 2, 3}, 3, 2, ialloc((int[]){1, 3, 3}), 3);
    total++;
    printf("Sent: [1, 2, 3, 2, 5, 2], 2\n");
    correct += test((int[]){1, 2, 3, 2, 5, 2}, 6, 2, ialloc((int[]){1, 3, 3, 5, 5, 2}), 6);
    total++;
    printf("Sent: [3, 4], 3\n");
    correct += test((int[]){3, 4}, 2, 3, ialloc((int[]){3, 4}), 2);
    total++;
    printf("Sent: [3, 3], 3\n");
    correct += test((int[]){3, 3}, 2, 3, ialloc((int[]){3, 3}), 2);
    total++;
    printf("Sent: [1, 3, 1, 2], 1\n");
    correct += test((int[]){1, 3, 1, 2}, 4, 1, ialloc((int[]){1, 3, 3, 2}), 4);
    total++;
    printf("Sent: [3], 3\n");
    correct += test((int[]){3}, 1, 3, ialloc((int[]){3}), 1);
    total++;
    printf("Sent: [], 3\n");
    correct += test((int[]){}, 1, 3, ialloc((int[]){}), 1);
    total++;
    printf("Sent: [7, 1, 6], 1\n");
    correct += test((int[]){7, 1, 6}, 3, 1, ialloc((int[]){7, 7, 6}), 3);
    total++;
    printf("Sent: [1, 1, 1], 1\n");
    correct += test((int[]){1, 1, 1}, 3, 1, ialloc((int[]){1, 1, 1}), 3);
    total++;
    printf("Sent: [1, 1, 1, 2], 1\n");
    correct += test((int[]){1, 1, 1, 2}, 4, 1, ialloc((int[]){1, 1, 1, 2}), 4);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return a version of the given array where all the 10's have been
removed. The remaining elements should shift left towards the
start of the array as needed, and the empty spaces a the end of
the array should be 0. So {1, 10, 10, 2} yields {1, 2, 0, 0}. You
may modify and return the given array or make a new array.
*/

int * withoutTen(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int * expected, int expectedSize)
{
    int * returned = withoutTen(nums, numsSize);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 10, 10, 2]\n");
    correct += test((int[]){1, 10, 10, 2}, 4, ialloc((int[]){1, 2, 0, 0}), 4);
    total++;
    printf("Sent: [10, 2, 10]\n");
    correct += test((int[]){10, 2, 10}, 3, ialloc((int[]){2, 0, 0}), 3);
    total++;
    printf("Sent: [1, 99, 10]\n");
    correct += test((int[]){1, 99, 10}, 3, ialloc((int[]){1, 99, 0}), 3);
    total++;
    printf("Sent: [10, 13, 10, 14]\n");
    correct += test((int[]){10, 13, 10, 14}, 4, ialloc((int[]){13, 14, 0, 0}), 4);
    total++;
    printf("Sent: [10, 13, 10, 14, 10]\n");
    correct += test((int[]){10, 13, 10, 14, 10}, 5, ialloc((int[]){13, 14, 0, 0, 0}), 5);
    total++;
    printf("Sent: [10, 10, 3]\n");
    correct += test((int[]){10, 10, 3}, 3, ialloc((int[]){3, 0, 0}), 3);
    total++;
    printf("Sent: [1]\n");
    correct += test((int[]){1}, 1, ialloc((int[]){1}), 1);
    total++;
    printf("Sent: [13, 1]\n");
    correct += test((int[]){13, 1}, 2, ialloc((int[]){13, 1}), 2);
    total++;
    printf("Sent: [10]\n");
    correct += test((int[]){10}, 1, ialloc((int[]){0}), 1);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, ialloc((int[]){}), 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

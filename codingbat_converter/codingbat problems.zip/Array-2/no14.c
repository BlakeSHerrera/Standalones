#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, return TRUE if it contains no 1's or it
contains no 4's.
*/

int no14(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = no14(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, TRUE);
    total++;
    printf("Sent: [1, 2, 3, 4]\n");
    correct += test((int[]){1, 2, 3, 4}, 4, FALSE);
    total++;
    printf("Sent: [2, 3, 4]\n");
    correct += test((int[]){2, 3, 4}, 3, TRUE);
    total++;
    printf("Sent: [1, 1, 4, 4]\n");
    correct += test((int[]){1, 1, 4, 4}, 4, FALSE);
    total++;
    printf("Sent: [2, 2, 4, 4]\n");
    correct += test((int[]){2, 2, 4, 4}, 4, TRUE);
    total++;
    printf("Sent: [2, 3, 4, 1]\n");
    correct += test((int[]){2, 3, 4, 1}, 4, FALSE);
    total++;
    printf("Sent: [2, 1, 1]\n");
    correct += test((int[]){2, 1, 1}, 3, TRUE);
    total++;
    printf("Sent: [1, 4]\n");
    correct += test((int[]){1, 4}, 2, FALSE);
    total++;
    printf("Sent: [2]\n");
    correct += test((int[]){2}, 1, TRUE);
    total++;
    printf("Sent: [2, 1]\n");
    correct += test((int[]){2, 1}, 2, TRUE);
    total++;
    printf("Sent: [1]\n");
    correct += test((int[]){1}, 1, TRUE);
    total++;
    printf("Sent: [4]\n");
    correct += test((int[]){4}, 1, TRUE);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, TRUE);
    total++;
    printf("Sent: [1, 1, 1, 1]\n");
    correct += test((int[]){1, 1, 1, 1}, 4, TRUE);
    total++;
    printf("Sent: [9, 4, 4, 1]\n");
    correct += test((int[]){9, 4, 4, 1}, 4, FALSE);
    total++;
    printf("Sent: [4, 2, 3, 1]\n");
    correct += test((int[]){4, 2, 3, 1}, 4, FALSE);
    total++;
    printf("Sent: [4, 2, 3, 5]\n");
    correct += test((int[]){4, 2, 3, 5}, 4, TRUE);
    total++;
    printf("Sent: [4, 4, 2]\n");
    correct += test((int[]){4, 4, 2}, 3, TRUE);
    total++;
    printf("Sent: [1, 4, 4]\n");
    correct += test((int[]){1, 4, 4}, 3, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

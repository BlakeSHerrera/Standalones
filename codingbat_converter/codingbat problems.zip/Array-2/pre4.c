#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a non-empty array of ints, return a new array containing
the elements from the original array that come before the first 4
in the original array. The original array will contain at least
one 4. Note that it is valid in java to create an array of length
0.
*/

int * pre4(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int * expected, int expectedSize)
{
    int * returned = pre4(nums, numsSize);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 4, 1]\n");
    correct += test((int[]){1, 2, 4, 1}, 4, ialloc((int[]){1, 2}), 2);
    total++;
    printf("Sent: [3, 1, 4]\n");
    correct += test((int[]){3, 1, 4}, 3, ialloc((int[]){3, 1}), 2);
    total++;
    printf("Sent: [1, 4, 4]\n");
    correct += test((int[]){1, 4, 4}, 3, ialloc((int[]){1}), 1);
    total++;
    printf("Sent: [1, 4, 4, 2]\n");
    correct += test((int[]){1, 4, 4, 2}, 4, ialloc((int[]){1}), 1);
    total++;
    printf("Sent: [1, 3, 4, 2, 4]\n");
    correct += test((int[]){1, 3, 4, 2, 4}, 5, ialloc((int[]){1, 3}), 2);
    total++;
    printf("Sent: [4, 4]\n");
    correct += test((int[]){4, 4}, 2, ialloc((int[]){}), 1);
    total++;
    printf("Sent: [3, 3, 4]\n");
    correct += test((int[]){3, 3, 4}, 3, ialloc((int[]){3, 3}), 2);
    total++;
    printf("Sent: [1, 2, 1, 4]\n");
    correct += test((int[]){1, 2, 1, 4}, 4, ialloc((int[]){1, 2, 1}), 3);
    total++;
    printf("Sent: [2, 1, 4, 2]\n");
    correct += test((int[]){2, 1, 4, 2}, 4, ialloc((int[]){2, 1}), 2);
    total++;
    printf("Sent: [2, 1, 2, 1, 4, 2]\n");
    correct += test((int[]){2, 1, 2, 1, 4, 2}, 6, ialloc((int[]){2, 1, 2, 1}), 4);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

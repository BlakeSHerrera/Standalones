#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array length 1 or more of ints, return the difference
between the largest and smallest values in the array. Note: the
built-in Math.min(v1, v2) and Math.max(v1, v2) methods  return
the smaller or larger of two values.
*/

int bigDiff(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = bigDiff(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [10, 3, 5, 6]\n");
    correct += test((int[]){10, 3, 5, 6}, 4, 7);
    total++;
    printf("Sent: [7, 2, 10, 9]\n");
    correct += test((int[]){7, 2, 10, 9}, 4, 8);
    total++;
    printf("Sent: [2, 10, 7, 2]\n");
    correct += test((int[]){2, 10, 7, 2}, 4, 8);
    total++;
    printf("Sent: [2, 10]\n");
    correct += test((int[]){2, 10}, 2, 8);
    total++;
    printf("Sent: [10, 2]\n");
    correct += test((int[]){10, 2}, 2, 8);
    total++;
    printf("Sent: [10, 0]\n");
    correct += test((int[]){10, 0}, 2, 10);
    total++;
    printf("Sent: [2, 3]\n");
    correct += test((int[]){2, 3}, 2, 1);
    total++;
    printf("Sent: [2, 2]\n");
    correct += test((int[]){2, 2}, 2, 0);
    total++;
    printf("Sent: [2]\n");
    correct += test((int[]){2}, 1, 0);
    total++;
    printf("Sent: [5, 1, 6, 1, 9, 9]\n");
    correct += test((int[]){5, 1, 6, 1, 9, 9}, 6, 8);
    total++;
    printf("Sent: [7, 6, 8, 5]\n");
    correct += test((int[]){7, 6, 8, 5}, 4, 3);
    total++;
    printf("Sent: [7, 7, 6, 8, 5, 5, 6]\n");
    correct += test((int[]){7, 7, 6, 8, 5, 5, 6}, 7, 3);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

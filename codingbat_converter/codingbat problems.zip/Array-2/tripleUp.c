#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return TRUE if the array contains, somewhere, three increasing
adjacent numbers like .... 4, 5, 6, ... or 23, 24, 25.
*/

int tripleUp(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = tripleUp(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 4, 5, 6, 2]\n");
    correct += test((int[]){1, 4, 5, 6, 2}, 5, TRUE);
    total++;
    printf("Sent: [1, 2, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, TRUE);
    total++;
    printf("Sent: [1, 2, 4]\n");
    correct += test((int[]){1, 2, 4}, 3, FALSE);
    total++;
    printf("Sent: [1, 2, 4, 5, 7, 6, 5, 6, 7, 6]\n");
    correct += test((int[]){1, 2, 4, 5, 7, 6, 5, 6, 7, 6}, 10, TRUE);
    total++;
    printf("Sent: [1, 2, 4, 5, 7, 6, 5, 7, 7, 6]\n");
    correct += test((int[]){1, 2, 4, 5, 7, 6, 5, 7, 7, 6}, 10, FALSE);
    total++;
    printf("Sent: [1, 2]\n");
    correct += test((int[]){1, 2}, 2, FALSE);
    total++;
    printf("Sent: [1]\n");
    correct += test((int[]){1}, 1, FALSE);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, FALSE);
    total++;
    printf("Sent: [10, 9, 8, -100, -99, -98, 100]\n");
    correct += test((int[]){10, 9, 8, -100, -99, -98, 100}, 7, TRUE);
    total++;
    printf("Sent: [10, 9, 8, -100, -99, 99, 100]\n");
    correct += test((int[]){10, 9, 8, -100, -99, 99, 100}, 7, FALSE);
    total++;
    printf("Sent: [-100, -99, -99, 100, 101, 102]\n");
    correct += test((int[]){-100, -99, -99, 100, 101, 102}, 6, TRUE);
    total++;
    printf("Sent: [2, 3, 5, 6, 8, 9, 2, 3]\n");
    correct += test((int[]){2, 3, 5, 6, 8, 9, 2, 3}, 8, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return the sum of the numbers in the array, returning 0 for an
empty array. Except the number 13 is very unlucky, so it does not
count and numbers that come immediately after a 13 also do not
count.
*/

int sum13(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = sum13(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 2, 1]\n");
    correct += test((int[]){1, 2, 2, 1}, 4, 6);
    total++;
    printf("Sent: [1, 1]\n");
    correct += test((int[]){1, 1}, 2, 2);
    total++;
    printf("Sent: [1, 2, 2, 1, 13]\n");
    correct += test((int[]){1, 2, 2, 1, 13}, 5, 6);
    total++;
    printf("Sent: [1, 2, 13, 2, 1, 13]\n");
    correct += test((int[]){1, 2, 13, 2, 1, 13}, 6, 4);
    total++;
    printf("Sent: [13, 1, 2, 13, 2, 1, 13]\n");
    correct += test((int[]){13, 1, 2, 13, 2, 1, 13}, 7, 3);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, 0);
    total++;
    printf("Sent: [13]\n");
    correct += test((int[]){13}, 1, 0);
    total++;
    printf("Sent: [13, 13]\n");
    correct += test((int[]){13, 13}, 2, 0);
    total++;
    printf("Sent: [13, 0, 13]\n");
    correct += test((int[]){13, 0, 13}, 3, 0);
    total++;
    printf("Sent: [13, 1, 13]\n");
    correct += test((int[]){13, 1, 13}, 3, 0);
    total++;
    printf("Sent: [5, 7, 2]\n");
    correct += test((int[]){5, 7, 2}, 3, 14);
    total++;
    printf("Sent: [5, 13, 2]\n");
    correct += test((int[]){5, 13, 2}, 3, 5);
    total++;
    printf("Sent: [0]\n");
    correct += test((int[]){0}, 1, 0);
    total++;
    printf("Sent: [13, 0]\n");
    correct += test((int[]){13, 0}, 2, 0);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

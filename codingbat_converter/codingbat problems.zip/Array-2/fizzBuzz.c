#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
This is slightly more difficult version of the famous FizzBuzz
problem which is sometimes given as a first problem for job
interviews. (See also: FizzBuzz Code.) Consider the series of
numbers beginning at start and running up to but not including
end, so for example start=1 and end=5 gives the series 1, 2, 3,
4. Return a new char *[] array containing the string form of
these numbers, except for multiples of 3, use "Fizz" instead of
the number, for multiples of 5 use "Buzz", and for multiples of
both 3 and 5 use "FizzBuzz". In Java, char *.valueOf(xxx) will
make the char * form of an int or other type. This version is a
little more complicated than the usual version since you have to
allocate and index into an array instead of just printing, and we
vary the start/end instead of just always doing 1..100.
*/

String[] fizzBuzz(int start, int end)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int start, int end, String[] expected)
{

}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 1, 6\n");
    correct += test(1, 6, ialloc((int[]){"1", "2", "Fizz", "4", "Buzz"}), 5);
    total++;
    printf("Sent: 1, 8\n");
    correct += test(1, 8, ialloc((int[]){"1", "2", "Fizz", "4", "Buzz", "Fizz", "7"}), 7);
    total++;
    printf("Sent: 1, 11\n");
    correct += test(1, 11, ialloc((int[]){"1", "2", "Fizz", "4", "Buzz", "Fizz", "7", "8", "Fizz", "Buzz"}), 10);
    total++;
    printf("Sent: 1, 16\n");
    correct += test(1, 16, ialloc((int[]){"1", "2", "Fizz", "4", "Buzz", "Fizz", "7", "8", "Fizz", "Buzz", "11", "Fizz", "13", "14", "FizzBuzz"}), 15);
    total++;
    printf("Sent: 1, 4\n");
    correct += test(1, 4, ialloc((int[]){"1", "2", "Fizz"}), 3);
    total++;
    printf("Sent: 1, 2\n");
    correct += test(1, 2, ialloc((int[]){"1"}), 1);
    total++;
    printf("Sent: 50, 56\n");
    correct += test(50, 56, ialloc((int[]){"Buzz", "Fizz", "52", "53", "Fizz", "Buzz"}), 6);
    total++;
    printf("Sent: 15, 17\n");
    correct += test(15, 17, ialloc((int[]){"FizzBuzz", "16"}), 2);
    total++;
    printf("Sent: 30, 36\n");
    correct += test(30, 36, ialloc((int[]){"FizzBuzz", "31", "32", "Fizz", "34", "Buzz"}), 6);
    total++;
    printf("Sent: 1000, 1006\n");
    correct += test(1000, 1006, ialloc((int[]){"Buzz", "1001", "Fizz", "1003", "1004", "FizzBuzz"}), 6);
    total++;
    printf("Sent: 99, 102\n");
    correct += test(99, 102, ialloc((int[]){"Fizz", "Buzz", "101"}), 3);
    total++;
    printf("Sent: 14, 20\n");
    correct += test(14, 20, ialloc((int[]){"14", "FizzBuzz", "16", "17", "Fizz", "19"}), 6);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

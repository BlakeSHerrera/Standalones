#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return the sum of the numbers in the array, except ignore
sections of numbers starting with a 6 and extending to the next 7
(every 6 will be followed by at least one 7). Return 0 for no
numbers.
*/

int sum67(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = sum67(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 2]\n");
    correct += test((int[]){1, 2, 2}, 3, 5);
    total++;
    printf("Sent: [1, 2, 2, 6, 99, 99, 7]\n");
    correct += test((int[]){1, 2, 2, 6, 99, 99, 7}, 7, 5);
    total++;
    printf("Sent: [1, 1, 6, 7, 2]\n");
    correct += test((int[]){1, 1, 6, 7, 2}, 5, 4);
    total++;
    printf("Sent: [1, 6, 2, 2, 7, 1, 6, 99, 99, 7]\n");
    correct += test((int[]){1, 6, 2, 2, 7, 1, 6, 99, 99, 7}, 10, 2);
    total++;
    printf("Sent: [1, 6, 2, 6, 2, 7, 1, 6, 99, 99, 7]\n");
    correct += test((int[]){1, 6, 2, 6, 2, 7, 1, 6, 99, 99, 7}, 11, 2);
    total++;
    printf("Sent: [2, 7, 6, 2, 6, 7, 2, 7]\n");
    correct += test((int[]){2, 7, 6, 2, 6, 7, 2, 7}, 8, 18);
    total++;
    printf("Sent: [2, 7, 6, 2, 6, 2, 7]\n");
    correct += test((int[]){2, 7, 6, 2, 6, 2, 7}, 7, 9);
    total++;
    printf("Sent: [1, 6, 7, 7]\n");
    correct += test((int[]){1, 6, 7, 7}, 4, 8);
    total++;
    printf("Sent: [6, 7, 1, 6, 7, 7]\n");
    correct += test((int[]){6, 7, 1, 6, 7, 7}, 6, 8);
    total++;
    printf("Sent: [6, 8, 1, 6, 7]\n");
    correct += test((int[]){6, 8, 1, 6, 7}, 5, 0);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, 0);
    total++;
    printf("Sent: [6, 7, 11]\n");
    correct += test((int[]){6, 7, 11}, 3, 11);
    total++;
    printf("Sent: [11, 6, 7, 11]\n");
    correct += test((int[]){11, 6, 7, 11}, 4, 22);
    total++;
    printf("Sent: [2, 2, 6, 7, 7]\n");
    correct += test((int[]){2, 2, 6, 7, 7}, 5, 11);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

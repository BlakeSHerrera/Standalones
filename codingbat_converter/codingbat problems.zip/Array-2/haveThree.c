#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, return TRUE if the value 3 appears in the
array exactly 3 times, and no 3's are next to each other.
*/

int haveThree(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = haveThree(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [3, 1, 3, 1, 3]\n");
    correct += test((int[]){3, 1, 3, 1, 3}, 5, TRUE);
    total++;
    printf("Sent: [3, 1, 3, 3]\n");
    correct += test((int[]){3, 1, 3, 3}, 4, FALSE);
    total++;
    printf("Sent: [3, 4, 3, 3, 4]\n");
    correct += test((int[]){3, 4, 3, 3, 4}, 5, FALSE);
    total++;
    printf("Sent: [1, 3, 1, 3, 1, 2]\n");
    correct += test((int[]){1, 3, 1, 3, 1, 2}, 6, FALSE);
    total++;
    printf("Sent: [1, 3, 1, 3, 1, 3]\n");
    correct += test((int[]){1, 3, 1, 3, 1, 3}, 6, TRUE);
    total++;
    printf("Sent: [1, 3, 3, 1, 3]\n");
    correct += test((int[]){1, 3, 3, 1, 3}, 5, FALSE);
    total++;
    printf("Sent: [1, 3, 1, 3, 1, 3, 4, 3]\n");
    correct += test((int[]){1, 3, 1, 3, 1, 3, 4, 3}, 8, FALSE);
    total++;
    printf("Sent: [3, 4, 3, 4, 3, 4, 4]\n");
    correct += test((int[]){3, 4, 3, 4, 3, 4, 4}, 7, TRUE);
    total++;
    printf("Sent: [3, 3, 3]\n");
    correct += test((int[]){3, 3, 3}, 3, FALSE);
    total++;
    printf("Sent: [1, 3]\n");
    correct += test((int[]){1, 3}, 2, FALSE);
    total++;
    printf("Sent: [3]\n");
    correct += test((int[]){3}, 1, FALSE);
    total++;
    printf("Sent: [1]\n");
    correct += test((int[]){1}, 1, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

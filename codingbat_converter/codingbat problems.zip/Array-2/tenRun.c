#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
For each multiple of 10 in the given array, change all the values
following it to be that multiple of 10, until encountering
another multiple of 10. So {2, 10, 3, 4, 20, 5} yields {2, 10,
10, 10, 20, 20}.
*/

int * tenRun(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int * expected, int expectedSize)
{
    int * returned = tenRun(nums, numsSize);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [2, 10, 3, 4, 20, 5]\n");
    correct += test((int[]){2, 10, 3, 4, 20, 5}, 6, ialloc((int[]){2, 10, 10, 10, 20, 20}), 6);
    total++;
    printf("Sent: [10, 1, 20, 2]\n");
    correct += test((int[]){10, 1, 20, 2}, 4, ialloc((int[]){10, 10, 20, 20}), 4);
    total++;
    printf("Sent: [10, 1, 9, 20]\n");
    correct += test((int[]){10, 1, 9, 20}, 4, ialloc((int[]){10, 10, 10, 20}), 4);
    total++;
    printf("Sent: [1, 2, 50, 1]\n");
    correct += test((int[]){1, 2, 50, 1}, 4, ialloc((int[]){1, 2, 50, 50}), 4);
    total++;
    printf("Sent: [1, 20, 50, 1]\n");
    correct += test((int[]){1, 20, 50, 1}, 4, ialloc((int[]){1, 20, 50, 50}), 4);
    total++;
    printf("Sent: [10, 10]\n");
    correct += test((int[]){10, 10}, 2, ialloc((int[]){10, 10}), 2);
    total++;
    printf("Sent: [10, 2]\n");
    correct += test((int[]){10, 2}, 2, ialloc((int[]){10, 10}), 2);
    total++;
    printf("Sent: [0, 2]\n");
    correct += test((int[]){0, 2}, 2, ialloc((int[]){0, 0}), 2);
    total++;
    printf("Sent: [1, 2]\n");
    correct += test((int[]){1, 2}, 2, ialloc((int[]){1, 2}), 2);
    total++;
    printf("Sent: [1]\n");
    correct += test((int[]){1}, 1, ialloc((int[]){1}), 1);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, ialloc((int[]){}), 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

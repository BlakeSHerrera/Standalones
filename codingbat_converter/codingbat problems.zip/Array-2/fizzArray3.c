#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given start and end numbers, return a new array containing the
sequence of integers from start up to but not including end, so
start=5 and end=10 yields {5, 6, 7, 8, 9}. The end number will be
greater or equal to the start number. Note that a length-0 array
is valid. (See also: FizzBuzz Code)
*/

int * fizzArray3(int start, int end)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int start, int end, int * expected, int expectedSize)
{
    int * returned = fizzArray3(start, end);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 5, 10\n");
    correct += test(5, 10, ialloc((int[]){5, 6, 7, 8, 9}), 5);
    total++;
    printf("Sent: 11, 18\n");
    correct += test(11, 18, ialloc((int[]){11, 12, 13, 14, 15, 16, 17}), 7);
    total++;
    printf("Sent: 1, 3\n");
    correct += test(1, 3, ialloc((int[]){1, 2}), 2);
    total++;
    printf("Sent: 1, 2\n");
    correct += test(1, 2, ialloc((int[]){1}), 1);
    total++;
    printf("Sent: 1, 1\n");
    correct += test(1, 1, ialloc((int[]){}), 1);
    total++;
    printf("Sent: 1000, 1005\n");
    correct += test(1000, 1005, ialloc((int[]){1000, 1001, 1002, 1003, 1004}), 5);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

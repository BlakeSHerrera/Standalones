#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return TRUE if the group of N numbers at the start and end of the
array are the same. For example, with {5, 6, 45, 99, 13, 5, 6},
the ends are the same for n=0 and n=2, and FALSE for n=1 and n=3.
You may assume that n is in the range 0..nums.length inclusive.
*/

int sameEnds(int nums[], int numsSize, int len)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int len, int expected)
{
    int returned = sameEnds(nums, numsSize, len);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [5, 6, 45, 99, 13, 5, 6], 1\n");
    correct += test((int[]){5, 6, 45, 99, 13, 5, 6}, 7, 1, FALSE);
    total++;
    printf("Sent: [5, 6, 45, 99, 13, 5, 6], 2\n");
    correct += test((int[]){5, 6, 45, 99, 13, 5, 6}, 7, 2, TRUE);
    total++;
    printf("Sent: [5, 6, 45, 99, 13, 5, 6], 3\n");
    correct += test((int[]){5, 6, 45, 99, 13, 5, 6}, 7, 3, FALSE);
    total++;
    printf("Sent: [1, 2, 5, 2, 1], 1\n");
    correct += test((int[]){1, 2, 5, 2, 1}, 5, 1, TRUE);
    total++;
    printf("Sent: [1, 2, 5, 2, 1], 2\n");
    correct += test((int[]){1, 2, 5, 2, 1}, 5, 2, FALSE);
    total++;
    printf("Sent: [1, 2, 5, 2, 1], 0\n");
    correct += test((int[]){1, 2, 5, 2, 1}, 5, 0, TRUE);
    total++;
    printf("Sent: [1, 2, 5, 2, 1], 5\n");
    correct += test((int[]){1, 2, 5, 2, 1}, 5, 5, TRUE);
    total++;
    printf("Sent: [1, 1, 1], 0\n");
    correct += test((int[]){1, 1, 1}, 3, 0, TRUE);
    total++;
    printf("Sent: [1, 1, 1], 1\n");
    correct += test((int[]){1, 1, 1}, 3, 1, TRUE);
    total++;
    printf("Sent: [1, 1, 1], 2\n");
    correct += test((int[]){1, 1, 1}, 3, 2, TRUE);
    total++;
    printf("Sent: [1, 1, 1], 3\n");
    correct += test((int[]){1, 1, 1}, 3, 3, TRUE);
    total++;
    printf("Sent: [1], 1\n");
    correct += test((int[]){1}, 1, 1, TRUE);
    total++;
    printf("Sent: [], 0\n");
    correct += test((int[]){}, 1, 0, TRUE);
    total++;
    printf("Sent: [4, 2, 4, 5], 1\n");
    correct += test((int[]){4, 2, 4, 5}, 4, 1, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

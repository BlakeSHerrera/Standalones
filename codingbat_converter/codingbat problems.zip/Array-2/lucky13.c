#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, return TRUE if the array contains no 1's
and no 3's.
*/

int lucky13(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = lucky13(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [0, 2, 4]\n");
    correct += test((int[]){0, 2, 4}, 3, TRUE);
    total++;
    printf("Sent: [1, 2, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, FALSE);
    total++;
    printf("Sent: [1, 2, 4]\n");
    correct += test((int[]){1, 2, 4}, 3, FALSE);
    total++;
    printf("Sent: [2, 7, 2, 8]\n");
    correct += test((int[]){2, 7, 2, 8}, 4, TRUE);
    total++;
    printf("Sent: [2, 7, 1, 8]\n");
    correct += test((int[]){2, 7, 1, 8}, 4, FALSE);
    total++;
    printf("Sent: [3, 7, 2, 8]\n");
    correct += test((int[]){3, 7, 2, 8}, 4, FALSE);
    total++;
    printf("Sent: [2, 7, 2, 1]\n");
    correct += test((int[]){2, 7, 2, 1}, 4, FALSE);
    total++;
    printf("Sent: [1, 2]\n");
    correct += test((int[]){1, 2}, 2, FALSE);
    total++;
    printf("Sent: [2, 2]\n");
    correct += test((int[]){2, 2}, 2, TRUE);
    total++;
    printf("Sent: [2]\n");
    correct += test((int[]){2}, 1, TRUE);
    total++;
    printf("Sent: [3]\n");
    correct += test((int[]){3}, 1, FALSE);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given arrays nums1 and nums2 of the same length, for every
element in nums1, consider the corresponding element in nums2 (at
the same index). Return the count of the number of times that the
two elements differ by 2 or less, but are not equal.
*/

int matchUp(int nums1[], int nums1Size, int nums2[], int nums2Size)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums1[], int nums1Size, int nums2[], int nums2Size, int expected)
{
    int returned = matchUp(nums1, nums1Size, nums2, nums2Size);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3], [2, 3, 10]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){2, 3, 10}, 3, 2);
    total++;
    printf("Sent: [1, 2, 3], [2, 3, 5]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){2, 3, 5}, 3, 3);
    total++;
    printf("Sent: [1, 2, 3], [2, 3, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){2, 3, 3}, 3, 2);
    total++;
    printf("Sent: [5, 3], [5, 5]\n");
    correct += test((int[]){5, 3}, 2, (int[]){5, 5}, 2, 1);
    total++;
    printf("Sent: [5, 3], [4, 4]\n");
    correct += test((int[]){5, 3}, 2, (int[]){4, 4}, 2, 2);
    total++;
    printf("Sent: [5, 3], [3, 3]\n");
    correct += test((int[]){5, 3}, 2, (int[]){3, 3}, 2, 1);
    total++;
    printf("Sent: [5, 3], [2, 2]\n");
    correct += test((int[]){5, 3}, 2, (int[]){2, 2}, 2, 1);
    total++;
    printf("Sent: [5, 3], [1, 1]\n");
    correct += test((int[]){5, 3}, 2, (int[]){1, 1}, 2, 1);
    total++;
    printf("Sent: [5, 3], [0, 0]\n");
    correct += test((int[]){5, 3}, 2, (int[]){0, 0}, 2, 0);
    total++;
    printf("Sent: [4], [4]\n");
    correct += test((int[]){4}, 1, (int[]){4}, 1, 0);
    total++;
    printf("Sent: [4], [5]\n");
    correct += test((int[]){4}, 1, (int[]){5}, 1, 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return the "centered" average of an array of ints, which we'll
say is the mean average of the values, except ignoring the
largest and smallest values in the array. If there are multiple
copies of the smallest value, ignore just one copy, and likewise
for the largest value. Use int division to produce the final
average. You may assume that the array is length 3 or more.
*/

int centeredAverage(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = centeredAverage(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3, 4, 100]\n");
    correct += test((int[]){1, 2, 3, 4, 100}, 5, 3);
    total++;
    printf("Sent: [1, 1, 5, 5, 10, 8, 7]\n");
    correct += test((int[]){1, 1, 5, 5, 10, 8, 7}, 7, 5);
    total++;
    printf("Sent: [-10, -4, -2, -4, -2, 0]\n");
    correct += test((int[]){-10, -4, -2, -4, -2, 0}, 6, -3);
    total++;
    printf("Sent: [5, 3, 4, 6, 2]\n");
    correct += test((int[]){5, 3, 4, 6, 2}, 5, 4);
    total++;
    printf("Sent: [5, 3, 4, 0, 100]\n");
    correct += test((int[]){5, 3, 4, 0, 100}, 5, 4);
    total++;
    printf("Sent: [100, 0, 5, 3, 4]\n");
    correct += test((int[]){100, 0, 5, 3, 4}, 5, 4);
    total++;
    printf("Sent: [4, 0, 100]\n");
    correct += test((int[]){4, 0, 100}, 3, 4);
    total++;
    printf("Sent: [0, 2, 3, 4, 100]\n");
    correct += test((int[]){0, 2, 3, 4, 100}, 5, 3);
    total++;
    printf("Sent: [1, 1, 100]\n");
    correct += test((int[]){1, 1, 100}, 3, 1);
    total++;
    printf("Sent: [7, 7, 7]\n");
    correct += test((int[]){7, 7, 7}, 3, 7);
    total++;
    printf("Sent: [1, 7, 8]\n");
    correct += test((int[]){1, 7, 8}, 3, 7);
    total++;
    printf("Sent: [1, 1, 99, 99]\n");
    correct += test((int[]){1, 1, 99, 99}, 4, 50);
    total++;
    printf("Sent: [1000, 0, 1, 99]\n");
    correct += test((int[]){1000, 0, 1, 99}, 4, 50);
    total++;
    printf("Sent: [4, 4, 4, 4, 5]\n");
    correct += test((int[]){4, 4, 4, 4, 5}, 5, 4);
    total++;
    printf("Sent: [4, 4, 4, 1, 5]\n");
    correct += test((int[]){4, 4, 4, 1, 5}, 5, 4);
    total++;
    printf("Sent: [6, 4, 8, 12, 3]\n");
    correct += test((int[]){6, 4, 8, 12, 3}, 5, 6);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a number n, create and return a new int array of length n,
containing the numbers 0, 1, 2, ... n-1. The given n may be 0, in
which case just return a length 0 array. You do not need a
separate if-statement for the length-0 case; the for-loop should
naturally execute 0 times in that case, so it just works. The
syntax to make a new int array is: new int[desired_length]  �
(See also: FizzBuzz Code)
*/

int * fizzArray(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int * expected, int expectedSize)
{
    int * returned = fizzArray(n);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 4\n");
    correct += test(4, ialloc((int[]){0, 1, 2, 3}), 4);
    total++;
    printf("Sent: 1\n");
    correct += test(1, ialloc((int[]){0}), 1);
    total++;
    printf("Sent: 10\n");
    correct += test(10, ialloc((int[]){0, 1, 2, 3, 4, 5, 6, 7, 8, 9}), 10);
    total++;
    printf("Sent: 0\n");
    correct += test(0, ialloc((int[]){}), 1);
    total++;
    printf("Sent: 2\n");
    correct += test(2, ialloc((int[]){0, 1}), 2);
    total++;
    printf("Sent: 7\n");
    correct += test(7, ialloc((int[]){0, 1, 2, 3, 4, 5, 6}), 7);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

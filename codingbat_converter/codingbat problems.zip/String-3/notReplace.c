#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return a string where every appearance of the
lowercase word "is" has been replaced with "is not". The word
"is" should not be immediately preceeded or followed by a letter
-- so for example the "is" in "this" does not count. (Note:
Character.isLetter(char) tests if a char is a letter.)
*/

char * notReplace(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, char * expected)
{
    char * returned = notReplace(str);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"is test\"\n");
    correct += test("is test", "is not test");
    total++;
    printf("Sent: \"is-is\"\n");
    correct += test("is-is", "is not-is not");
    total++;
    printf("Sent: \"This is right\"\n");
    correct += test("This is right", "This is not right");
    total++;
    printf("Sent: \"This is isabell\"\n");
    correct += test("This is isabell", "This is not isabell");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"is\"\n");
    correct += test("is", "is not");
    total++;
    printf("Sent: \"isis\"\n");
    correct += test("isis", "isis");
    total++;
    printf("Sent: \"Dis is bliss is\"\n");
    correct += test("Dis is bliss is", "Dis is not bliss is not");
    total++;
    printf("Sent: \"is his\"\n");
    correct += test("is his", "is not his");
    total++;
    printf("Sent: \"xis yis\"\n");
    correct += test("xis yis", "xis yis");
    total++;
    printf("Sent: \"AAAis is\"\n");
    correct += test("AAAis is", "AAAis is not");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

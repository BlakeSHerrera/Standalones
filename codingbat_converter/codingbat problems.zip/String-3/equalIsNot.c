#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return TRUE if the number of appearances of "is"
anywhere in the string is equal to the number of appearances of
"not" anywhere in the string (case sensitive).
*/

int equalIsNot(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = equalIsNot(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"This is not\"\n");
    correct += test("This is not", FALSE);
    total++;
    printf("Sent: \"This is notnot\"\n");
    correct += test("This is notnot", TRUE);
    total++;
    printf("Sent: \"noisxxnotyynotxisi\"\n");
    correct += test("noisxxnotyynotxisi", TRUE);
    total++;
    printf("Sent: \"noisxxnotyynotxsi\"\n");
    correct += test("noisxxnotyynotxsi", FALSE);
    total++;
    printf("Sent: \"xxxyyyzzzintint\"\n");
    correct += test("xxxyyyzzzintint", TRUE);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", TRUE);
    total++;
    printf("Sent: \"isisnotnot\"\n");
    correct += test("isisnotnot", TRUE);
    total++;
    printf("Sent: \"isisnotno7Not\"\n");
    correct += test("isisnotno7Not", FALSE);
    total++;
    printf("Sent: \"isnotis\"\n");
    correct += test("isnotis", FALSE);
    total++;
    printf("Sent: \"mis3notpotbotis\"\n");
    correct += test("mis3notpotbotis", FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We'll say that a "triple" in a string is a char appearing three
times in a row. Return the number of triples in the given string.
The triples may overlap.
*/

int countTriple(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = countTriple(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"abcXXXabc\"\n");
    correct += test("abcXXXabc", 1);
    total++;
    printf("Sent: \"xxxabyyyycd\"\n");
    correct += test("xxxabyyyycd", 3);
    total++;
    printf("Sent: \"a\"\n");
    correct += test("a", 0);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", 0);
    total++;
    printf("Sent: \"XXXabc\"\n");
    correct += test("XXXabc", 1);
    total++;
    printf("Sent: \"XXXXabc\"\n");
    correct += test("XXXXabc", 2);
    total++;
    printf("Sent: \"XXXXXabc\"\n");
    correct += test("XXXXXabc", 3);
    total++;
    printf("Sent: \"222abyyycdXXX\"\n");
    correct += test("222abyyycdXXX", 3);
    total++;
    printf("Sent: \"abYYYabXXXXXab\"\n");
    correct += test("abYYYabXXXXXab", 4);
    total++;
    printf("Sent: \"abYYXabXXYXXab\"\n");
    correct += test("abYYXabXXYXXab", 0);
    total++;
    printf("Sent: \"abYYXabXXYXXab\"\n");
    correct += test("abYYXabXXYXXab", 0);
    total++;
    printf("Sent: \"122abhhh2\"\n");
    correct += test("122abhhh2", 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return the length of the largest "block" in the
string. A block is a run of adjacent chars that are the same.
*/

int maxBlock(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = maxBlock(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"hoopla\"\n");
    correct += test("hoopla", 2);
    total++;
    printf("Sent: \"abbCCCddBBBxx\"\n");
    correct += test("abbCCCddBBBxx", 3);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", 0);
    total++;
    printf("Sent: \"xyz\"\n");
    correct += test("xyz", 1);
    total++;
    printf("Sent: \"xxyz\"\n");
    correct += test("xxyz", 2);
    total++;
    printf("Sent: \"xyzz\"\n");
    correct += test("xyzz", 2);
    total++;
    printf("Sent: \"abbbcbbbxbbbx\"\n");
    correct += test("abbbcbbbxbbbx", 3);
    total++;
    printf("Sent: \"XXBBBbbxx\"\n");
    correct += test("XXBBBbbxx", 3);
    total++;
    printf("Sent: \"XXBBBBbbxx\"\n");
    correct += test("XXBBBBbbxx", 4);
    total++;
    printf("Sent: \"XXBBBbbxxXXXX\"\n");
    correct += test("XXBBBbbxxXXXX", 4);
    total++;
    printf("Sent: \"XX2222BBBbbXX2222\"\n");
    correct += test("XX2222BBBbbXX2222", 4);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

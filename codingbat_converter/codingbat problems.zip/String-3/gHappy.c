#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We'll say that a lowercase 'g' in a string is "happy" if there is
another 'g' immediately to its left or right. Return TRUE if all
the g's in the given string are happy.
*/

int gHappy(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = gHappy(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"xxggxx\"\n");
    correct += test("xxggxx", TRUE);
    total++;
    printf("Sent: \"xxgxx\"\n");
    correct += test("xxgxx", FALSE);
    total++;
    printf("Sent: \"xxggyygxx\"\n");
    correct += test("xxggyygxx", FALSE);
    total++;
    printf("Sent: \"g\"\n");
    correct += test("g", FALSE);
    total++;
    printf("Sent: \"gg\"\n");
    correct += test("gg", TRUE);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", TRUE);
    total++;
    printf("Sent: \"xxgggxyz\"\n");
    correct += test("xxgggxyz", TRUE);
    total++;
    printf("Sent: \"xxgggxyg\"\n");
    correct += test("xxgggxyg", FALSE);
    total++;
    printf("Sent: \"xxgggxygg\"\n");
    correct += test("xxgggxygg", TRUE);
    total++;
    printf("Sent: \"mgm\"\n");
    correct += test("mgm", FALSE);
    total++;
    printf("Sent: \"mggm\"\n");
    correct += test("mggm", TRUE);
    total++;
    printf("Sent: \"yyygggxyy\"\n");
    correct += test("yyygggxyy", TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

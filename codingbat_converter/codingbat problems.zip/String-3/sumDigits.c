#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return the sum of the digits 0-9 that appear in
the string, ignoring all other characters. Return 0 if there are
no digits in the string. (Note: Character.isDigit(char) tests if
a char is one of the chars '0', '1', .. '9'.
Integer.parseInt(string) converts a string to an int.)
*/

int sumDigits(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = sumDigits(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"aa1bc2d3\"\n");
    correct += test("aa1bc2d3", 6);
    total++;
    printf("Sent: \"aa11b33\"\n");
    correct += test("aa11b33", 8);
    total++;
    printf("Sent: \"Chocolate\"\n");
    correct += test("Chocolate", 0);
    total++;
    printf("Sent: \"5hoco1a1e\"\n");
    correct += test("5hoco1a1e", 7);
    total++;
    printf("Sent: \"123abc123\"\n");
    correct += test("123abc123", 12);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", 0);
    total++;
    printf("Sent: \"Hello\"\n");
    correct += test("Hello", 0);
    total++;
    printf("Sent: \"X1z9b2\"\n");
    correct += test("X1z9b2", 12);
    total++;
    printf("Sent: \"5432a\"\n");
    correct += test("5432a", 14);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

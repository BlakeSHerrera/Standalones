#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return the longest substring that appears at both
the beginning and end of the string without overlapping. For
example, sameEnds("abXab") is "ab".
*/

char * sameEnds(char * string)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * string, char * expected)
{
    char * returned = sameEnds(string);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"abXYab\"\n");
    correct += test("abXYab", "ab");
    total++;
    printf("Sent: \"xx\"\n");
    correct += test("xx", "x");
    total++;
    printf("Sent: \"xxx\"\n");
    correct += test("xxx", "x");
    total++;
    printf("Sent: \"xxxx\"\n");
    correct += test("xxxx", "xx");
    total++;
    printf("Sent: \"javaXYZjava\"\n");
    correct += test("javaXYZjava", "java");
    total++;
    printf("Sent: \"javajava\"\n");
    correct += test("javajava", "java");
    total++;
    printf("Sent: \"xavaXYZjava\"\n");
    correct += test("xavaXYZjava", "");
    total++;
    printf("Sent: \"Hello! and Hello!\"\n");
    correct += test("Hello! and Hello!", "Hello!");
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", "");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"abcb\"\n");
    correct += test("abcb", "");
    total++;
    printf("Sent: \"mymmy\"\n");
    correct += test("mymmy", "my");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given two strings, base and remove, return a version of the base
string where all instances of the remove string have been removed
(not case sensitive). You may assume that the remove string is
length 1 or more. Remove only non-overlapping instances, so with
"xxx" removing "xx" leaves "x".
*/

char * withoutString(char * base, char * remove)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * base, char * remove, char * expected)
{
    char * returned = withoutString(base, remove);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"Hello there\", \"llo\"\n");
    correct += test("Hello there", "llo", "He there");
    total++;
    printf("Sent: \"Hello there\", \"e\"\n");
    correct += test("Hello there", "e", "Hllo thr");
    total++;
    printf("Sent: \"Hello there\", \"x\"\n");
    correct += test("Hello there", "x", "Hello there");
    total++;
    printf("Sent: \"This is a FISH\", \"IS\"\n");
    correct += test("This is a FISH", "IS", "Th  a FH");
    total++;
    printf("Sent: \"THIS is a FISH\", \"is\"\n");
    correct += test("THIS is a FISH", "is", "TH  a FH");
    total++;
    printf("Sent: \"THIS is a FISH\", \"iS\"\n");
    correct += test("THIS is a FISH", "iS", "TH  a FH");
    total++;
    printf("Sent: \"abxxxxab\", \"xx\"\n");
    correct += test("abxxxxab", "xx", "abab");
    total++;
    printf("Sent: \"abxxxab\", \"xx\"\n");
    correct += test("abxxxab", "xx", "abxab");
    total++;
    printf("Sent: \"abxxxab\", \"x\"\n");
    correct += test("abxxxab", "x", "abab");
    total++;
    printf("Sent: \"xxx\", \"x\"\n");
    correct += test("xxx", "x", "");
    total++;
    printf("Sent: \"xxx\", \"xx\"\n");
    correct += test("xxx", "xx", "x");
    total++;
    printf("Sent: \"xyzzy\", \"Y\"\n");
    correct += test("xyzzy", "Y", "xzz");
    total++;
    printf("Sent: \"\", \"x\"\n");
    correct += test("", "x", "");
    total++;
    printf("Sent: \"abcabc\", \"b\"\n");
    correct += test("abcabc", "b", "acac");
    total++;
    printf("Sent: \"AA22bb\", \"2\"\n");
    correct += test("AA22bb", "2", "AAbb");
    total++;
    printf("Sent: \"1111\", \"1\"\n");
    correct += test("1111", "1", "");
    total++;
    printf("Sent: \"1111\", \"11\"\n");
    correct += test("1111", "11", "");
    total++;
    printf("Sent: \"MkjtMkx\", \"Mk\"\n");
    correct += test("MkjtMkx", "Mk", "jtx");
    total++;
    printf("Sent: \"Hi HoHo\", \"Ho\"\n");
    correct += test("Hi HoHo", "Ho", "Hi ");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, return the sum of the numbers appearing in the
string, ignoring all other characters. A number is a series of 1
or more digit chars in a row. (Note: Character.isDigit(char)
tests if a char is one of the chars '0', '1', .. '9'.
Integer.parseInt(string) converts a string to an int.)
*/

int sumNumbers(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = sumNumbers(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"abc123xyz\"\n");
    correct += test("abc123xyz", 123);
    total++;
    printf("Sent: \"aa11b33\"\n");
    correct += test("aa11b33", 44);
    total++;
    printf("Sent: \"7 11\"\n");
    correct += test("7 11", 18);
    total++;
    printf("Sent: \"Chocolate\"\n");
    correct += test("Chocolate", 0);
    total++;
    printf("Sent: \"5hoco1a1e\"\n");
    correct += test("5hoco1a1e", 7);
    total++;
    printf("Sent: \"5$$1;;1!!\"\n");
    correct += test("5$$1;;1!!", 7);
    total++;
    printf("Sent: \"a1234bb11\"\n");
    correct += test("a1234bb11", 1245);
    total++;
    printf("Sent: \"\"\n");
    correct += test("", 0);
    total++;
    printf("Sent: \"a22bbb3\"\n");
    correct += test("a22bbb3", 25);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

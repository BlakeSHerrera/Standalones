#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, count the number of words ending in 'y' or 'z' --
so the 'y' in "heavy" and the 'z' in "fez" count, but not the 'y'
in "yellow" (not case sensitive). We'll say that a y or z is at
the end of a word if there is not an alphabetic letter
immediately following it. (Note: Character.isLetter(char) tests
if a char is an alphabetic letter.)
*/

int countYZ(char * str)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * str, int expected)
{
    int returned = countYZ(str);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"fez day\"\n");
    correct += test("fez day", 2);
    total++;
    printf("Sent: \"day fez\"\n");
    correct += test("day fez", 2);
    total++;
    printf("Sent: \"day fyyyz\"\n");
    correct += test("day fyyyz", 2);
    total++;
    printf("Sent: \"day yak\"\n");
    correct += test("day yak", 1);
    total++;
    printf("Sent: \"day:yak\"\n");
    correct += test("day:yak", 1);
    total++;
    printf("Sent: \"!!day--yaz!!\"\n");
    correct += test("!!day--yaz!!", 2);
    total++;
    printf("Sent: \"yak zak\"\n");
    correct += test("yak zak", 0);
    total++;
    printf("Sent: \"DAY abc XYZ\"\n");
    correct += test("DAY abc XYZ", 2);
    total++;
    printf("Sent: \"aaz yyz my\"\n");
    correct += test("aaz yyz my", 3);
    total++;
    printf("Sent: \"y2bz\"\n");
    correct += test("y2bz", 2);
    total++;
    printf("Sent: \"zxyx\"\n");
    correct += test("zxyx", 0);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

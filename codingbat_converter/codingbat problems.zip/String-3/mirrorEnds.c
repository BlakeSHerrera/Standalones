#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given a string, look for a mirror image (backwards) string at
both the beginning and end of the given string. In other words,
zero or more characters at the very begining of the given string,
and at the very end of the string in reverse order (possibly
overlapping). For example, the string "abXYZba" has the mirror
end "ab".
*/

char * mirrorEnds(char * string)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(char * string, char * expected)
{
    char * returned = mirrorEnds(string);
    printf("%s Expected\n", expected);
    printf("%s Returned\n\n", returned);
    int res = strcmp(expected, returned) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: \"abXYZba\"\n");
    correct += test("abXYZba", "ab");
    total++;
    printf("Sent: \"abca\"\n");
    correct += test("abca", "a");
    total++;
    printf("Sent: \"aba\"\n");
    correct += test("aba", "aba");
    total++;
    printf("Sent: \"abab\"\n");
    correct += test("abab", "");
    total++;
    printf("Sent: \"xxx\"\n");
    correct += test("xxx", "xxx");
    total++;
    printf("Sent: \"xxYxx\"\n");
    correct += test("xxYxx", "xxYxx");
    total++;
    printf("Sent: \"Hi and iH\"\n");
    correct += test("Hi and iH", "Hi ");
    total++;
    printf("Sent: \"x\"\n");
    correct += test("x", "x");
    total++;
    printf("Sent: \"\"\n");
    correct += test("", "");
    total++;
    printf("Sent: \"123and then 321\"\n");
    correct += test("123and then 321", "123");
    total++;
    printf("Sent: \"band andab\"\n");
    correct += test("band andab", "ba");
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

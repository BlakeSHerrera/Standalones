#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given two arrays of ints sorted in increasing order, outer and
inner, return TRUE if all of the numbers in inner appear in
outer. The best solution makes only a single "linear" pass of
both arrays, taking advantage of the fact that both arrays are
already in sorted order.
*/

int linearIn(int outer[], int outerSize, int inner[], int innerSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int outer[], int outerSize, int inner[], int innerSize, int expected)
{
    int returned = linearIn(outer, outerSize, inner, innerSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 4, 6], [2, 4]\n");
    correct += test((int[]){1, 2, 4, 6}, 4, (int[]){2, 4}, 2, TRUE);
    total++;
    printf("Sent: [1, 2, 4, 6], [2, 3, 4]\n");
    correct += test((int[]){1, 2, 4, 6}, 4, (int[]){2, 3, 4}, 3, FALSE);
    total++;
    printf("Sent: [1, 2, 4, 4, 6], [2, 4]\n");
    correct += test((int[]){1, 2, 4, 4, 6}, 5, (int[]){2, 4}, 2, TRUE);
    total++;
    printf("Sent: [2, 2, 4, 4, 6, 6], [2, 4]\n");
    correct += test((int[]){2, 2, 4, 4, 6, 6}, 6, (int[]){2, 4}, 2, TRUE);
    total++;
    printf("Sent: [2, 2, 2, 2, 2], [2, 2]\n");
    correct += test((int[]){2, 2, 2, 2, 2}, 5, (int[]){2, 2}, 2, TRUE);
    total++;
    printf("Sent: [2, 2, 2, 2, 2], [2, 4]\n");
    correct += test((int[]){2, 2, 2, 2, 2}, 5, (int[]){2, 4}, 2, FALSE);
    total++;
    printf("Sent: [2, 2, 2, 2, 4], [2, 4]\n");
    correct += test((int[]){2, 2, 2, 2, 4}, 5, (int[]){2, 4}, 2, TRUE);
    total++;
    printf("Sent: [1, 2, 3], [2]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){2}, 1, TRUE);
    total++;
    printf("Sent: [1, 2, 3], [-1]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){-1}, 1, FALSE);
    total++;
    printf("Sent: [1, 2, 3], []\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){}, 1, TRUE);
    total++;
    printf("Sent: [-1, 0, 3, 3, 3, 10, 12], [-1, 0, 3, 12]\n");
    correct += test((int[]){-1, 0, 3, 3, 3, 10, 12}, 7, (int[]){-1, 0, 3, 12}, 4, TRUE);
    total++;
    printf("Sent: [-1, 0, 3, 3, 3, 10, 12], [0, 3, 12, 14]\n");
    correct += test((int[]){-1, 0, 3, 3, 3, 10, 12}, 7, (int[]){0, 3, 12, 14}, 4, FALSE);
    total++;
    printf("Sent: [-1, 0, 3, 3, 3, 10, 12], [-1, 10, 11]\n");
    correct += test((int[]){-1, 0, 3, 3, 3, 10, 12}, 7, (int[]){-1, 10, 11}, 3, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

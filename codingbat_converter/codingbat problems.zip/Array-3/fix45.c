#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
(This is a slightly harder version of the fix34 problem.) Return
an array that contains exactly the same numbers as the given
array, but rearranged so that every 4 is immediately followed by
a 5. Do not move the 4's, but every other number may move. The
array contains the same number of 4's and 5's, and every 4 has a
number after it that is not a 4. In this version, 5's may appear
anywhere in the original array.
*/

int * fix45(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int * expected, int expectedSize)
{
    int * returned = fix45(nums, numsSize);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [5, 4, 9, 4, 9, 5]\n");
    correct += test((int[]){5, 4, 9, 4, 9, 5}, 6, ialloc((int[]){9, 4, 5, 4, 5, 9}), 6);
    total++;
    printf("Sent: [1, 4, 1, 5]\n");
    correct += test((int[]){1, 4, 1, 5}, 4, ialloc((int[]){1, 4, 5, 1}), 4);
    total++;
    printf("Sent: [1, 4, 1, 5, 5, 4, 1]\n");
    correct += test((int[]){1, 4, 1, 5, 5, 4, 1}, 7, ialloc((int[]){1, 4, 5, 1, 1, 4, 5}), 7);
    total++;
    printf("Sent: [4, 9, 4, 9, 5, 5, 4, 9, 5]\n");
    correct += test((int[]){4, 9, 4, 9, 5, 5, 4, 9, 5}, 9, ialloc((int[]){4, 5, 4, 5, 9, 9, 4, 5, 9}), 9);
    total++;
    printf("Sent: [5, 5, 4, 1, 4, 1]\n");
    correct += test((int[]){5, 5, 4, 1, 4, 1}, 6, ialloc((int[]){1, 1, 4, 5, 4, 5}), 6);
    total++;
    printf("Sent: [4, 2, 2, 5]\n");
    correct += test((int[]){4, 2, 2, 5}, 4, ialloc((int[]){4, 5, 2, 2}), 4);
    total++;
    printf("Sent: [4, 2, 4, 2, 5, 5]\n");
    correct += test((int[]){4, 2, 4, 2, 5, 5}, 6, ialloc((int[]){4, 5, 4, 5, 2, 2}), 6);
    total++;
    printf("Sent: [4, 2, 4, 5, 5]\n");
    correct += test((int[]){4, 2, 4, 5, 5}, 5, ialloc((int[]){4, 5, 4, 5, 2}), 5);
    total++;
    printf("Sent: [1, 1, 1]\n");
    correct += test((int[]){1, 1, 1}, 3, ialloc((int[]){1, 1, 1}), 3);
    total++;
    printf("Sent: [4, 5]\n");
    correct += test((int[]){4, 5}, 2, ialloc((int[]){4, 5}), 2);
    total++;
    printf("Sent: [5, 4, 1]\n");
    correct += test((int[]){5, 4, 1}, 3, ialloc((int[]){1, 4, 5}), 3);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, ialloc((int[]){}), 1);
    total++;
    printf("Sent: [5, 4, 5, 4, 1]\n");
    correct += test((int[]){5, 4, 5, 4, 1}, 5, ialloc((int[]){1, 4, 5, 4, 5}), 5);
    total++;
    printf("Sent: [4, 5, 4, 1, 5]\n");
    correct += test((int[]){4, 5, 4, 1, 5}, 5, ialloc((int[]){4, 5, 4, 5, 1}), 5);
    total++;
    printf("Sent: [3, 4, 5]\n");
    correct += test((int[]){3, 4, 5}, 3, ialloc((int[]){3, 4, 5}), 3);
    total++;
    printf("Sent: [4, 1, 5]\n");
    correct += test((int[]){4, 1, 5}, 3, ialloc((int[]){4, 5, 1}), 3);
    total++;
    printf("Sent: [5, 4, 1]\n");
    correct += test((int[]){5, 4, 1}, 3, ialloc((int[]){1, 4, 5}), 3);
    total++;
    printf("Sent: [2, 4, 2, 5]\n");
    correct += test((int[]){2, 4, 2, 5}, 4, ialloc((int[]){2, 4, 5, 2}), 4);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

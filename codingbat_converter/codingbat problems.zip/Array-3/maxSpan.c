#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Consider the leftmost and righmost appearances of some value in
an array. We'll say that the "span" is the number of elements
between the two inclusive. A single value has a span of 1.
Returns the largest span found in the given array. (Efficiency is
not a priority.)
*/

int maxSpan(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = maxSpan(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 1, 1, 3]\n");
    correct += test((int[]){1, 2, 1, 1, 3}, 5, 4);
    total++;
    printf("Sent: [1, 4, 2, 1, 4, 1, 4]\n");
    correct += test((int[]){1, 4, 2, 1, 4, 1, 4}, 7, 6);
    total++;
    printf("Sent: [1, 4, 2, 1, 4, 4, 4]\n");
    correct += test((int[]){1, 4, 2, 1, 4, 4, 4}, 7, 6);
    total++;
    printf("Sent: [3, 3, 3]\n");
    correct += test((int[]){3, 3, 3}, 3, 3);
    total++;
    printf("Sent: [3, 9, 3]\n");
    correct += test((int[]){3, 9, 3}, 3, 3);
    total++;
    printf("Sent: [3, 9, 9]\n");
    correct += test((int[]){3, 9, 9}, 3, 2);
    total++;
    printf("Sent: [3, 9]\n");
    correct += test((int[]){3, 9}, 2, 1);
    total++;
    printf("Sent: [3, 3]\n");
    correct += test((int[]){3, 3}, 2, 2);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, 0);
    total++;
    printf("Sent: [1]\n");
    correct += test((int[]){1}, 1, 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Say that a "clump" in an array is a series of 2 or more adjacent
elements of the same value. Return the number of clumps in the
given array.
*/

int countClumps(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = countClumps(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 2, 3, 4, 4]\n");
    correct += test((int[]){1, 2, 2, 3, 4, 4}, 6, 2);
    total++;
    printf("Sent: [1, 1, 2, 1, 1]\n");
    correct += test((int[]){1, 1, 2, 1, 1}, 5, 2);
    total++;
    printf("Sent: [1, 1, 1, 1, 1]\n");
    correct += test((int[]){1, 1, 1, 1, 1}, 5, 1);
    total++;
    printf("Sent: [1, 2, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, 0);
    total++;
    printf("Sent: [2, 2, 1, 1, 1, 2, 1, 1, 2, 2]\n");
    correct += test((int[]){2, 2, 1, 1, 1, 2, 1, 1, 2, 2}, 10, 4);
    total++;
    printf("Sent: [0, 2, 2, 1, 1, 1, 2, 1, 1, 2, 2]\n");
    correct += test((int[]){0, 2, 2, 1, 1, 1, 2, 1, 1, 2, 2}, 11, 4);
    total++;
    printf("Sent: [0, 0, 2, 2, 1, 1, 1, 2, 1, 1, 2, 2]\n");
    correct += test((int[]){0, 0, 2, 2, 1, 1, 1, 2, 1, 1, 2, 2}, 12, 5);
    total++;
    printf("Sent: [0, 0, 0, 2, 2, 1, 1, 1, 2, 1, 1, 2, 2]\n");
    correct += test((int[]){0, 0, 0, 2, 2, 1, 1, 1, 2, 1, 1, 2, 2}, 13, 5);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, 0);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

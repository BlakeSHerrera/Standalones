#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
We'll say that a "mirror" section in an array is a group of
contiguous elements such that somewhere in the array, the same
group appears in reverse order. For example, the largest mirror
section in {1, 2, 3, 8, 9, 3, 2, 1} is length 3 (the {1, 2, 3}
part). Return the size of the largest mirror section found in the
given array.
*/

int maxMirror(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = maxMirror(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3, 8, 9, 3, 2, 1]\n");
    correct += test((int[]){1, 2, 3, 8, 9, 3, 2, 1}, 8, 3);
    total++;
    printf("Sent: [1, 2, 1, 4]\n");
    correct += test((int[]){1, 2, 1, 4}, 4, 3);
    total++;
    printf("Sent: [7, 1, 2, 9, 7, 2, 1]\n");
    correct += test((int[]){7, 1, 2, 9, 7, 2, 1}, 7, 2);
    total++;
    printf("Sent: [21, 22, 9, 8, 7, 6, 23, 24, 6, 7, 8, 9, 25, 7, 8, 9]\n");
    correct += test((int[]){21, 22, 9, 8, 7, 6, 23, 24, 6, 7, 8, 9, 25, 7, 8, 9}, 16, 4);
    total++;
    printf("Sent: [1, 2, 1, 20, 21, 1, 2, 1, 2, 23, 24, 2, 1, 2, 1, 25]\n");
    correct += test((int[]){1, 2, 1, 20, 21, 1, 2, 1, 2, 23, 24, 2, 1, 2, 1, 25}, 16, 4);
    total++;
    printf("Sent: [1, 2, 3, 2, 1]\n");
    correct += test((int[]){1, 2, 3, 2, 1}, 5, 5);
    total++;
    printf("Sent: [1, 2, 3, 3, 8]\n");
    correct += test((int[]){1, 2, 3, 3, 8}, 5, 2);
    total++;
    printf("Sent: [1, 2, 7, 8, 1, 7, 2]\n");
    correct += test((int[]){1, 2, 7, 8, 1, 7, 2}, 7, 2);
    total++;
    printf("Sent: [1, 1, 1]\n");
    correct += test((int[]){1, 1, 1}, 3, 3);
    total++;
    printf("Sent: [1]\n");
    correct += test((int[]){1}, 1, 1);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, 0);
    total++;
    printf("Sent: [9, 1, 1, 4, 2, 1, 1, 1]\n");
    correct += test((int[]){9, 1, 1, 4, 2, 1, 1, 1}, 8, 3);
    total++;
    printf("Sent: [5, 9, 9, 4, 5, 4, 9, 9, 2]\n");
    correct += test((int[]){5, 9, 9, 4, 5, 4, 9, 9, 2}, 9, 7);
    total++;
    printf("Sent: [5, 9, 9, 6, 5, 4, 9, 9, 2]\n");
    correct += test((int[]){5, 9, 9, 6, 5, 4, 9, 9, 2}, 9, 2);
    total++;
    printf("Sent: [5, 9, 1, 6, 5, 4, 1, 9, 5]\n");
    correct += test((int[]){5, 9, 1, 6, 5, 4, 1, 9, 5}, 9, 3);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given n>=0, create an array length n*n with the following
pattern, shown here for n=3 : {0, 0, 1, �� 0, 2, 1, �� 3, 2, 1}
(spaces added to show the 3 groups).
*/

int * squareUp(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int * expected, int expectedSize)
{
    int * returned = squareUp(n);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 3\n");
    correct += test(3, ialloc((int[]){0, 0, 1, 0, 2, 1, 3, 2, 1}), 9);
    total++;
    printf("Sent: 2\n");
    correct += test(2, ialloc((int[]){0, 1, 2, 1}), 4);
    total++;
    printf("Sent: 4\n");
    correct += test(4, ialloc((int[]){0, 0, 0, 1, 0, 0, 2, 1, 0, 3, 2, 1, 4, 3, 2, 1}), 16);
    total++;
    printf("Sent: 1\n");
    correct += test(1, ialloc((int[]){1}), 1);
    total++;
    printf("Sent: 0\n");
    correct += test(0, ialloc((int[]){}), 1);
    total++;
    printf("Sent: 6\n");
    correct += test(6, ialloc((int[]){0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 2, 1, 0, 0, 0, 3, 2, 1, 0, 0, 4, 3, 2, 1, 0, 5, 4, 3, 2, 1, 6, 5, 4, 3, 2, 1}), 36);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

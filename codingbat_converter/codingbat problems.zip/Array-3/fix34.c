#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Return an array that contains exactly the same numbers as the
given array, but rearranged so that every 3 is immediately
followed by a 4. Do not move the 3's, but every other number may
move. The array contains the same number of 3's and 4's, every 3
has a number after it that is not a 3, and a 3 appears in the
array before any 4.
*/

int * fix34(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int * expected, int expectedSize)
{
    int * returned = fix34(nums, numsSize);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 3, 1, 4]\n");
    correct += test((int[]){1, 3, 1, 4}, 4, ialloc((int[]){1, 3, 4, 1}), 4);
    total++;
    printf("Sent: [1, 3, 1, 4, 4, 3, 1]\n");
    correct += test((int[]){1, 3, 1, 4, 4, 3, 1}, 7, ialloc((int[]){1, 3, 4, 1, 1, 3, 4}), 7);
    total++;
    printf("Sent: [3, 2, 2, 4]\n");
    correct += test((int[]){3, 2, 2, 4}, 4, ialloc((int[]){3, 4, 2, 2}), 4);
    total++;
    printf("Sent: [3, 2, 3, 2, 4, 4]\n");
    correct += test((int[]){3, 2, 3, 2, 4, 4}, 6, ialloc((int[]){3, 4, 3, 4, 2, 2}), 6);
    total++;
    printf("Sent: [2, 3, 2, 3, 2, 4, 4]\n");
    correct += test((int[]){2, 3, 2, 3, 2, 4, 4}, 7, ialloc((int[]){2, 3, 4, 3, 4, 2, 2}), 7);
    total++;
    printf("Sent: [5, 3, 5, 4, 5, 4, 5, 4, 3, 5, 3, 5]\n");
    correct += test((int[]){5, 3, 5, 4, 5, 4, 5, 4, 3, 5, 3, 5}, 12, ialloc((int[]){5, 3, 4, 5, 5, 5, 5, 5, 3, 4, 3, 4}), 12);
    total++;
    printf("Sent: [3, 1, 4]\n");
    correct += test((int[]){3, 1, 4}, 3, ialloc((int[]){3, 4, 1}), 3);
    total++;
    printf("Sent: [3, 4, 1]\n");
    correct += test((int[]){3, 4, 1}, 3, ialloc((int[]){3, 4, 1}), 3);
    total++;
    printf("Sent: [1, 1, 1]\n");
    correct += test((int[]){1, 1, 1}, 3, ialloc((int[]){1, 1, 1}), 3);
    total++;
    printf("Sent: [1]\n");
    correct += test((int[]){1}, 1, ialloc((int[]){1}), 1);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, ialloc((int[]){}), 1);
    total++;
    printf("Sent: [7, 3, 7, 7, 4]\n");
    correct += test((int[]){7, 3, 7, 7, 4}, 5, ialloc((int[]){7, 3, 4, 7, 7}), 5);
    total++;
    printf("Sent: [3, 1, 4, 3, 1, 4]\n");
    correct += test((int[]){3, 1, 4, 3, 1, 4}, 6, ialloc((int[]){3, 4, 1, 3, 4, 1}), 6);
    total++;
    printf("Sent: [3, 1, 1, 3, 4, 4]\n");
    correct += test((int[]){3, 1, 1, 3, 4, 4}, 6, ialloc((int[]){3, 4, 1, 3, 4, 1}), 6);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

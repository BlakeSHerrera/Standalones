#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given n>=0, create an array with the pattern {1, �� 1, 2, �� 1,
2, 3, ��... 1, 2, 3 .. n} (spaces added to show the grouping).
Note that the length of the array will be 1 + 2 + 3 ... + n,
which is known to sum to exactly n*(n + 1)/2.
*/

int * seriesUp(int n)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int n, int * expected, int expectedSize)
{
    int * returned = seriesUp(n);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: 3\n");
    correct += test(3, ialloc((int[]){1, 1, 2, 1, 2, 3}), 6);
    total++;
    printf("Sent: 4\n");
    correct += test(4, ialloc((int[]){1, 1, 2, 1, 2, 3, 1, 2, 3, 4}), 10);
    total++;
    printf("Sent: 2\n");
    correct += test(2, ialloc((int[]){1, 1, 2}), 3);
    total++;
    printf("Sent: 1\n");
    correct += test(1, ialloc((int[]){1}), 1);
    total++;
    printf("Sent: 0\n");
    correct += test(0, ialloc((int[]){}), 1);
    total++;
    printf("Sent: 6\n");
    correct += test(6, ialloc((int[]){1, 1, 2, 1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6}), 21);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

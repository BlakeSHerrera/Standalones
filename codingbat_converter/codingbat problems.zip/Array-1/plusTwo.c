#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 int arrays, each length 2, return a new array length 4
containing all their elements.
*/

int * plusTwo(int a[], int aSize, int b[], int bSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a[], int aSize, int b[], int bSize, int * expected, int expectedSize)
{
    int * returned = plusTwo(a, aSize, b, bSize);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2], [3, 4]\n");
    correct += test((int[]){1, 2}, 2, (int[]){3, 4}, 2, ialloc((int[]){1, 2, 3, 4}), 4);
    total++;
    printf("Sent: [4, 4], [2, 2]\n");
    correct += test((int[]){4, 4}, 2, (int[]){2, 2}, 2, ialloc((int[]){4, 4, 2, 2}), 4);
    total++;
    printf("Sent: [9, 2], [3, 4]\n");
    correct += test((int[]){9, 2}, 2, (int[]){3, 4}, 2, ialloc((int[]){9, 2, 3, 4}), 4);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints of odd length, look at the first, last,
and middle values in the array and return the largest. The array
length will be a least 1.
*/

int maxTriple(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = maxTriple(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, 3);
    total++;
    printf("Sent: [1, 5, 3]\n");
    correct += test((int[]){1, 5, 3}, 3, 5);
    total++;
    printf("Sent: [5, 2, 3]\n");
    correct += test((int[]){5, 2, 3}, 3, 5);
    total++;
    printf("Sent: [1, 2, 3, 1, 1]\n");
    correct += test((int[]){1, 2, 3, 1, 1}, 5, 3);
    total++;
    printf("Sent: [1, 7, 3, 1, 5]\n");
    correct += test((int[]){1, 7, 3, 1, 5}, 5, 5);
    total++;
    printf("Sent: [5, 1, 3, 7, 1]\n");
    correct += test((int[]){5, 1, 3, 7, 1}, 5, 5);
    total++;
    printf("Sent: [5, 1, 7, 3, 7, 8, 1]\n");
    correct += test((int[]){5, 1, 7, 3, 7, 8, 1}, 7, 5);
    total++;
    printf("Sent: [5, 1, 7, 9, 7, 8, 1]\n");
    correct += test((int[]){5, 1, 7, 9, 7, 8, 1}, 7, 9);
    total++;
    printf("Sent: [5, 1, 7, 3, 7, 8, 9]\n");
    correct += test((int[]){5, 1, 7, 3, 7, 8, 9}, 7, 9);
    total++;
    printf("Sent: [2, 2, 5, 1, 1]\n");
    correct += test((int[]){2, 2, 5, 1, 1}, 5, 5);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

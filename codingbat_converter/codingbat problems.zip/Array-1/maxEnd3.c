#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints length 3, figure out which is larger, the
first or last element in the array, and set all the other
elements to be that value. Return the changed array.
*/

int * maxEnd3(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int * expected, int expectedSize)
{
    int * returned = maxEnd3(nums, numsSize);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, ialloc((int[]){3, 3, 3}), 3);
    total++;
    printf("Sent: [11, 5, 9]\n");
    correct += test((int[]){11, 5, 9}, 3, ialloc((int[]){11, 11, 11}), 3);
    total++;
    printf("Sent: [2, 11, 3]\n");
    correct += test((int[]){2, 11, 3}, 3, ialloc((int[]){3, 3, 3}), 3);
    total++;
    printf("Sent: [11, 3, 3]\n");
    correct += test((int[]){11, 3, 3}, 3, ialloc((int[]){11, 11, 11}), 3);
    total++;
    printf("Sent: [3, 11, 11]\n");
    correct += test((int[]){3, 11, 11}, 3, ialloc((int[]){11, 11, 11}), 3);
    total++;
    printf("Sent: [2, 2, 2]\n");
    correct += test((int[]){2, 2, 2}, 3, ialloc((int[]){2, 2, 2}), 3);
    total++;
    printf("Sent: [2, 11, 2]\n");
    correct += test((int[]){2, 11, 2}, 3, ialloc((int[]){2, 2, 2}), 3);
    total++;
    printf("Sent: [0, 0, 1]\n");
    correct += test((int[]){0, 0, 1}, 3, ialloc((int[]){1, 1, 1}), 3);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 arrays of ints, a and b, return TRUE if they have the
same first element or they have the same last element. Both
arrays will be length 1 or more.
*/

int commonEnd(int a[], int aSize, int b[], int bSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a[], int aSize, int b[], int bSize, int expected)
{
    int returned = commonEnd(a, aSize, b, bSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3], [7, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){7, 3}, 2, TRUE);
    total++;
    printf("Sent: [1, 2, 3], [7, 3, 2]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){7, 3, 2}, 3, FALSE);
    total++;
    printf("Sent: [1, 2, 3], [1, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){1, 3}, 2, TRUE);
    total++;
    printf("Sent: [1, 2, 3], [1]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){1}, 1, TRUE);
    total++;
    printf("Sent: [1, 2, 3], [2]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){2}, 1, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, return TRUE if the array is length 1 or
more, and the first element and the last element are equal.
*/

int sameFirstLast(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = sameFirstLast(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, FALSE);
    total++;
    printf("Sent: [1, 2, 3, 1]\n");
    correct += test((int[]){1, 2, 3, 1}, 4, TRUE);
    total++;
    printf("Sent: [1, 2, 1]\n");
    correct += test((int[]){1, 2, 1}, 3, TRUE);
    total++;
    printf("Sent: [7]\n");
    correct += test((int[]){7}, 1, TRUE);
    total++;
    printf("Sent: []\n");
    correct += test((int[]){}, 1, FALSE);
    total++;
    printf("Sent: [1, 2, 3, 4, 5, 1]\n");
    correct += test((int[]){1, 2, 3, 4, 5, 1}, 6, TRUE);
    total++;
    printf("Sent: [1, 2, 3, 4, 5, 13]\n");
    correct += test((int[]){1, 2, 3, 4, 5, 13}, 6, FALSE);
    total++;
    printf("Sent: [13, 2, 3, 4, 5, 13]\n");
    correct += test((int[]){13, 2, 3, 4, 5, 13}, 6, TRUE);
    total++;
    printf("Sent: [7, 7]\n");
    correct += test((int[]){7, 7}, 2, TRUE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

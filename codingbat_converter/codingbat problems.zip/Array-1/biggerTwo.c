#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Start with 2 int arrays, a and b, each length 2. Consider the sum
of the values in each array. Return the array which has the
largest sum. In event of a tie, return a.
*/

int * biggerTwo(int a[], int aSize, int b[], int bSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a[], int aSize, int b[], int bSize, int * expected, int expectedSize)
{
    int * returned = biggerTwo(a, aSize, b, bSize);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2], [3, 4]\n");
    correct += test((int[]){1, 2}, 2, (int[]){3, 4}, 2, ialloc((int[]){3, 4}), 2);
    total++;
    printf("Sent: [3, 4], [1, 2]\n");
    correct += test((int[]){3, 4}, 2, (int[]){1, 2}, 2, ialloc((int[]){3, 4}), 2);
    total++;
    printf("Sent: [1, 1], [1, 2]\n");
    correct += test((int[]){1, 1}, 2, (int[]){1, 2}, 2, ialloc((int[]){1, 2}), 2);
    total++;
    printf("Sent: [2, 1], [1, 1]\n");
    correct += test((int[]){2, 1}, 2, (int[]){1, 1}, 2, ialloc((int[]){2, 1}), 2);
    total++;
    printf("Sent: [2, 2], [1, 3]\n");
    correct += test((int[]){2, 2}, 2, (int[]){1, 3}, 2, ialloc((int[]){2, 2}), 2);
    total++;
    printf("Sent: [1, 3], [2, 2]\n");
    correct += test((int[]){1, 3}, 2, (int[]){2, 2}, 2, ialloc((int[]){1, 3}), 2);
    total++;
    printf("Sent: [6, 7], [3, 1]\n");
    correct += test((int[]){6, 7}, 2, (int[]){3, 1}, 2, ialloc((int[]){6, 7}), 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

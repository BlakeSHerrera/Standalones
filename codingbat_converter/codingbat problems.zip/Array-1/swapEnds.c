#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, swap the first and last elements in the
array. Return the modified array. The array length will be at
least 1.
*/

int * swapEnds(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int * expected, int expectedSize)
{
    int * returned = swapEnds(nums, numsSize);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3, 4]\n");
    correct += test((int[]){1, 2, 3, 4}, 4, ialloc((int[]){4, 2, 3, 1}), 4);
    total++;
    printf("Sent: [1, 2, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, ialloc((int[]){3, 2, 1}), 3);
    total++;
    printf("Sent: [8, 6, 7, 9, 5]\n");
    correct += test((int[]){8, 6, 7, 9, 5}, 5, ialloc((int[]){5, 6, 7, 9, 8}), 5);
    total++;
    printf("Sent: [3, 1, 4, 1, 5, 9]\n");
    correct += test((int[]){3, 1, 4, 1, 5, 9}, 6, ialloc((int[]){9, 1, 4, 1, 5, 3}), 6);
    total++;
    printf("Sent: [1, 2]\n");
    correct += test((int[]){1, 2}, 2, ialloc((int[]){2, 1}), 2);
    total++;
    printf("Sent: [1]\n");
    correct += test((int[]){1}, 1, ialloc((int[]){1}), 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 int arrays, a and b, of any length, return a new array
with the first element of each array. If either array is length
0, ignore that array.
*/

int * front11(int a[], int aSize, int b[], int bSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a[], int aSize, int b[], int bSize, int * expected, int expectedSize)
{
    int * returned = front11(a, aSize, b, bSize);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3], [7, 9, 8]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){7, 9, 8}, 3, ialloc((int[]){1, 7}), 2);
    total++;
    printf("Sent: [1], [2]\n");
    correct += test((int[]){1}, 1, (int[]){2}, 1, ialloc((int[]){1, 2}), 2);
    total++;
    printf("Sent: [1, 7], []\n");
    correct += test((int[]){1, 7}, 2, (int[]){}, 1, ialloc((int[]){1}), 1);
    total++;
    printf("Sent: [], [2, 8]\n");
    correct += test((int[]){}, 1, (int[]){2, 8}, 2, ialloc((int[]){2}), 1);
    total++;
    printf("Sent: [], []\n");
    correct += test((int[]){}, 1, (int[]){}, 1, ialloc((int[]){}), 1);
    total++;
    printf("Sent: [3], [1, 4, 1, 9]\n");
    correct += test((int[]){3}, 1, (int[]){1, 4, 1, 9}, 4, ialloc((int[]){3, 1}), 2);
    total++;
    printf("Sent: [1, 4, 1, 9], []\n");
    correct += test((int[]){1, 4, 1, 9}, 4, (int[]){}, 1, ialloc((int[]){1}), 1);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Start with 2 int arrays, a and b, of any length. Return how many
of the arrays have 1 as their first element.
*/

int start1(int a[], int aSize, int b[], int bSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a[], int aSize, int b[], int bSize, int expected)
{
    int returned = start1(a, aSize, b, bSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3], [1, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){1, 3}, 2, 2);
    total++;
    printf("Sent: [7, 2, 3], [1]\n");
    correct += test((int[]){7, 2, 3}, 3, (int[]){1}, 1, 1);
    total++;
    printf("Sent: [1, 2], []\n");
    correct += test((int[]){1, 2}, 2, (int[]){}, 1, 1);
    total++;
    printf("Sent: [], [1, 2]\n");
    correct += test((int[]){}, 1, (int[]){1, 2}, 2, 1);
    total++;
    printf("Sent: [7], []\n");
    correct += test((int[]){7}, 1, (int[]){}, 1, 0);
    total++;
    printf("Sent: [7], [1]\n");
    correct += test((int[]){7}, 1, (int[]){1}, 1, 1);
    total++;
    printf("Sent: [1], [1]\n");
    correct += test((int[]){1}, 1, (int[]){1}, 1, 2);
    total++;
    printf("Sent: [7], [8]\n");
    correct += test((int[]){7}, 1, (int[]){8}, 1, 0);
    total++;
    printf("Sent: [], []\n");
    correct += test((int[]){}, 1, (int[]){}, 1, 0);
    total++;
    printf("Sent: [1, 3], [1]\n");
    correct += test((int[]){1, 3}, 2, (int[]){1}, 1, 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints, return TRUE if 6 appears as either the
first or last element in the array. The array will be length 1 or
more.
*/

int firstLast6(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int expected)
{
    int returned = firstLast6(nums, numsSize);
    printf("%d Expected\n", expected);
    printf("%d Returned\n\n", returned);
    return expected == returned;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 6]\n");
    correct += test((int[]){1, 2, 6}, 3, TRUE);
    total++;
    printf("Sent: [6, 1, 2, 3]\n");
    correct += test((int[]){6, 1, 2, 3}, 4, TRUE);
    total++;
    printf("Sent: [13, 6, 1, 2, 3]\n");
    correct += test((int[]){13, 6, 1, 2, 3}, 5, FALSE);
    total++;
    printf("Sent: [13, 6, 1, 2, 6]\n");
    correct += test((int[]){13, 6, 1, 2, 6}, 5, TRUE);
    total++;
    printf("Sent: [3, 2, 1]\n");
    correct += test((int[]){3, 2, 1}, 3, FALSE);
    total++;
    printf("Sent: [3, 6, 1]\n");
    correct += test((int[]){3, 6, 1}, 3, FALSE);
    total++;
    printf("Sent: [3, 6]\n");
    correct += test((int[]){3, 6}, 2, TRUE);
    total++;
    printf("Sent: [6]\n");
    correct += test((int[]){6}, 1, TRUE);
    total++;
    printf("Sent: [3]\n");
    correct += test((int[]){3}, 1, FALSE);
    total++;
    printf("Sent: [5, 6]\n");
    correct += test((int[]){5, 6}, 2, TRUE);
    total++;
    printf("Sent: [5, 5]\n");
    correct += test((int[]){5, 5}, 2, FALSE);
    total++;
    printf("Sent: [1, 2, 3, 4, 6]\n");
    correct += test((int[]){1, 2, 3, 4, 6}, 5, TRUE);
    total++;
    printf("Sent: [1, 2, 3, 4]\n");
    correct += test((int[]){1, 2, 3, 4}, 4, FALSE);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

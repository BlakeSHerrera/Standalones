#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints of even length, return a new array length
2 containing the middle two elements from the original array. The
original array will be length 2 or more.
*/

int * makeMiddle(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int * expected, int expectedSize)
{
    int * returned = makeMiddle(nums, numsSize);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3, 4]\n");
    correct += test((int[]){1, 2, 3, 4}, 4, ialloc((int[]){2, 3}), 2);
    total++;
    printf("Sent: [7, 1, 2, 3, 4, 9]\n");
    correct += test((int[]){7, 1, 2, 3, 4, 9}, 6, ialloc((int[]){2, 3}), 2);
    total++;
    printf("Sent: [1, 2]\n");
    correct += test((int[]){1, 2}, 2, ialloc((int[]){1, 2}), 2);
    total++;
    printf("Sent: [5, 2, 4, 7]\n");
    correct += test((int[]){5, 2, 4, 7}, 4, ialloc((int[]){2, 4}), 2);
    total++;
    printf("Sent: [9, 0, 4, 3, 9, 1]\n");
    correct += test((int[]){9, 0, 4, 3, 9, 1}, 6, ialloc((int[]){4, 3}), 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

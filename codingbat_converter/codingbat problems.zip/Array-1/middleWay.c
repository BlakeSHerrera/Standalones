#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given 2 int arrays, a and b, each length 3, return a new array
length 2 containing their middle elements.
*/

int * middleWay(int a[], int aSize, int b[], int bSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int a[], int aSize, int b[], int bSize, int * expected, int expectedSize)
{
    int * returned = middleWay(a, aSize, b, bSize);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3], [4, 5, 6]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){4, 5, 6}, 3, ialloc((int[]){2, 5}), 2);
    total++;
    printf("Sent: [7, 7, 7], [3, 8, 0]\n");
    correct += test((int[]){7, 7, 7}, 3, (int[]){3, 8, 0}, 3, ialloc((int[]){7, 8}), 2);
    total++;
    printf("Sent: [5, 2, 9], [1, 4, 5]\n");
    correct += test((int[]){5, 2, 9}, 3, (int[]){1, 4, 5}, 3, ialloc((int[]){2, 4}), 2);
    total++;
    printf("Sent: [1, 9, 7], [4, 8, 8]\n");
    correct += test((int[]){1, 9, 7}, 3, (int[]){4, 8, 8}, 3, ialloc((int[]){9, 8}), 2);
    total++;
    printf("Sent: [1, 2, 3], [3, 1, 4]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){3, 1, 4}, 3, ialloc((int[]){2, 1}), 2);
    total++;
    printf("Sent: [1, 2, 3], [4, 1, 1]\n");
    correct += test((int[]){1, 2, 3}, 3, (int[]){4, 1, 1}, 3, ialloc((int[]){2, 1}), 2);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}

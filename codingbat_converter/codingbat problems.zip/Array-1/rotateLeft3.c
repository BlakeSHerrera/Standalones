#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*
Given an array of ints length 3, return an array with the
elements "rotated left" so {1, 2, 3} yields {2, 3, 1}.
*/

int * rotateLeft3(int nums[], int numsSize)
{
    
}

void printarr(int * arr, int size)
{
    int i;
    printf("{");
    for(i=0; i<size; i++)
    {
        if(i != 0)
        {
            printf(", %d", arr[i]);
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    printf("}");
}

int * ialloc(int arr[])
{
    int size = sizeof(arr);
    int * i = (int *) malloc(size * sizeof(int));
    for(size = size-1; size>=0; size--)
    {
        i[size] = arr[size];
    }
    return i;
}

int test(int nums[], int numsSize, int * expected, int expectedSize)
{
    int * returned = rotateLeft3(nums, numsSize);
    printarr(expected, expectedSize);
    printf(" Expected\n", expected);
    printarr(returned, expectedSize);
    printf(" Returned\n\n", returned);
    int res = memcmp(expected, returned, expectedSize * sizeof(int)) == 0;
    free(returned);
    free(expected);
    return res;
}

int main()
{
    int correct = 0;
    int total = 0;
    printf("Sent: [1, 2, 3]\n");
    correct += test((int[]){1, 2, 3}, 3, ialloc((int[]){2, 3, 1}), 3);
    total++;
    printf("Sent: [5, 11, 9]\n");
    correct += test((int[]){5, 11, 9}, 3, ialloc((int[]){11, 9, 5}), 3);
    total++;
    printf("Sent: [7, 0, 0]\n");
    correct += test((int[]){7, 0, 0}, 3, ialloc((int[]){0, 0, 7}), 3);
    total++;
    printf("Sent: [1, 2, 1]\n");
    correct += test((int[]){1, 2, 1}, 3, ialloc((int[]){2, 1, 1}), 3);
    total++;
    printf("Sent: [0, 0, 1]\n");
    correct += test((int[]){0, 0, 1}, 3, ialloc((int[]){0, 1, 0}), 3);
    total++;
    printf("%d / %d correct\n", correct, total");
    return 0;
}
